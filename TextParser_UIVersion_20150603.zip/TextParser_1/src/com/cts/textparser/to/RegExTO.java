/**
 * 
 */
package com.cts.textparser.to;

import java.util.regex.Pattern;


/**
 * Transfer object to represent a regular expression item
 * 
 * @author 153093
 *
 */
public class RegExTO extends DictionaryItem {

	/**
	 * Actual value
	 */
	private String value;
	
	/**
	 * Complied pattern for value
	 */
	private Pattern pattern;

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * @return the pattern
	 */
	public Pattern getPattern() {
		return pattern;
	}

	/**
	 * @param pattern the pattern to set
	 */
	public void setPattern(Pattern pattern) {
		this.pattern = pattern;
	}

}
