/**
 * 
 */
package com.cts.textparser.to;

import java.util.HashMap;
import java.util.Map;



/**
 * Transfer object to represent each parsed attribute value
 * 
 * @author 153093
 *
 */
public class ParsedAttributeItem {

	/**
	 * Parsed value
	 */
	private String value;
	
	/**
	 * Sub attribute values which are arrived from main attribute value
	 */
	private Map<String, Map<Integer, ParsedAttributeItem>> subAttributes;
	
	
	public ParsedAttributeItem(String value) {
		this.value = value;
		subAttributes = new HashMap<String, Map<Integer,ParsedAttributeItem>>();
	}
	
	public ParsedAttributeItem(ParsedAttributeItem attributeItem) {
		this(attributeItem.getValue());
	}
	
	/**
	 * Describe properties as string
	 * 
	 */
	@Override
	public String toString() {
		return value;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * @return the subAttributes
	 */
	public Map<String, Map<Integer, ParsedAttributeItem>> getSubAttributes() {
		return subAttributes;
	}

	/**
	 * @param subAttributes the subAttributes to set
	 */
	public void setSubAttributes(
			Map<String, Map<Integer, ParsedAttributeItem>> subAttributes) {
		this.subAttributes = subAttributes;
	}

}
