/**
 * 
 */
package com.cts.textparser.to;

import java.util.ArrayList;
import java.util.List;

/**
 * @author 236221
 *
 */
public class MasterViewTO {

	private String tabName;
	private String elementName;
	
	private List<ListTO<String>> listTOs = new ArrayList<>();
	private List<MapTO> mapTOs = new ArrayList<>();
	private List<ListTO<ReplaceInPatternItem>> replaceInPatternTOs = new ArrayList<>();
	private List<ListTO<InsertInPatternItem>> insertInPatternTOs = new ArrayList<>();
	private List<AttributeTO> attributeTOs = new ArrayList<>();

	/**
	 * @return the listTOs
	 */
	public List<ListTO<String>> getListTOs() {
		return listTOs;
	}
	/**
	 * @param listTOs the listTOs to set
	 */
	public void setListTOs(List<ListTO<String>> listTOs) {
		this.listTOs = listTOs;
	}
	/**
	 * @return the tabName
	 */
	public String getTabName() {
		return tabName;
	}
	/**
	 * @param tabName the tabName to set
	 */
	public void setTabName(String tabName) {
		this.tabName = tabName;
	}
	/**
	 * @return the mapTOs
	 */
	public List<MapTO> getMapTOs() {
		return mapTOs;
	}
	/**
	 * @param mapTOs the mapTOs to set
	 */
	public void setMapTOs(List<MapTO> mapTOs) {
		this.mapTOs = mapTOs;
	}
	/**
	 * @return the replaceInPatternTOs
	 */
	public List<ListTO<ReplaceInPatternItem>> getReplaceInPatternTOs() {
		return replaceInPatternTOs;
	}
	/**
	 * @param replaceInPatternTOs the replaceInPatternTOs to set
	 */
	public void setReplaceInPatternTOs(
			List<ListTO<ReplaceInPatternItem>> replaceInPatternTOs) {
		this.replaceInPatternTOs = replaceInPatternTOs;
	}
	/**
	 * @return the insertInPatternTOs
	 */
	public List<ListTO<InsertInPatternItem>> getInsertInPatternTOs() {
		return insertInPatternTOs;
	}
	/**
	 * @param insertInPatternTOs the insertInPatternTOs to set
	 */
	public void setInsertInPatternTOs(
			List<ListTO<InsertInPatternItem>> insertInPatternTOs) {
		this.insertInPatternTOs = insertInPatternTOs;
	}
	/**
	 * @return the attributeTOs
	 */
	public List<AttributeTO> getAttributeTOs() {
		return attributeTOs;
	}
	/**
	 * @param attributeTOs the attributeTOs to set
	 */
	public void setAttributeTOs(List<AttributeTO> attributeTOs) {
		this.attributeTOs = attributeTOs;
	}
	/**
	 * @return the elementName
	 */
	public String getElementName() {
		return elementName;
	}
	/**
	 * @param elementName the elementName to set
	 */
	public void setElementName(String elementName) {
		this.elementName = elementName;
	}
	
	
}
