/**
 * 
 */
package com.cts.textparser.to;

import java.util.List;



/**
 * Transfer object to represent a attribute
 * 
 * @author 153093
 *
 */
public class AttributeTO extends DictionaryItem {

	/**
	 * To hold name of sub attributes
	 */
	private List<String> subAttributeNames; // TODO: Modify parent-sub level classification, to manage better for UI

	/**
	 * @return the subAttributeNames
	 */
	public List<String> getSubAttributeNames() {
		return subAttributeNames;
	}

	/**
	 * @param subAttributeNames the subAttributeNames to set
	 */
	public void setSubAttributeNames(List<String> subAttributeNames) {
		this.subAttributeNames = subAttributeNames;
	}
}
