/**
 * 
 */
package com.cts.textparser.constant;

import java.util.regex.Pattern;

/**
 * To hold list of regular expression constants for this application
 * 
 * @author 153093
 *
 */
public class RegexConstants {

	public static final String ONE_OR_MORE_WHITE_SPACE = "\\s+";
	public static final String TWO_OR_MORE_WHITE_SPACE = "\\s{2,}";

	public static final String ONE_OR_MORE_WORD_CHARS = "\\w+";
	public static final Pattern PATTERN_ONE_OR_MORE_WORD_CHARS = Pattern.compile(ONE_OR_MORE_WORD_CHARS);

	public static final String COMPLEX_FRACTION = "(^|\\s)\\d+\\s+\\d+/\\d+(\\s|$)"; // Like 1 1/2
	public static final Pattern PATTERN_COMPLEX_FRACTION = Pattern.compile(COMPLEX_FRACTION);

	public static final String SIMPLE_FRACTION = "(^|\\s)\\d+/\\d+(\\s|$)"; // Like 1/2
	public static final Pattern PATTERN_SIMPLE_FRACTION = Pattern.compile(SIMPLE_FRACTION);

	public static final String PHRASES_WITHIN_BRACKET = "[(].*?[)]";
	public static final Pattern PATTERN_PHRASES_WITHIN_BRACKET = Pattern.compile(PHRASES_WITHIN_BRACKET);
}

