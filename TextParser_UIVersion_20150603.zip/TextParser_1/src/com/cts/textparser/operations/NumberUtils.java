/**
 * 
 */
package com.cts.textparser.operations;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cts.textparser.constant.GeneralConstants;
import com.cts.textparser.constant.RegexConstants;

/**
 * Utility class to hold methods which will do number related operations.
 * 
 * @author 153093
 *
 */
public class NumberUtils {

	private static final Logger LOGGER = Logger.getLogger(NumberUtils.class);

	private static final String DIGIT_IND_ONES = "O";
	private static final String DIGIT_IND_TENS = "T";
	private static final String DIGIT_IND_MAGNITUDES = "M";
	
	private static Map<String, Integer> numberOnesMap;

	private static Map<String, Integer> numberTensMap;

	private static Map<String, Integer> numberMagnitudesMap;
	
	
	static {
		// Initialize static fields with required values
		numberOnesMap = new HashMap<String, Integer>();
		numberOnesMap.put("ZERO", 0);
		numberOnesMap.put("ONE", 1);
		numberOnesMap.put("TWO", 2);
		numberOnesMap.put("THREE", 3);
		numberOnesMap.put("FOUR", 4);
		numberOnesMap.put("FIVE", 5);
		numberOnesMap.put("SIX", 6);
		numberOnesMap.put("SEVEN", 7);
		numberOnesMap.put("EIGHT", 8);
		numberOnesMap.put("NINE", 9);
		numberOnesMap.put("TEN", 10);
		numberOnesMap.put("ELEVEN", 11);
		numberOnesMap.put("TWELVE", 12);
		numberOnesMap.put("THIRTEEN", 13);
		numberOnesMap.put("FOURTEEN", 14);
		numberOnesMap.put("FIFTEEN", 15);
		numberOnesMap.put("SIXTEEN", 16);
		numberOnesMap.put("SEVENTEEN", 17);
		numberOnesMap.put("EIGHTEEN", 18);
		numberOnesMap.put("NINETEEN", 19);
		
		numberTensMap = new HashMap<String, Integer>();
		numberTensMap.put("TWENTY", 20);
		numberTensMap.put("THIRTY", 30);
		numberTensMap.put("FORTY", 40);
		numberTensMap.put("FIFTY", 50);
		numberTensMap.put("SIXTY", 60);
		numberTensMap.put("SEVENTY", 70);
		numberTensMap.put("EIGHTY", 80);
		numberTensMap.put("NINETY", 90);
		
		numberMagnitudesMap = new HashMap<String, Integer>();
		numberMagnitudesMap.put("HUNDRED", 100);
		numberMagnitudesMap.put("THOUSAND", 1000);
		numberMagnitudesMap.put("MILLION", 100000);
	}
	
	/**
	 * This method will covert all number words to digits in given input string, example "ONE" to "1".
	 * This method has limitation, it won't convert complex words (like HUNDREAD AND ONE),
	 * it will work fine for 1 to 100.
	 * 
	 * @param 	input
	 * 			input string in upper case
	 * 
	 * @return	modified string, all number words will be in digit form.
	 * 
	 */
	public static String convertNumberWordsToDigits(String input) {
		LOGGER.debug("Converting numeric words to digits starts...");
		if(StringUtils.isBlank(input)) {
			return input;
		}
					
	    int findStartIdx;
	    int startIdx, endIdx;
		int digitForm = -1;
		String token;
		String result = GeneralConstants.EMPTY_STRING;
		String digitIdentifiedInd = GeneralConstants.EMPTY_STRING;
	    StringBuilder inputBuffer = new StringBuilder(input);
		
		Pattern pattern = RegexConstants.PATTERN_ONE_OR_MORE_WORD_CHARS;
	    Matcher matcher = pattern.matcher(inputBuffer);
	    findStartIdx = startIdx = endIdx = 0;
	    while(matcher.find(findStartIdx)) {
		
	    	if(StringUtils.isNotBlank(inputBuffer.substring(findStartIdx, matcher.start()))) {
				if(StringUtils.isNotBlank(digitIdentifiedInd)) {
					result = String.valueOf(digitForm);
			    	inputBuffer.replace(startIdx, endIdx, result);
			    	
				    matcher = pattern.matcher(inputBuffer);
				    findStartIdx = startIdx + result.length();
				    digitIdentifiedInd = GeneralConstants.EMPTY_STRING;
					digitForm = -1;
					startIdx = findStartIdx;
				    continue;
				}
	    	}

	    	token = inputBuffer.substring(matcher.start(), matcher.end());
			if(numberOnesMap.containsKey(token)) {
				if(DIGIT_IND_ONES.equals(digitIdentifiedInd)) {
					result = String.valueOf(digitForm);
			    	inputBuffer.replace(startIdx, endIdx, result);
			    	
				    matcher = pattern.matcher(inputBuffer);
				    findStartIdx = startIdx + result.length();
				    digitIdentifiedInd = GeneralConstants.EMPTY_STRING;
					digitForm = -1;
					startIdx = findStartIdx;
				    continue;
				}
				if(digitForm == -1) {
					digitForm = numberOnesMap.get(token);
			    	startIdx = matcher.start();
			    	endIdx = matcher.end();
				}
				else {
					digitForm += numberOnesMap.get(token);
			    	endIdx = matcher.end();
				}
				digitIdentifiedInd = DIGIT_IND_ONES;
			}
			else if(numberTensMap.containsKey(token)) {
				if(digitForm == -1) {
					digitForm = numberTensMap.get(token);
			    	startIdx = matcher.start();
			    	endIdx = matcher.end();
				}
				else {
					digitForm += numberTensMap.get(token);
			    	endIdx = matcher.end();
				}
				digitIdentifiedInd = DIGIT_IND_TENS;
			}
			else if(numberMagnitudesMap.containsKey(token)) {
				if(digitForm == -1) {
					digitForm = numberMagnitudesMap.get(token);
			    	startIdx = matcher.start();
			    	endIdx = matcher.end();
				}
				else {
					digitForm *= numberMagnitudesMap.get(token);
			    	endIdx = matcher.end();
				}
				digitIdentifiedInd = DIGIT_IND_MAGNITUDES;
			}
			else {
				if(StringUtils.isNotBlank(digitIdentifiedInd)) {
					result = String.valueOf(digitForm);
			    	inputBuffer.replace(startIdx, endIdx, result);
			    	
				    matcher = pattern.matcher(inputBuffer);
				    findStartIdx = startIdx + result.length();
				    digitIdentifiedInd = GeneralConstants.EMPTY_STRING;
					digitForm = -1;
					startIdx = findStartIdx;
				    continue;
				}
			}
			findStartIdx = matcher.end();
		}
		
		if(StringUtils.isNotBlank(digitIdentifiedInd)) {
			result = String.valueOf(digitForm);
	    	inputBuffer.replace(startIdx, endIdx, result);
		}
		
		LOGGER.debug("Converting numeric words to digits ends.");
		return inputBuffer.toString();
	}
	
	/**
	 * Method to convert fraction values to decimal form
	 * 
	 * @param 	input
	 * 			input string
	 * 
	 * @return	modified string, all fractions representation will be 
	 * 			converted to decimal form, also removes extra white spaces if any.
	 * 
	 */
	public static String convertFractionsToDecimal(String input) {
		LOGGER.debug("Converting fractions to decimals starts...");
		
		StringBuilder inputBuffer = new StringBuilder(input);
	    int findStartIdx;
	    int spaceIdx, slashIdx;
	    double numerator1, numerator2, denominator;
	    String fraction;

	    // Convert complex fractions
	    Pattern pattern = RegexConstants.PATTERN_COMPLEX_FRACTION;
	    Matcher matcher = pattern.matcher(inputBuffer);
	    findStartIdx = 0;
	    while (matcher.find(findStartIdx)) {
	    	findStartIdx = matcher.start();
	    	
	    	fraction = inputBuffer.substring(matcher.start(), matcher.end()).trim();
	    	spaceIdx = fraction.indexOf(GeneralConstants.SPACE_STRING);
	    	numerator1 = Integer.parseInt(fraction.substring(0, spaceIdx).trim());
	    	slashIdx = fraction.indexOf(GeneralConstants.SLASH_STRING);
	    	numerator2 = Integer.parseInt(fraction.substring(spaceIdx + 1, slashIdx).trim());
	    	denominator = Integer.parseInt(fraction.substring(slashIdx + 1).trim());
	    	numerator1 *= denominator;
	    	numerator1 = (numerator1 + numerator2) / denominator;
	    	
    		inputBuffer.replace(matcher.start(), matcher.end(), 
    				GeneralConstants.SPACE_STRING + numerator1 + GeneralConstants.SPACE_STRING);

	    	// build matcher again with updated string, and start from new index
	    	matcher = pattern.matcher(inputBuffer);
	    }

	    // convert simple fractions to decimal form, example 1/2 to 0.50
	    pattern = RegexConstants.PATTERN_SIMPLE_FRACTION;
	    matcher = pattern.matcher(inputBuffer);
	    findStartIdx = 0;
	    while (matcher.find(findStartIdx)) {
	    	findStartIdx = matcher.start();

	    	fraction = inputBuffer.substring(matcher.start(), matcher.end()).trim();
	    	slashIdx = fraction.indexOf(GeneralConstants.SLASH_STRING);
	    	numerator1 = Integer.parseInt(fraction.substring(0, slashIdx).trim());
	    	denominator = Integer.parseInt(fraction.substring(slashIdx + 1).trim());
	    	numerator1 = numerator1 / denominator;
    		inputBuffer.replace(matcher.start(), matcher.end(), 
    				GeneralConstants.SPACE_STRING + numerator1 + GeneralConstants.SPACE_STRING);
	    	
	    	// build matcher again with updated string, and start from new index
	    	matcher = pattern.matcher(inputBuffer);
	    }
	    
		LOGGER.debug("Converting fractions to decimals ends.");
		return inputBuffer.toString();
	}
}
