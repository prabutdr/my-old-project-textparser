/**
 * 
 */
package com.cts.textparser.operations;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;

import com.cts.textparser.constant.GeneralConstants;
import com.cts.textparser.to.ParsedAttributeItem;

/**
 * Utility class to hold methods which will do general operations for parser.
 * 
 * @author 153093
 *
 */
public class GeneralOperations {

	private static final Logger LOGGER = Logger.getLogger(GeneralOperations.class);

	/**
	 * Method to convert attribute values into upper case
	 * 
	 * @param 	sourceAttribute
	 * 			Name of source attribute
	 * 
	 * @param 	targetAttribute
	 * 			Name of target attribute
	 * 
	 * @param 	textParserTO
	 * 			Internal transfer object which holds all attribute maps
	 * 
	 * @return	Result code
	 */
	public static String copyAttribute(Map<Integer, ParsedAttributeItem> sourceAttributeMap, Map<Integer, ParsedAttributeItem> targetAttributeMap) {
		LOGGER.debug("Copy attribute starts...");
		
		// Copy all source attribute values to target attribute value map
		Iterator<Entry<Integer, ParsedAttributeItem>> attributeMapIterator = sourceAttributeMap.entrySet().iterator();
		while(attributeMapIterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> attributeEntry = attributeMapIterator.next();
			targetAttributeMap.put(attributeEntry.getKey(), new ParsedAttributeItem(attributeEntry.getValue()));
		}
		
		LOGGER.debug("Copy attribute ends.");
		return GeneralConstants.SUCCESS_RESULT_CODE;
	}
}
