/**
 * 
 */
package com.cts.textparser.operations;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

import com.cts.textparser.constant.GeneralConstants;
import com.cts.textparser.constant.RegexConstants;
import com.cts.textparser.to.InsertInPatternItem;
import com.cts.textparser.to.ReplaceInPatternItem;

/**
 * Utility class to hold methods which will do text operations.
 * 
 * @author 153093
 *
 */
public class TextUtils {

	/**
	 * Helper method to apply a replace in pattern rule on given attribute value
	 * 
	 * @param 	attributeValue
	 * 
	 * @param 	replaceInPatternItem
	 * 			Rule to be applied
	 * 
	 * @return	Modified attribute value (after applying rule)
	 */
	public static String replaceInPattern(final String attributeValue, final ReplaceInPatternItem replaceInPatternItem) {
		if (StringUtils.isBlank(attributeValue)) {
			return attributeValue;
		}
		
	    int findStartIdx;
	    int startIdx, endIdx;
	    String matchText;
	    StringBuilder inputBuffer = new StringBuilder(attributeValue);
		
		// Search patterns in input string if found, replace expression with substitute
		// within that matched substring
	    Matcher matcher = replaceInPatternItem.getLookupPattern().matcher(inputBuffer);
	    findStartIdx = 0;
	    while (matcher.find(findStartIdx)) {
	    	startIdx = matcher.start();
	    	endIdx = matcher.end();
	    	matchText = inputBuffer.substring(startIdx, endIdx);
	    	matchText = matchText.replaceAll(replaceInPatternItem.getTargetValue(), replaceInPatternItem.getReplacement());
	    	inputBuffer.replace(startIdx, endIdx, matchText);
		    
	    	// build matcher again with updated string, and start from new index
	    	matcher = replaceInPatternItem.getLookupPattern().matcher(inputBuffer);
	    	findStartIdx = startIdx + matchText.length();
	    }
	    
	    return inputBuffer.toString();
	}

	/**
	 * Helper method to apply a insert in pattern rule on given attribute value
	 * 
	 * @param 	attributeValue
	 * 
	 * @param 	insertInPatternItem
	 * 			Rule to be applied
	 * 
	 * @return	Modified attribute value (after applying rule)
	 */
	public static String insertInPattern(final String attributeValue, final InsertInPatternItem insertInPatternItem) {
		if(StringUtils.isBlank(attributeValue)) {
			return attributeValue;
		}
		
	    int findStartIdx;
	    int targetIdx;
	    StringBuilder inputBuffer = new StringBuilder(attributeValue);
		
		// Search patterns in the input string, if found insert given value at given position
		// within that matched substring
	    Matcher matcher = insertInPatternItem.getLookupPattern().matcher(inputBuffer);
	    findStartIdx = 0;
	    while(matcher.find(findStartIdx)) {
	    	targetIdx = matcher.start() + insertInPatternItem.getTargetPosition();
	    	findStartIdx = matcher.end() + insertInPatternItem.getInsertValue().length();
	    	
	    	inputBuffer.insert(targetIdx, insertInPatternItem.getInsertValue());

	    	// build matcher again with updated string, and start from new index
	    	matcher = insertInPatternItem.getLookupPattern().matcher(inputBuffer);
	    }
	    
	    return inputBuffer.toString();
	}	

	/**
	 * Helper method to apply replace phrases rule on given attribute value
	 * 
	 * @param 	attributeValue
	 * @param 	phraseMap
	 * 
	 * @return	Modified attribute value (after applying rule)
	 */
	public static String replacePhrases(final String attributeValue, final Map<String, String> phraseMap) {
		if(StringUtils.isBlank(attributeValue)) {
			return attributeValue;
		}
		
		StringBuilder inputBuffer = new StringBuilder(attributeValue);
		int startIdx, endIdx;
		String key, value;

		for (Map.Entry<String,String> entry : phraseMap.entrySet()) {
			  key = entry.getKey();
			  value = entry.getValue();

			  endIdx = 0;
			  while((startIdx = inputBuffer.indexOf(key, endIdx)) != -1) {
				  endIdx = startIdx + key.length();
				  if(((startIdx == 0) || (!Character.isLetter(inputBuffer.charAt(startIdx - 1)) && !Character.isDigit(inputBuffer.charAt(startIdx - 1))))
						  && ((endIdx == inputBuffer.length()) || (!Character.isLetter(inputBuffer.charAt(endIdx)) && !Character.isDigit(inputBuffer.charAt(endIdx))))
						  && (key.length() > value.length() || inputBuffer.indexOf(value, startIdx) != startIdx)) {
					  inputBuffer.replace(startIdx, endIdx, value);
					  endIdx = startIdx + value.length();
				  }
			  }
		}
		
		return inputBuffer.toString();
	}

	/**
	 * Check the values within the brackets (), and if same value present before 
	 * bracket starts then considering it as duplicate value and removing 
	 * one of it. 
	 * Example - "2 (2)" will be converted to "2"    
	 * 
	 * @param 	input
	 * 			input string
	 * 
	 * @return	Modified string after normalizing tokens within bracket
	 * 
	 */
	public static String removeDuplicatesInBracket(String input) {
		if(StringUtils.isBlank(input)) {
			return input;
		}
		
		StringBuilder inputBuffer = new StringBuilder(input);
		String wordInBracket, wordTillBracket;
		Pattern pattern = RegexConstants.PATTERN_PHRASES_WITHIN_BRACKET;
		int findStartIdx = 0;

		Matcher matcher = pattern.matcher(inputBuffer);
		while(matcher.find(findStartIdx)) {
			wordInBracket = inputBuffer.substring(matcher.start() + 1, matcher.end() - 1).trim();
			wordTillBracket = inputBuffer.substring(0, matcher.start()).trim();

			if(wordTillBracket.endsWith(wordInBracket)) {
				findStartIdx = matcher.start();
				inputBuffer.replace(matcher.start(), matcher.end(), GeneralConstants.EMPTY_STRING);

		    	// build matcher again with updated string, and start from new index
		    	matcher = pattern.matcher(inputBuffer);
			}
			else {
				findStartIdx = matcher.end();
			}
	    }
	    String result = inputBuffer.toString();
	    
		// Remove more than one white spaces with single white space character
	    result = removeSpareSpaces(result);

		return result;
	}

	/**
	 * Method to remove spare spaces. i.e., this will replace more than one white spaces
	 * into one white space character  
	 * 
	 * @param 	input
	 * 			input string
	 * 
	 * @return	Modified string after normalizing tokens within bracket
	 * 
	 */
	public static String removeSpareSpaces(String input) {
		// Remove more than one white spaces with single white space character
	    return input.replaceAll(RegexConstants.ONE_OR_MORE_WHITE_SPACE, GeneralConstants.SPACE_STRING);
	}
}
