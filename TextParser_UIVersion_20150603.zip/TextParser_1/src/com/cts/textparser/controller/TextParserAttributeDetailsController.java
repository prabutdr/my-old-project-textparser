/**
 * 
 */
package com.cts.textparser.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cts.textparser.constant.DictionaryConstants;
import com.cts.textparser.constant.GeneralConstants;
import com.cts.textparser.to.AttributeTO;
import com.cts.textparser.to.ListTO;
import com.cts.textparser.to.MasterViewTO;
import com.cts.textparser.to.ReplaceInPatternItem;
import com.cts.textparser.util.TextParserException;
import com.cts.textparser.util.WorkbookUtil;

/**
 * @author 236221
 *
 */

@Controller
@RequestMapping("/attributeDetail")
public class TextParserAttributeDetailsController {


	
	@Autowired(required = true)
	@Qualifier("workbookUtil")
	private WorkbookUtil workbookUtil;
	
	@RequestMapping(method = RequestMethod.GET)
	public String getCacheResult(ModelMap model, HttpServletRequest request) {
		MasterViewTO masterViewTO= new MasterViewTO();
		masterViewTO.setTabName("Attributes");
		try {
			 List<AttributeTO> attributesFromSheet = workbookUtil.getAttributesFromSheet(DictionaryConstants.ATTRIBUTE);
			for (AttributeTO attributeTO : attributesFromSheet){
					masterViewTO.getAttributeTOs().add(attributeTO);
			}
		} catch (TextParserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.put("masterViewTO", masterViewTO);
		return GeneralConstants.VIEW_SHOW_CACHE_MASTER;
	}
}
