/**
 * 
 */
package com.cts.textparser.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cts.textparser.constant.DictionaryConstants;
import com.cts.textparser.constant.GeneralConstants;
import com.cts.textparser.to.InsertInPatternItem;
import com.cts.textparser.to.ListTO;
import com.cts.textparser.to.MapTO;
import com.cts.textparser.to.MasterViewTO;
import com.cts.textparser.to.ReplaceInPatternItem;
import com.cts.textparser.util.TextParserException;
import com.cts.textparser.util.WorkbookUtil;

/**
 * @author 236221
 *
 */
@Controller
public class TextParserCacheDetailsController {
	
	@Autowired(required = true)
	@Qualifier("workbookUtil")
	private WorkbookUtil workbookUtil;
	
	@RequestMapping(value="/cacheDetail", method = RequestMethod.GET)
	public String getDashboardScreen(ModelMap model, HttpServletRequest request) {
		return GeneralConstants.VIEW_SHOW_CACHE_MASTER;
	}
	
	
	@RequestMapping(value="/attributeDetails", method = RequestMethod.GET)
	public String getAttributeDetails(ModelMap model, HttpServletRequest request) {
		
		String component = request.getParameter("component");
		
		try {
			Map<String, List<String>> masterMap = new HashMap<String, List<String>>();
			
			if(component.equalsIgnoreCase("List")){
				List<String> tempList = new ArrayList<String>();
				List<String> desclist = new ArrayList<String>();
				List<ListTO<String>> listTOs = workbookUtil.getListsFromSheet(DictionaryConstants.LIST);
				for(ListTO listTO:listTOs){
					tempList.add(listTO.getName());
					desclist.add(listTO.getDescription());
				}
				masterMap.put("key", tempList);
				masterMap.put("description", desclist);
			}
			if(component.equalsIgnoreCase("Map")){
				List<String> tempMap = new ArrayList<String>();
				List<MapTO> mapsFromSheet = workbookUtil.getMapsFromSheet(DictionaryConstants.MAP);
				for(MapTO mapTO:mapsFromSheet){
					tempMap.add(mapTO.getName());
				}			
				masterMap.put("key", tempMap);
			}
			if(component.equalsIgnoreCase("ReplacePattern")){
				List<String> tempReplaceInPatterns = new ArrayList<String>();
				List<ListTO<ReplaceInPatternItem>> replaceInPatternsFromSheet = workbookUtil.getReplaceInPatternsFromSheet(DictionaryConstants.REPLACE_IN_PATTERN);
				for(ListTO replaceInPatternTO:replaceInPatternsFromSheet){
					tempReplaceInPatterns.add(replaceInPatternTO.getName());
				}			
				masterMap.put("key", tempReplaceInPatterns);
			}
			if(component.equalsIgnoreCase("InsertPattern")){
				List<String> tempinsertInPatterns = new ArrayList<String>();
				List<ListTO<InsertInPatternItem>> insertInPatternsFromSheet = workbookUtil.getInsertInPatternsFromSheet(DictionaryConstants.INSERT_IN_PATTERN);
				for(ListTO insertInPatternTO:insertInPatternsFromSheet){
					tempinsertInPatterns.add(insertInPatternTO.getName());
				}			
				masterMap.put("key", tempinsertInPatterns);
			}
			
			/*List<String> tempAttributes = new ArrayList<String>();
			List<AttributeTO> attributesFromSheet = workbookUtil.getAttributesFromSheet(DictionaryConstants.ATTRIBUTE);
			for(AttributeTO attributesTO:attributesFromSheet){
				tempAttributes.add(attributesTO.getName());
			}			
			masterMap.put("attribute", tempAttributes);*/
			model.put(GeneralConstants.MA_TEXT_CACHE_RESULT_MAP, masterMap);
			
		} catch (TextParserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return "cacheDetail";
	}
	
	@RequestMapping(value="/showTableData", method = RequestMethod.GET)
	public String showTableData(ModelMap model, HttpServletRequest request) {
		String component = request.getParameter("component");
		MasterViewTO masterViewTO= new MasterViewTO();
		try {
			List<ListTO<String>> listTOs = workbookUtil.getListsFromSheet(DictionaryConstants.LIST);
			for (ListTO listTO : listTOs){
				if(listTO.getName().equalsIgnoreCase(component)){
					masterViewTO.setTabName("List");
					masterViewTO.setElementName(component);
					masterViewTO.getListTOs().add(listTO);
				}					
			}
		} catch (TextParserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.put("masterViewTO", masterViewTO);
		return "showTableData";
	}
	
	@RequestMapping(value="/updatedData", method = RequestMethod.GET)
	public String getUpdatedData(ModelMap model, HttpServletRequest request) {
		String rowIdx = request.getParameter("rowIdx");
		String cellValue = request.getParameter("cellValue");
		String sheetName = request.getParameter("sheetName");
		String columnIdx = request.getParameter("columnIdx");
		
		System.out.println("parameter------------------------"+cellValue);
		System.out.println("parameter------------------------"+rowIdx);
		System.out.println("parameter------------------------"+sheetName);
		System.out.println("parameter------------------------"+columnIdx);
		return null;}
	
}
