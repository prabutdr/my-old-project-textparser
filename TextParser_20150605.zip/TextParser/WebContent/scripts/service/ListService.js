var ListServicesModule = angular.module("ListServicesModule", []);

var getAllListSummaryURL = "list/getAllSummary.json";
var deleteListURL = "list/delete.json";
	
ListServicesModule.factory("ListService", ["$http", function($http) {
	listDetail = {
		lists: [],
		errorText: ""
	};
	
	function getAllListSummary() {
		$http.get(getAllListSummaryURL)
		.success(function(data, status, headers, config) {
			listDetail.lists = data;
		})
		.error(function(data, status, headers, config) {
			listDetail.errorText = "Unable to load dictionary lists, please try again later.";
		});
		
		return listDetail;
	}
	
	function deleteList(list) {
		$http.post(deleteListURL, list)
		.success(function(data, status, headers, config) {
			removeFromArray(listDetail.lists, list);
			listDetail.errorText = "Successfully deleted";
		})
		.error(function(data, status, headers, config) {
			listDetail.errorText = "Unable to delete the list from dictionary, please try again later.";
		});
	}
	
	return {
		getAllListSummary: getAllListSummary,
		deleteList: deleteList
	};
}]);

function removeFromArray(array, value) {
    var idx = array.indexOf(value);
    if (idx !== -1) {
        array.splice(idx, 1);
    }
    return array;
}	

