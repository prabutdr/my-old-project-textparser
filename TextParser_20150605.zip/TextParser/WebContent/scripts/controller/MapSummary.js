DictionaryAdminModule.controller("MapSummaryController", ["$scope", function($scope) {
	
}]);