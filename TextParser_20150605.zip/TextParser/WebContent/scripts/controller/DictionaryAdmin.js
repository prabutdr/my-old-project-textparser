/**
 * Defining angular module - DictionaryAdminModule
 */
var DictionaryAdminModule = angular.module("DictionaryAdminModule", ["ngRoute", "ListServicesModule"]);

/**
 * Routing configuration for DictionaryAdminModule
 */
DictionaryAdminModule.config(["$routeProvider", function($routeProvider) {
	$routeProvider.
		when('/list', {
			templateUrl: "../templates/lists.html",
			controller: 'ListSummaryController'
		}).
		when('/map', {
			templateUrl: "../templates/maps.html",
			controller: 'MapSummaryController'
		}).
		otherwise(
				{redirectTo: 'list'}
		);
}]);

DictionaryAdminModule.controller("DictionaryAdminController", ["$scope", function($scope) {
	$scope.dictionaryItems = [
	    {
	    	name: "List",
	    	routeUrl: "#/list"
	    },
	    {
	    	name: "Map",
	    	routeUrl: "#/map"
	    }
	];
			
}]);

