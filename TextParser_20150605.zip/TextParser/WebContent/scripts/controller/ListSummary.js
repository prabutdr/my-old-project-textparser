DictionaryAdminModule.controller("ListSummaryController", ["$scope", "ListService", function($scope, listService) {
	$scope.listDetail =	listService.getAllListSummary();
	
	$scope.deleteList = function(list) {
		var response = window.confirm("Are you sure to delete this list?");
		if (response == true) {
			listService.deleteList(list);
		}
	};
	
}]);

