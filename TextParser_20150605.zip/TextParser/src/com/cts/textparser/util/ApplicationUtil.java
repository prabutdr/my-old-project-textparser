/**
 * 
 */
package com.cts.textparser.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.cts.textparser.cache.DictionaryCache;
import com.cts.textparser.constant.ErrorConstants;
import com.cts.textparser.constant.GeneralConstants;
import com.cts.textparser.constant.RegexConstants;
import com.cts.textparser.to.ParsedAttributeItem;
import com.cts.textparser.to.PatternTO;
import com.cts.textparser.to.RegExTO;
import com.cts.textparser.to.TextParserExceptionTO;
import com.cts.textparser.to.TextParserTO;

/**
 * Utility class to define common methods for this application
 * 
 * @author 153093
 *
 */
@Component("applicationUtil")
public class ApplicationUtil {

	private static final Logger LOGGER = Logger.getLogger(ApplicationUtil.class);
	
	/**
	 * To hold list of result codes & descriptions
	 */
	@Autowired(required = true)
	@Qualifier("resultCodeProperties")
	private Properties resultCodeProperties;
	
	/**
	 * Dictionary cache to hold dictionary lists
	 */
	@Autowired(required = true)
	@Qualifier("dictionaryFactory")
	private DictionaryFactory dictionaryFactory;

	
	/**
	 * Method to add new parsed attribute value to transfer object
	 * 
	 * @param	textParserTO
	 * @param 	attributeName
	 * @param 	attributeIdx
	 * @param 	attributeValue
	 */
	public static void addAttributeValue(TextParserTO textParserTO, String attributeName, Integer attributeIdx, String attributeValue) {
		Map<Integer, ParsedAttributeItem> attributeMap = textParserTO.getAttribute(attributeName);
		attributeMap.put(attributeIdx, new ParsedAttributeItem(attributeValue));
	}

	/**
	 * Method to add new parsed sub attribute value to transfer object
	 * 
	 * @param groupAttributeItem
	 * @param subAttrbuteName
	 * @param subAttributeMap
	 */
//	public static void addSubAttributeValue(ParsedAttributeItem groupAttributeItem, String subAttrbuteName, 
//			Map<Integer, ParsedAttributeItem> subAttributeMap) {
//		Map<String, Map<Integer, ParsedAttributeItem>> subAttributes = groupAttributeItem.getSubAttributes();
//		Map<Integer, ParsedAttributeItem> attributeMap = subAttributes.get(subAttrbuteName);
//		if(attributeMap == null) {
//			subAttributes.put(subAttrbuteName, subAttributeMap);
//		}
//		else {
//			attributeMap.putAll(subAttributeMap);
//		}
//	}

	/**
	 * Method to add new parsed sub attribute value to transfer object
	 * 
	 * @param groupAttributeItem
	 * @param subAttrbuteName
	 * @param subAttributeIdx
	 * @param subAttributeValue
	 */
//	public static void addSubAttributeValue(ParsedAttributeItem groupAttributeItem, String subAttrbuteName, 
//			Integer subAttributeIdx, String subAttributeValue) {
//		Map<String, Map<Integer, ParsedAttributeItem>> subAttributes = groupAttributeItem.getSubAttributes();
//		Map<Integer, ParsedAttributeItem> subAttributeMap = subAttributes.get(subAttrbuteName);
//		if(subAttributeMap == null) {
//			subAttributeMap = new TreeMap<>();
//			subAttributes.put(subAttrbuteName, subAttributeMap);
//		}
//		subAttributeMap.put(subAttributeIdx, new ParsedAttributeItem(subAttributeValue));
//	}

	/**
	 * Method to remove a parsed sub attribute from group attribute 
	 * 
	 * @param 	groupAttributeItem
	 * @param 	subAttrbuteName
	 * @return
	 */
//	public static Map<Integer, ParsedAttributeItem> removeSubAttribute(ParsedAttributeItem groupAttributeItem, String subAttrbuteName) {
//		Map<String, Map<Integer, ParsedAttributeItem>> subAttributes = groupAttributeItem.getSubAttributes();
//		return subAttributes.remove(subAttrbuteName);
//	}

	/**
	 * To retrieve a attribute from transfer object
	 * 
	 * @param textParserTO
	 * @param attributeName
	 * 
	 * @return
	 */
	public static Map<Integer, ParsedAttributeItem> getAttribute(TextParserTO textParserTO, String attributeName) {
		return textParserTO.getAttribute(attributeName);
	}

	/**
	 * To retrieve result code description from property file
	 * 
	 * @param 	resultCode
	 * 
	 * @return	result description for result code
	 */
	public String getResultDescription(String resultCode) {
		return resultCodeProperties.getProperty(resultCode);
	}
	
	/**
	 * Helper method to build application exception with given error code & cause 
	 * 
	 * @param 	resultCode
	 * @param 	cause
	 * 
	 * @return	Application exception which is built
	 */
	public TextParserException buildTextParserException(String resultCode, TextParserTO textParserTO, Throwable cause) {
		
		// Build fault info
		TextParserExceptionTO textParserExceptionTO = new TextParserExceptionTO();
		textParserExceptionTO.setResultCode(StringUtils.isBlank(resultCode)? ErrorConstants.RUNTIME_EXCEPTION: resultCode);
		textParserExceptionTO.setResultDescription(this.getResultDescription(textParserExceptionTO.getResultCode()));
		textParserExceptionTO.setTextParserTO(textParserTO);
		
		// Build application exception
		TextParserException exception;
		if (cause == null) {
			exception = new TextParserException(textParserExceptionTO.getResultDescription(), textParserExceptionTO);
		} else {
			exception = new TextParserException(textParserExceptionTO.getResultDescription(), textParserExceptionTO, cause);
		}
		
		return exception;
	}

	/**
	 * Helper method to build application exception with given error code 
	 * 
	 * @param 	resultCode
	 * 
	 * @return	Application exception which is built
	 */
	public TextParserException buildTextParserException(String resultCode) {
		return this.buildTextParserException(resultCode, null, null);
	}
	
	/**
	 * Helper method to build application exception with given error code & textParserTO
	 * 
	 * @param 	resultCode
	 * @param	textParserTO
	 * 
	 * @return	Application exception which is built
	 */
	public TextParserException buildTextParserException(String resultCode, TextParserTO textParserTO) {
		return this.buildTextParserException(resultCode, textParserTO, null);
	}
	
	/**
	 * Helper method to build application exception with given error code & cause
	 * 
	 * @param 	resultCode
	 * @param 	cause
	 * 
	 * @return	Application exception which is built
	 */
	public TextParserException buildTextParserException(String resultCode, Throwable cause) {
		return this.buildTextParserException(resultCode, null, cause);
	}
	
	/**
	 * Build & initialize {@link TextParserTO} object using given input text
	 * 
	 * @param 	inputText
	 * 
	 * @return
	 * @throws TextParserException 
	 */
	public TextParserTO buildTextParserTO(String inputText) throws TextParserException {
		LOGGER.debug("Building new text parser transfer object starts...");
		if(StringUtils.isBlank(inputText)) {
			// Not a valid input
			throw buildTextParserException(ErrorConstants.INPUT_TEXT_MISSING);
		}
		
		// Build attribute empty maps per configuration
		Map<String, Map<Integer, ParsedAttributeItem>> attributes = new HashMap<String, Map<Integer, ParsedAttributeItem>>();
		Map<Integer, ParsedAttributeItem> attribute;
		for(String attributeName: dictionaryFactory.getAttributeNames()) {
			attribute = new TreeMap<Integer, ParsedAttributeItem>();
			attributes.put(attributeName, attribute);
		}
		

		// Validate & set input text into attribute map
		Map<Integer, ParsedAttributeItem> inputTextAttribute = attributes.get(GeneralConstants.ATTRIBUTE_INPUT_TEXT);
		if (inputTextAttribute == null) {
			// input text attribute not found in the attribute map
			throw buildTextParserException(ErrorConstants.INPUT_TEXT_ATTR_MISSING);
		}
		// Set input text into attribute map
		inputTextAttribute.put(GeneralConstants.DEFAULT_POSITION_INDEX, new ParsedAttributeItem(inputText));
		
		// Place attribute map in transfer object
		TextParserTO textParserTO = new TextParserTO();
		textParserTO.setAttributes(attributes);
		
		LOGGER.debug("Building new text parser transfer object ends.");
		return textParserTO;
	}
	
	/**
	 * Method to get list of patterns for PatternTO
	 * 
	 * @param 	patternTO
	 * 
	 * @return	List of formed patterns
	 * 
	 * @throws 	TextParserException
	 */
	public List<Pattern> buildPatterns(PatternTO patternTO) throws TextParserException {
		List<Pattern> patternList = new ArrayList<>();
		Collection<String> prefixList = dictionaryFactory.getStringCollection(patternTO.getPrefixRegEx());
		Collection<String> valueList = dictionaryFactory.getStringCollection(patternTO.getContentText());
		Collection<String> suffixList = dictionaryFactory.getStringCollection(patternTO.getSuffixRegEx());
		
		// Form pattern combinations
		for(String prefix: prefixList) {
			for(String value: valueList) {
				for(String suffix: suffixList) {
					patternList.add(Pattern.compile(prefix + Pattern.quote(value) + suffix));
				}
			}
		}
		
		return patternList;
	}
	
	/**
	 * To build equivalent patternTO list for regExDictionaryCache 
	 * 
	 * @param 	regExDictionaryCache
	 * @return
	 * @throws 	TextParserException
	 */
	public List<PatternTO> buildPatternsFromRegExCache(DictionaryCache<String, RegExTO> regExDictionaryCache) throws TextParserException {
		List<PatternTO> patternTOList = new ArrayList<>();
		PatternTO patternTO;
		RegExTO regExTO;
		for(String regExName: regExDictionaryCache.getKeys()) {
			regExTO = regExDictionaryCache.get(regExName);
			patternTO = new PatternTO();
			
			patternTO.setName(regExTO.getName());
			patternTO.setDescription(regExTO.getDescription());
			patternTO.setPrefixRegEx(regExTO.getValue());
			patternTO.setContentText(GeneralConstants.EMPTY_STRING);
			patternTO.setSuffixRegEx(GeneralConstants.EMPTY_STRING);
			patternTO.setValue(buildPatterns(patternTO));	
			patternTOList.add(patternTO);
		}
		return patternTOList;
	}

    /**
     * Helper method to calculate interval values from given range.
     * Example - 
     * 	1) Range is 1	- Interval is 1
     * 	2) Range is 5	- Interval is 1
     * 	3) Range is 3 to 5	- Interval is 3
     * 	4) Range is 4 to 1	- Interval is 4
     * 
     * @param range
     * @return
     */
    public static Double getIntervalFromRange(String range) {
    	Double attributeValueLow, attributeValueHigh;
		Matcher matcher = RegexConstants.PATTERN_NUMERIC.matcher(range);
	    
		if(matcher.find()) {
			// Parse low value from range
			attributeValueLow = Double.valueOf(range.substring(matcher.start(), matcher.end()));
			
			if(matcher.find(matcher.end())) {
				// Parse high value if any
				attributeValueHigh = Double.valueOf(range.substring(matcher.start(), matcher.end()));
				// Calculate interval and send it back
				return Math.abs(attributeValueHigh - attributeValueLow) + 1;
			}
			else {
				// Only low value found, then return default interval (usually 1)
				return GeneralConstants.DEFAULT_INTERVAL_FOR_RANGE;
			}
		}
		else {
			// No numeric pattern found, means invalid
			return null;
		}
    }
}
