/**
 * 
 */
package com.cts.textparser.util;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.cts.textparser.constant.ActiveInd;
import com.cts.textparser.constant.DictionaryConstants;
import com.cts.textparser.constant.ErrorConstants;
import com.cts.textparser.constant.SortInd;
import com.cts.textparser.dto.ListDTO;

/**
 * Utility class to hold methods to perform read/write operations
 * from dictionary workbook
 * 
 * @author 153093
 * 
 */
@Component("workbookDAO")
public class WorkbookDAO {

	private static final Logger LOGGER = Logger.getLogger(WorkbookDAO.class); 

	/**
	 * Resource to hold file reference of dictionary file
	 */
	@Value("${textparser.dictionary.file}")
	private String workbookFile;
	
	@Autowired(required = true)
	@Qualifier("applicationUtil")
	private ApplicationUtil applicationUtil;
	
	/**
	 * Cell data formatter to parse cell values from work book
	 */
	private static final DataFormatter DATAFORMATTER = new DataFormatter();
	
	
	/**
	 * Method to get configured dictionary lists (only details, not entire list data)
	 * 
	 * @return	List of ListDTO objects which represent the complete lists.
	 * 
	 * @throws 	TextParserException 
	 */
	public List<ListDTO> getAllListSummary() throws TextParserException {
		List<ListDTO> listDTOs = new ArrayList<>();
		FileInputStream workbookFIS = null;
		
		try {
			workbookFIS = new FileInputStream(workbookFile);
			HSSFWorkbook workbook = new HSSFWorkbook(workbookFIS);
			HSSFSheet sheet = workbook.getSheet(DictionaryConstants.LIST);
			
			if(sheet == null) {
				LOGGER.debug("getAllListDetails - Sheet name not found in the workbook");
				throw applicationUtil.buildTextParserException(ErrorConstants.UNABLE_TO_READ_WRITE_FROM_WORKBOOK);
			}
			
			// Iterate through sheet and get ListTO items if any
			HSSFRow row = sheet.getRow(0);
			if(row != null) {
				int columnIdx = 0;
				String cellValue = DATAFORMATTER.formatCellValue(row.getCell(columnIdx));
				ListDTO listDTO;
				while(StringUtils.isNotBlank(cellValue)) {
					listDTO = getListSummary(sheet, columnIdx);
					if(listDTO.getActiveInd() == ActiveInd.YES) {
						listDTOs.add(listDTO);
					}
					
					columnIdx += 2;
					cellValue = DATAFORMATTER.formatCellValue(row.getCell(columnIdx));
				}
			}
			LOGGER.debug("getAllListDetails - Completed - List Count - " + listDTOs.size());
		} catch (Exception e) {
			LOGGER.debug("Exception occurred", e);
			throw applicationUtil.buildTextParserException(ErrorConstants.UNABLE_TO_READ_WRITE_FROM_WORKBOOK, null, e);
		} finally {
			try {
				if (workbookFIS != null) {
					workbookFIS.close();
				}
			} catch (IOException e) {
				LOGGER.debug("IOException occurred in finally", e);
				throw applicationUtil.buildTextParserException(ErrorConstants.UNABLE_TO_READ_WRITE_FROM_WORKBOOK, null, e);
			}
		}
		
		return listDTOs;
	}		

	/**
	 * Helper method to read a list summary details from given sheet & column index
	 * 
	 * @param 	sheet
	 * 			Sheet name in the work book
	 * 
	 * @param 	columnIdx
	 * 			Column index where list starts 
	 * 
	 * @return	ListDTO representation of the list
	 * 
	 */
	private ListDTO getListSummary(HSSFSheet sheet, int columnIdx) {
		ListDTO listDTO = new ListDTO();
		int rowIdx = 0;
		
		// To retrieve list properties
		listDTO.setIndex(columnIdx);
		listDTO.setName(DATAFORMATTER.formatCellValue(sheet.getRow(rowIdx++).getCell(columnIdx + 1)));
		listDTO.setDescription(DATAFORMATTER.formatCellValue(sheet.getRow(rowIdx++).getCell(columnIdx + 1)));
		String sortInd = DATAFORMATTER.formatCellValue(sheet.getRow(rowIdx++).getCell(columnIdx + 1));
		if(StringUtils.isBlank(sortInd)) {
			listDTO.setSortInd(SortInd.NO_SORT);
		}
		else {
			listDTO.setSortInd(SortInd.valueOf(sortInd));
		}
		String activeInd = DATAFORMATTER.formatCellValue(sheet.getRow(rowIdx++).getCell(columnIdx + 1));
		if(StringUtils.isBlank(activeInd)) {
			listDTO.setActiveInd(ActiveInd.YES);
		}
		else {
			listDTO.setActiveInd(ActiveInd.fromString(activeInd));
		}
		
		return listDTO;
	}
	
	public void deleteList(ListDTO listDTO) throws TextParserException {
		FileInputStream workbookFIS = null;
		FileOutputStream workbookFOS = null;
		
		try {
			workbookFIS = new FileInputStream(workbookFile);
			HSSFWorkbook workbook = new HSSFWorkbook(workbookFIS);
			HSSFSheet sheet = workbook.getSheet(DictionaryConstants.LIST);
			if(sheet == null) {
				LOGGER.debug("deleteList - Sheet name not found in the workbook");
				throw applicationUtil.buildTextParserException(ErrorConstants.UNABLE_TO_READ_WRITE_FROM_WORKBOOK);
			}
			
			sheet.getRow(3).createCell(listDTO.getIndex() + 1).setCellValue(ActiveInd.NO.getValue());
			
			workbookFOS = new FileOutputStream(workbookFile);
			workbook.write(workbookFOS);
			LOGGER.debug("deleteList - Completed");
		} catch (Exception e) {
			LOGGER.debug("Exception occurred", e);
			throw applicationUtil.buildTextParserException(ErrorConstants.UNABLE_TO_READ_WRITE_FROM_WORKBOOK, null, e);
		} finally {
			try {
				if (workbookFIS != null) {
					workbookFIS.close();
				}
				if (workbookFOS != null) {
					workbookFOS.close();
				}
			} catch (IOException e) {
				LOGGER.debug("IOException occurred in finally", e);
				throw applicationUtil.buildTextParserException(ErrorConstants.UNABLE_TO_READ_WRITE_FROM_WORKBOOK, null, e);
			}
		}
	}

}
