/**
 * 
 */
package com.cts.textparser.to;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;


/**
 * Transfer object to represent each parsed attribute value
 * 
 * @author 153093
 *
 */
public class ParsedAttributeItem {

	/**
	 * Parsed value
	 */
	private String value;
	
	/**
	 * Sub attribute values which are arrived from main attribute value
	 */
	private Map<String, String> subAttributes;
	
	
	public ParsedAttributeItem(String value) {
		this.value = value;
		subAttributes = new HashMap<String, String>();
	}
	
	public ParsedAttributeItem(ParsedAttributeItem attributeItem) {
		this(attributeItem.getValue());
	}
	
	/**
	 * 
	 */
	@Override
	public String toString() {
		return String.valueOf(value);
	}
	
	/**
	 * Describe properties as descriptive string
	 * 
	 */
	public String toDescString() {
		StringBuilder result = new StringBuilder();
		result.append(value);
		
		if(subAttributes != null && !subAttributes.isEmpty()) {
			result.append(" {");
			for(Entry<String, String> subAttributeEntry: subAttributes.entrySet()) {
				result.append(subAttributeEntry.getKey());
				result.append("=");
				result.append(subAttributeEntry.getValue());
				result.append("; ");
			}
			result.append("}");
		}
		
		return result.toString();
	}
	
	/**
	 * Method to add a sub attribute value
	 * 
	 * @param subAttrbuteName
	 * @param subAttrbuteValue
	 * 
	 * @return	Previous value if any for given name
	 */
	public String putSubAttributeValue(String subAttrbuteName, String subAttributeValue) {
		return subAttributes.put(subAttrbuteName, subAttributeValue);
	}

	/**
	 * Method to get a sub attribute value
	 * 
	 * @param 	subAttrbuteName
	 * 
	 * @return	match sub attribute value if any for given name
	 */
	public String getSubAttributeValue(String subAttrbuteName) {
		return subAttributes.get(subAttrbuteName);
	}

	/**
	 * Method to remove a sub attribute value 
	 * 
	 * @param subAttrbuteName
	 * 
	 * @return	Removed value if any for given name
	 */
	public String removeSubAttribute(String subAttrbuteName) {
		return subAttributes.remove(subAttrbuteName);
	}
	
	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * @return the subAttributes
	 */
	public Map<String, String> getSubAttributes() {
		return subAttributes;
	}

	/**
	 * @param subAttributes the subAttributes to set
	 */
	public void setSubAttributes(Map<String, String> subAttributes) {
		this.subAttributes = subAttributes;
	}
}
