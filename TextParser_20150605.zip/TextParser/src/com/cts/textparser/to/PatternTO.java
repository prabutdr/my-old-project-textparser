/**
 * 
 */
package com.cts.textparser.to;

import java.util.List;
import java.util.regex.Pattern;


/**
 * Transfer object to represent a pattern item
 * 
 * @author 153093
 *
 */
public class PatternTO extends DictionaryItem {

	/**
	 * Prefix regex
	 */
	private String prefixRegEx;
	
	/**
	 * Actual text value
	 */
	private String contentText;
	
	/**
	 * Suffix regex
	 */
	private String suffixRegEx;
	
	/**
	 * List of patterns formed from prefixRegEx + value + suffix 
	 */
	private List<Pattern> value;

	
	/**
	 * @return the prefixRegEx
	 */
	public String getPrefixRegEx() {
		return prefixRegEx;
	}

	/**
	 * @param prefixRegEx the prefixRegEx to set
	 */
	public void setPrefixRegEx(String prefixRegEx) {
		this.prefixRegEx = prefixRegEx;
	}

	/**
	 * @return the contentText
	 */
	public String getContentText() {
		return contentText;
	}

	/**
	 * @param contentText the contentText to set
	 */
	public void setContentText(String contentText) {
		this.contentText = contentText;
	}

	/**
	 * @return the suffixRegEx
	 */
	public String getSuffixRegEx() {
		return suffixRegEx;
	}

	/**
	 * @param suffixRegEx the suffixRegEx to set
	 */
	public void setSuffixRegEx(String suffixRegEx) {
		this.suffixRegEx = suffixRegEx;
	}

	/**
	 * @return the value
	 */
	public List<Pattern> getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(List<Pattern> value) {
		this.value = value;
	}
}
