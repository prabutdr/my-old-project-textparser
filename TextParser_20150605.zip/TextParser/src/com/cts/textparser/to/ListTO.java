/**
 * 
 */
package com.cts.textparser.to;

import java.util.ArrayList;
import java.util.List;

import com.cts.textparser.constant.ActiveInd;
import com.cts.textparser.constant.SortInd;
import com.cts.textparser.util.DictionaryUtil;

/**
 * Transfer object to represent list in data dictionary 
 * 
 * @author 153093
 *
 */
public class ListTO<T extends Comparable<T>> extends DictionaryItem {

	/**
	 * Actual list values
	 */
	private List<T> value;
	
	/**
	 * To specify sorting flag
	 */
	private SortInd sortInd;

	/**
	 * Indicator to specify whether this list in active
	 */
	private ActiveInd activeInd;
	
	
	/**
	 * @return the value
	 */
	public List<T> getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(List<T> value) {
		this.value = value;
		
		// Perform sort if required
		this.value = DictionaryUtil.sort(this.value, this.sortInd);
	}

	/**
	 * @return the sortInd
	 */
	public SortInd getSortInd() {
		return sortInd;
	}

	/**
	 * @param sortInd the sortInd to set
	 */
	public void setSortInd(SortInd sortInd) {
		this.sortInd = sortInd;
		
		// Perform sort if required
		this.value = DictionaryUtil.sort(this.value, this.sortInd);
	}

	/**
	 * @return the activeInd
	 */
	public ActiveInd getActiveInd() {
		return activeInd;
	}

	/**
	 * @param activeInd the activeInd to set
	 */
	public void setActiveInd(ActiveInd activeInd) {
		this.activeInd = activeInd;
	}

	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		list.add("Test");
		list.add("Another");
		list.add("dd");
		System.out.println("Result - " + list);
	}
}
