/**
 * 
 */
package com.cts.textparser.constant;

/**
 * @author 153093
 *
 */
public enum ModifyInd {
	NONE,
	ADD,
	DELETE,
	UPDATE
}
