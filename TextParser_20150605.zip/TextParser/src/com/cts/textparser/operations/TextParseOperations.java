/**
 * 
 */
package com.cts.textparser.operations;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.cts.textparser.constant.GeneralConstants;
import com.cts.textparser.to.ParsedAttributeItem;
import com.cts.textparser.to.TextParserTO;

/**
 * Utility class to hold methods which will do text parsing operations.
 * 
 * @author 153093
 *
 */
public class TextParseOperations {

	private static final Logger LOGGER = Logger.getLogger(TextParseOperations.class);

	/**
	 * This method will check given patterns in source attribute, if match found,
	 * then matched value will be tagged to target attribute map with identified
	 * position index (relative to source attribute index).  Also it will remove
	 * matched value from source attribute and will be filled with white-spaces. 
	 * 
	 * @param 	srcAttributeMap
	 * 
	 * @param 	destAttributeMap
	 * 
	 * @param 	patterns
	 * 
	 * @return	Result code
	 */
	public static String parseByPattern(final Map<Integer, ParsedAttributeItem> srcAttributeMap, final Map<Integer, ParsedAttributeItem> destAttributeMap, Collection<Pattern> patterns) {
		LOGGER.debug("Parse attribute by pattern starts... ");
		
		// Do it for all source attribute values
		Iterator<Entry<Integer, ParsedAttributeItem>> attributeMapIterator = srcAttributeMap.entrySet().iterator();
		String srcAttributeValue;
		while (attributeMapIterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> attributeEntry = attributeMapIterator.next();
			
			// Parse attribute by pattern for an attribute value
			srcAttributeValue = attributeEntry.getValue().getValue();
			srcAttributeValue = TextParseUtils.parseByPattern(attributeEntry.getKey(), srcAttributeValue, destAttributeMap, patterns);
			
			// Update back source attribute value
			attributeEntry.getValue().setValue(srcAttributeValue);
		}
		
		LOGGER.debug("Parse attribute by pattern ends.");
		return GeneralConstants.SUCCESS_RESULT_CODE;
	}
	
	/**
	 * This method will check given patterns in source attribute, if match found,
	 * then matched value will be tagged to sub attribute map with identified
	 * position index (relative to source attribute index).  
	 * 
	 * @param 	groupAttributeMap
	 * @param 	subAttrbuteName
	 * @param 	patterns
	 * @return	Result code
	 */
	public static String parseSubAttributeByPattern(final Map<Integer, ParsedAttributeItem> groupAttributeMap, 
			final String subAttrbuteName, Collection<Pattern> patterns) {
		LOGGER.debug("Parse sub attribute by pattern starts... ");
		
		// Do it for all source attribute values
		Iterator<Entry<Integer, ParsedAttributeItem>> attributeMapIterator = groupAttributeMap.entrySet().iterator();
		ParsedAttributeItem groupAttributeItem;
		while (attributeMapIterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> attributeEntry = attributeMapIterator.next();
			
			Map<Integer, ParsedAttributeItem> subAttributeMap = new TreeMap<>();
			
			// Parse attribute by pattern for an attribute value
			groupAttributeItem = attributeEntry.getValue();
			TextParseUtils.parseByPattern(attributeEntry.getKey(), groupAttributeItem.getValue(), subAttributeMap, patterns);
			
			if (!subAttributeMap.isEmpty()) {
				groupAttributeItem.putSubAttributeValue(subAttrbuteName, TextUtils.convertToString(subAttributeMap.values()));
			}
		}
		
		LOGGER.debug("Parse sub attribute by pattern ends.");
		return GeneralConstants.SUCCESS_RESULT_CODE;
	}
	
	/**
	 * This method will generate NGram phrases for source attribute and the generated token 
	 * are now considered one by one for matching with data dictionary map (key=attribute value, value=attribute name)
	 * starting with the largest N-Gram. Once the tokens are matched, the whole phrase will 
	 * be tagged into matched attribute and removed from the source attribute.  And N-Gram tokens 
	 * will be generated again for remaining text and the matching will proceed with rest 
	 * of the tokens for rest of the N-Grams. 
	 * 
	 * @param 	srcAttributeMap
	 * @param 	textParserTO
	 * @param 	dictionaryMap
	 * 
	 * @return	Result code
	 */
	public static String parseByDictionaryMap(final Map<Integer, ParsedAttributeItem> srcAttributeMap, final TextParserTO textParserTO, final Map<String, String> dictionaryMap) {
		LOGGER.debug("Parse attribute by dictionary map starts... ");
		
		// Do it for all source attribute values
		Iterator<Entry<Integer, ParsedAttributeItem>> attributeMapIterator = srcAttributeMap.entrySet().iterator();
		String srcAttributeValue;
		while (attributeMapIterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> attributeEntry = attributeMapIterator.next();
			
			// Parse attribute by dictionary map for an attribute value
			srcAttributeValue = attributeEntry.getValue().getValue();
			srcAttributeValue = TextParseUtils.parseByDictionaryMap(attributeEntry.getKey(), srcAttributeValue, textParserTO, dictionaryMap);
			
			// Update back source attribute value
			attributeEntry.getValue().setValue(srcAttributeValue);
		}
		
		LOGGER.debug("Parse attribute by dictionary map ends.");
		return GeneralConstants.SUCCESS_RESULT_CODE;
	}
	
	/**
	 * Method to check whether given search pattern found in source attribute,
	 * if found and between (can be before/after) given parsed attributes,
	 * then tag matched value into attribute. 
	 * 
	 * @param 	srcAttributeMap
	 * 
	 * @param 	targetAttributeMap
	 * 			Where to tag parsed matched value
	 * 			if targetAttributeMap is null & followingAttributeMap is not null, 
	 * 				then update following attribute value with matched value as prefix. 
	 * 			if targetAttributeMap is null & followingAttributeMap is also null, 
	 * 				then update precedingAttributeMap attribute value with matched value as suffix. 
	 * 
	 * @param 	patterns
	 * 			List of patterns to search
	 * 
	 * @param 	precedingAttributeMap
	 * 			Preceding parsed attribute value, can be null if no need to check preceding attributes.
	 * 
	 * @param 	followingAttributeMap
	 * 			Following parsed attribute value, can be null if no need to check following attributes.
	 * 
	 * @return	Result code
	 */
	public static String parsePatternBetweenAttributes(final Map<Integer, ParsedAttributeItem> srcAttributeMap,
			final Map<Integer, ParsedAttributeItem> targetAttributeMap,
			Collection<Pattern> patterns, final Map<Integer, ParsedAttributeItem> precedingAttributeMap, 
			final Map<Integer, ParsedAttributeItem> followingAttributeMap) {
		LOGGER.debug("Parse patterns between attributes starts... ");
		
		// Do it for all source attribute values
		Iterator<Entry<Integer, ParsedAttributeItem>> attributeMapIterator = srcAttributeMap.entrySet().iterator();
		String srcAttributeValue;
		while (attributeMapIterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> attributeEntry = attributeMapIterator.next();
			
			// Parse attribute by dictionary map for an attribute value
			srcAttributeValue = attributeEntry.getValue().getValue();
			srcAttributeValue = TextParseUtils.parsePatternBetweenAttributes(attributeEntry.getKey(), srcAttributeValue,
					targetAttributeMap, patterns, precedingAttributeMap, followingAttributeMap);
			
			// Update back source attribute value
			attributeEntry.getValue().setValue(srcAttributeValue);
		}
		
		LOGGER.debug("Parse patterns between attributes ends.");
		return GeneralConstants.SUCCESS_RESULT_CODE;
	}
	
	/**
	 * Method to check whether given search pattern found in source attribute,
	 * if found and between (can be before/after) given parsed attributes,
	 * then tag matched value into attribute. 
	 * 
	 * @param 	srcAttributeMap
	 * 
	 * @param 	targetAttributeMap
	 * 			Where to tag parsed matched value
	 * 			if targetAttributeMap is null & followingAttributeMap is not null, 
	 * 				then update following attribute value with matched value as prefix. 
	 * 			if targetAttributeMap is null & followingAttributeMap is also null, 
	 * 				then update precedingAttributeMap attribute value with matched value as suffix. 
	 * 
	 * @param 	patterns
	 * 			List of patterns to search
	 * 
	 * @param 	precedingAttributeMap
	 * 			Preceding parsed attribute value, can be null if no need to check preceding attributes.
	 * 
	 * @param 	precedingAttributeMap
	 * 			Preceding parsed attribute value, can be null if no need to check preceding attributes.
	 * 
	 * @param 	followingAttributeMap
	 * 			Following parsed attribute value, can be null if no need to check following attributes.
	 * 
	 * @param	followingAttributeValues
	 * 			Following parsed value should be present in the list if provided
	 * 
	 * @return	Result code
	 */
	public static String parsePatternBetweenAttributesWithValues(final Map<Integer, ParsedAttributeItem> srcAttributeMap,
			final Map<Integer, ParsedAttributeItem> targetAttributeMap,
			Collection<Pattern> patterns, final Map<Integer, ParsedAttributeItem> precedingAttributeMap, Collection<String> precedingAttributeValues,
			final Map<Integer, ParsedAttributeItem> followingAttributeMap, Collection<String> followingAttributeValues) {
		LOGGER.debug("Parse patterns between attributes (with specific values) starts... ");
		
		// Do it for all source attribute values
		Iterator<Entry<Integer, ParsedAttributeItem>> attributeMapIterator = srcAttributeMap.entrySet().iterator();
		String srcAttributeValue;
		while (attributeMapIterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> attributeEntry = attributeMapIterator.next();
			
			// Parse attribute by dictionary map for an attribute value
			srcAttributeValue = attributeEntry.getValue().getValue();
			srcAttributeValue = TextParseUtils.parsePatternBetweenAttributesWithValues(attributeEntry.getKey(), srcAttributeValue,
					targetAttributeMap, patterns, precedingAttributeMap, precedingAttributeValues, followingAttributeMap, followingAttributeValues);
			
			// Update back source attribute value
			attributeEntry.getValue().setValue(srcAttributeValue);
		}
		
		LOGGER.debug("Parse patterns between attributes (with specific values) ends.");
		return GeneralConstants.SUCCESS_RESULT_CODE;
	}
	
	/**
	 * Method to check whether given search pattern found in remaining unparsed text,
	 * if found and between (can be before/after) given value, then tag matched value into attribute. 
	 * 
	 * @param 	srcAttributeMap
	 * 
	 * @param 	targetAttributeMap
	 * 			Where to tag parsed matched value
	 * 
	 * @param 	referenceAttributeMap
	 *			Reference attribute to see preceding/following parsed values 
	 *			(if null, srcAttributeMap will be considered as referenceAttributeMap)			
	 * 
	 * @param 	patterns
	 * 			Search pattern to see
	 * 
	 * @param 	precedingValues
	 * 			Preceding value list, can be null if no need to check preceding attributes.
	 * 			
	 * @param 	followingValues
	 * 			Following value list, can be null if no need to check following attributes.
	 * 
	 * @return	Result code
	 */
	public static String parsePatternBetweenValues(final Map<Integer, ParsedAttributeItem> srcAttributeMap, final Map<Integer, ParsedAttributeItem> targetAttributeMap, 
			final Map<Integer, ParsedAttributeItem> referenceAttributeMap,
			Collection<Pattern> patterns, Collection<String> precedingValues,
			Collection<String> followingValues) {
		LOGGER.debug("Parse patterns between values starts... ");
		
		// Do it for all source attribute values
		Iterator<Entry<Integer, ParsedAttributeItem>> attributeMapIterator = srcAttributeMap.entrySet().iterator();
		String srcAttributeValue, refernceAttributeValue;
		while (attributeMapIterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> attributeEntry = attributeMapIterator.next();
			
			// Parse attribute by dictionary map for an attribute value
			srcAttributeValue = attributeEntry.getValue().getValue();
			refernceAttributeValue = (referenceAttributeMap == null || referenceAttributeMap.get(attributeEntry.getKey()) == null)? null:
				referenceAttributeMap.get(attributeEntry.getKey()).getValue();
			srcAttributeValue = TextParseUtils.parsePatternBetweenValues(attributeEntry.getKey(), srcAttributeValue, 
					targetAttributeMap, refernceAttributeValue, patterns, precedingValues, followingValues);
			
			// Update back source attribute value
			attributeEntry.getValue().setValue(srcAttributeValue);
		}
		
		LOGGER.debug("Parse patterns between values ends.");
		return GeneralConstants.SUCCESS_RESULT_CODE;
	}

	/**
	 * This method will check given values in source attribute, if match found,
	 * then matched value will be tagged to target attribute map with identified
	 * position index (relative to source attribute index).  Also it will remove
	 * matched value from source attribute and will be filled with white-spaces. 
	 * 
	 * @param 	srcAttributeMap
	 * 
	 * @param 	destAttributeMap
	 * 
	 * @param 	patterns
	 * 
	 * @return	Result code
	 */
	public static String parseByValue(final Map<Integer, ParsedAttributeItem> srcAttributeMap, final Map<Integer, ParsedAttributeItem> destAttributeMap, Collection<String> values) {
		LOGGER.debug("Parse attribute by value starts... ");
		
		// Do it for all source attribute values
		Iterator<Entry<Integer, ParsedAttributeItem>> attributeMapIterator = srcAttributeMap.entrySet().iterator();
		String srcAttributeValue;
		while (attributeMapIterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> attributeEntry = attributeMapIterator.next();
			
			// Parse attribute by pattern for an attribute value
			srcAttributeValue = attributeEntry.getValue().getValue();
			srcAttributeValue = TextParseUtils.parseByValue(attributeEntry.getKey(), srcAttributeValue, destAttributeMap, values);
			
			// Update back source attribute value
			attributeEntry.getValue().setValue(srcAttributeValue);
		}
		
		LOGGER.debug("Parse attribute by value ends.");
		return GeneralConstants.SUCCESS_RESULT_CODE;
	}
	
	/**
	 * Method to check whether given search value found in source attribute,
	 * if found and between (can be before/after) given parsed attributes,
	 * then tag matched value into attribute. 
	 * 
	 * @param 	srcAttributeMap
	 * 
	 * @param 	targetAttributeMap
	 * 			Where to tag parsed matched value
	 * 			if targetAttributeMap is null & followingAttributeMap is not null, 
	 * 				then update following attribute value with matched value as prefix. 
	 * 			if targetAttributeMap is null & followingAttributeMap is also null, 
	 * 				then update precedingAttributeMap attribute value with matched value as suffix. 
	 * 
	 * @param 	values
	 * 			Collection of values to search
	 * 
	 * @param 	precedingAttributeMap
	 * 			Preceding parsed attribute value, can be null if no need to check preceding attributes.
	 * 
	 * @param 	followingAttributeMap
	 * 			Following parsed attribute value, can be null if no need to check following attributes.
	 * 
	 * @return	Result code
	 */
	public static String parseValueBetweenAttributes(final Map<Integer, ParsedAttributeItem> srcAttributeMap,
			final Map<Integer, ParsedAttributeItem> targetAttributeMap,
			Collection<String> values, final Map<Integer, ParsedAttributeItem> precedingAttributeMap, 
			final Map<Integer, ParsedAttributeItem> followingAttributeMap) {
		LOGGER.debug("Parse values between attributes starts... ");
		
		// Do it for all source attribute values
		Iterator<Entry<Integer, ParsedAttributeItem>> attributeMapIterator = srcAttributeMap.entrySet().iterator();
		String srcAttributeValue;
		while (attributeMapIterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> attributeEntry = attributeMapIterator.next();
			
			// Parse attribute by dictionary map for an attribute value
			srcAttributeValue = attributeEntry.getValue().getValue();
			srcAttributeValue = TextParseUtils.parseValueBetweenAttributes(attributeEntry.getKey(), srcAttributeValue,
					targetAttributeMap, values, precedingAttributeMap, followingAttributeMap);
			
			// Update back source attribute value
			attributeEntry.getValue().setValue(srcAttributeValue);
		}
		
		LOGGER.debug("Parse values between attributes ends.");
		return GeneralConstants.SUCCESS_RESULT_CODE;
	}
	
	/**
	 * Method to check whether given search values found in source attribute,
	 * if found and between (can be before/after) given parsed attributes,
	 * then tag matched value into attribute. 
	 * 
	 * @param 	srcAttributeMap
	 * 
	 * @param 	targetAttributeMap
	 * 			Where to tag parsed matched value
	 * 			if targetAttributeMap is null & followingAttributeMap is not null, 
	 * 				then update following attribute value with matched value as prefix. 
	 * 			if targetAttributeMap is null & followingAttributeMap is also null, 
	 * 				then update precedingAttributeMap attribute value with matched value as suffix. 
	 * 
	 * @param 	values
	 * 			List of values to search
	 * 
	 * @param 	precedingAttributeMap
	 * 			Preceding parsed attribute value, can be null if no need to check preceding attributes.
	 * 
	 * @param 	precedingAttributeMap
	 * 			Preceding parsed attribute value, can be null if no need to check preceding attributes.
	 * 
	 * @param 	followingAttributeMap
	 * 			Following parsed attribute value, can be null if no need to check following attributes.
	 * 
	 * @param	followingAttributeValues
	 * 			Following parsed value should be present in the list if provided
	 * 
	 * @return	Result code
	 */
	public static String parseValueBetweenAttributesWithValues(final Map<Integer, ParsedAttributeItem> srcAttributeMap,
			final Map<Integer, ParsedAttributeItem> targetAttributeMap,
			Collection<String> values, final Map<Integer, ParsedAttributeItem> precedingAttributeMap, Collection<String> precedingAttributeValues,
			final Map<Integer, ParsedAttributeItem> followingAttributeMap, Collection<String> followingAttributeValues) {
		LOGGER.debug("Parse values between attributes (with specific values) starts... ");
		
		// Do it for all source attribute values
		Iterator<Entry<Integer, ParsedAttributeItem>> attributeMapIterator = srcAttributeMap.entrySet().iterator();
		String srcAttributeValue;
		while (attributeMapIterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> attributeEntry = attributeMapIterator.next();
			
			// Parse attribute by dictionary map for an attribute value
			srcAttributeValue = attributeEntry.getValue().getValue();
			srcAttributeValue = TextParseUtils.parseValueBetweenAttributesWithValues(attributeEntry.getKey(), srcAttributeValue,
					targetAttributeMap, values, precedingAttributeMap, precedingAttributeValues, followingAttributeMap, followingAttributeValues);
			
			// Update back source attribute value
			attributeEntry.getValue().setValue(srcAttributeValue);
		}
		
		LOGGER.debug("Parse values between attributes (with specific values) ends.");
		return GeneralConstants.SUCCESS_RESULT_CODE;
	}
	
}
