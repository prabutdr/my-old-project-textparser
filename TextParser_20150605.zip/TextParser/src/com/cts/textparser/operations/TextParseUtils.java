/**
 * 
 */
package com.cts.textparser.operations;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.cts.textparser.constant.GeneralConstants;
import com.cts.textparser.constant.RegexConstants;
import com.cts.textparser.to.ParsedAttributeItem;
import com.cts.textparser.to.TextParserTO;
import com.cts.textparser.util.ApplicationUtil;

/**
 * Utility class to hold methods which will do text operations.
 * 
 * @author 153093
 *
 */
public class TextParseUtils {

	private static final Logger LOGGER = Logger.getLogger(TextParseUtils.class);

	/**
	 * This method will check given patterns in source attribute, if match found,
	 * then matched value will be tagged to target attribute map with identified
	 * position index (relative to source attribute index).  Also it will remove
	 * matched value from source attribute and will be filled with white-spaces. 
	 * 
	 * @param srcAttributeIdx
	 * @param srcAttributeValue
	 * @param destAttributeMap
	 * @param patterns
	 * 
	 * @return	Remaining unparsed text
	 */
	public static String parseByPattern(Integer srcAttributeIdx, String srcAttributeValue, final Map<Integer, ParsedAttributeItem> destAttributeMap, Collection<Pattern> patterns) {
		if (StringUtils.isBlank(srcAttributeValue)) {
			LOGGER.debug("Parse attribute by pattern - Skipping as no text to parse.");
			return srcAttributeValue;
		}
		
		StringBuilder intermediateText = new StringBuilder(srcAttributeValue);
		srcAttributeIdx = (srcAttributeIdx == GeneralConstants.DEFAULT_POSITION_INDEX)? 0: srcAttributeIdx;	// Update source index for calculation if it default one
		Matcher matcher;
		
		for (Pattern pattern: patterns) { 
		    matcher = pattern.matcher(intermediateText);
		    
		    while (matcher.find()) {
		    	// Fetch matched attribute value and its position
		    	String attributeValue = intermediateText.substring(matcher.start(), matcher.end()).trim();
		    	int attributeIdx = intermediateText.indexOf(attributeValue, matcher.start());

		    	// Store matched attribute value in destination attribute map
		    	destAttributeMap.put((srcAttributeIdx + attributeIdx), new ParsedAttributeItem(attributeValue));
		    	
		    	// Remove matched attribute from the input and fill with white spaces
		    	intermediateText.replace(attributeIdx, attributeIdx + attributeValue.length(), 
		    			StringUtils.repeat(GeneralConstants.SPACE_STRING, attributeValue.length()));

				// build matcher again with updated string
		    	matcher = pattern.matcher(intermediateText);
		    }
		    
			if(StringUtils.isBlank(intermediateText.toString())) {
				LOGGER.debug("Parse attribute by pattern - No more remaining tokens to parse."); 
				break;
			}
		}
		
		return intermediateText.toString();
	}

	/**
	 * This method will generate NGram phrases for source attribute and the generated token 
	 * are now considered one by one for matching with data dictionary map (key=attribute value, value=attribute name)
	 * starting with the largest N-Gram. Once the tokens are matched, the whole phrase will 
	 * be tagged into matched attribute and removed from the source attribute.  And N-Gram tokens 
	 * will be generated again for remaining text and the matching will proceed with rest 
	 * of the tokens for rest of the N-Grams. 
	 * 
	 * @param 	srcAttributeIdx
	 * @param 	srcAttributeValue
	 * @param 	textParserTO
	 * @param 	dictionaryMap
	 * 
	 * @return	Remaining unparsed text
	 */
	public static String parseByDictionaryMap(Integer srcAttributeIdx, String srcAttributeValue, final TextParserTO textParserTO, final Map<String, String> dictionaryMap) {
		String attributeName, attributeValue;
		int attributeIdx, endIdx;
		boolean isTextModified;
		
		srcAttributeIdx = (srcAttributeIdx == GeneralConstants.DEFAULT_POSITION_INDEX)? 0: srcAttributeIdx;	// Update source index for calculation if it default one
		List<String> phraseList = generateNGramTokensForPhrases(srcAttributeValue);
		StringBuilder intermediateText = new StringBuilder(srcAttributeValue);
		
		for(int phraseListIdx = 0; phraseListIdx < phraseList.size(); phraseListIdx++) {
			attributeValue = phraseList.get(phraseListIdx);
			
			if(dictionaryMap.containsKey(attributeValue)) {
				endIdx = 0;
				isTextModified = false;
				while((attributeIdx = intermediateText.indexOf(attributeValue, endIdx)) != -1) {
					endIdx = attributeIdx + attributeValue.length();
					
					if(((attributeIdx <= 0) || (!Character.isLetter(intermediateText.charAt(attributeIdx - 1)) && !Character.isDigit(intermediateText.charAt(attributeIdx - 1))))
							&& ((endIdx >= intermediateText.length()) || (!Character.isLetter(intermediateText.charAt(endIdx)) && !Character.isDigit(intermediateText.charAt(endIdx))))) {
						attributeName = dictionaryMap.get(attributeValue);
						 
				    	// Store matched attribute value in destination attribute map
						ApplicationUtil.addAttributeValue(textParserTO, attributeName, (srcAttributeIdx + attributeIdx), attributeValue);
				    	
				    	// Remove matched attribute from the input and fill with white spaces
						intermediateText.replace(attributeIdx, attributeIdx + attributeValue.length(), 
				    			StringUtils.repeat(GeneralConstants.SPACE_STRING, attributeValue.length()));
				    	isTextModified = true;
					}
				}
				
				if(isTextModified) {
					if(StringUtils.isBlank(intermediateText.toString())) {
						break;
					}

					phraseList = generateNGramTokensForPhrases(intermediateText.toString());
					phraseListIdx = -1;
				}
			}
		}
		
		return intermediateText.toString();
	}
	
	/**
	 * Method to generate possible phrases for parser from given input string using N-Gram technique.  
	 * If more than two white spaces found between phrases then, this method will consider
	 * it as two different sentence, so it will split then do generate possible NGram phrases separately
	 * for each sentence.  Means while generate phrases it won't combine words between
	 * two different sentence. 
	 *  
	 * @return 	List of phrases starting from "nGramSize" words phrases to 1 word phrases.
	 * 
	 */
	private static final List<String> generateNGramTokensForPhrases(String input) {
		if(input == null) {
			return null;
		}
		
		String[] tokens = input.split(RegexConstants.TWO_OR_MORE_WHITE_SPACE);
		List<String> phrasesList = new ArrayList<>();
		
		for(String token: tokens) {
			phrasesList.addAll(generateNGramTokens(token, 0));
		}
		
		return phrasesList;
	}

	/**
	 * Method to generate possible phrases from given input string using N-Gram technique.  
	 * The input is being converted into a series of combination of words known as N-Grams 
	 * where "N" is the number of words we are taking together for making a combination. 
	 * The combinations will be linear one, starting from the beginning word of the sentence 
	 * till the end. 
	 * 
	 * Eg. TAKE 1 TABLET DAILY will be converted into N-Gram (N=4) Tokens list as follows:
	 * 		TAKE 1 TABLET DAILY
	 * 		TAKE 1 TABLET
	 * 		1 TABLET DAILY
	 * 		TAKE 1
	 * 		1 TABLET
	 * 		TABLET DAILY
	 * 		TAKE
	 * 		1
	 * 		TABLET
	 * 		DAILY
	 * 
	 * @param 	input
	 * 			input string which needs to be tokenized
	 * 
	 * @param 	nGramSize
	 * 			Maximum words in splitted tokens
	 * 			if it is 0, then nGramSize will be number of words in input
	 * 
	 * @return 	List of phrases starting from "nGramSize" words phrases to 1 word phrases (see example above).
	 * 
	 * @throws	IllegalArgumentException
	 * 			If given nGramSize not valid (mean less than 0)
	 */
	private static final List<String> generateNGramTokens(String input, int nGramSize) {
		if(input == null) {
			return null;
		}
		if(nGramSize < 0) {
			throw new IllegalArgumentException("nGramSize should be greater than or equal to zero");
		}
		
		String[] tokens = input.split(RegexConstants.ONE_OR_MORE_WHITE_SPACE);
		List<String> phrasesList = new ArrayList<String>();
		StringBuilder buffer;
		
		for (int curNGramSize = (nGramSize == 0 || nGramSize > tokens.length)? tokens.length: nGramSize; curNGramSize >= 1; curNGramSize--) {
			int endIdx = tokens.length - curNGramSize;
			for (int startTokenIdx = 0; startTokenIdx <= endIdx; startTokenIdx++) {
				buffer = new StringBuilder();
				for(int currentTokenIdx = 0; currentTokenIdx < curNGramSize; currentTokenIdx++) {
					buffer.append(tokens[startTokenIdx + currentTokenIdx] + GeneralConstants.SPACE_STRING);
				}

				phrasesList.add(buffer.toString().trim());
			}
		}
		
		return phrasesList;
	}
	
	/**
	 * Method to check whether given search pattern found in source attribute,
	 * if found and between (can be before/after) given parsed attributes,
	 * then tag matched value into attribute. 
	 * 
	 * @param 	srcAttributeIdx
	 * @param 	srcAttributeValue
	 * 
	 * @param 	targetAttributeMap
	 * 			Where to tag parsed matched value
	 * 			if targetAttributeMap is null & followingAttributeMap is not null, 
	 * 				then update following attribute value with matched value as prefix. 
	 * 			if targetAttributeMap is null & followingAttributeMap is also null, 
	 * 				then update precedingAttributeMap attribute value with matched value as suffix. 
	 * 
	 * @param 	patterns
	 * 			List of patterns to search
	 * 
	 * @param 	precedingAttributeMap
	 * 			Preceding parsed attribute value, can be null if no need to check preceding attributes.
	 * 
	 * @param 	followingAttributeMap
	 * 			Following parsed attribute value, can be null if no need to check following attributes.
	 * 
	 * @return	Remaining unparsed text
	 */
	public static String parsePatternBetweenAttributes(Integer srcAttributeIdx, String srcAttributeValue, 
			final Map<Integer, ParsedAttributeItem> targetAttributeMap,
			Collection<Pattern> patterns, final Map<Integer, ParsedAttributeItem> precedingAttributeMap, 
			final Map<Integer, ParsedAttributeItem> followingAttributeMap) {
		return parsePatternBetweenAttributesWithValues(srcAttributeIdx, srcAttributeValue, targetAttributeMap, 
				patterns, precedingAttributeMap, null, followingAttributeMap, null);
	}
	
	/**
	 * Method to check whether given search pattern found in source attribute,
	 * if found and between (can be before/after) given parsed attributes,
	 * then tag matched value into attribute. 
	 * 
	 * @param 	srcAttributeIdx
	 * @param 	srcAttributeValue
	 * 
	 * @param 	targetAttributeMap
	 * 			Where to tag parsed matched value
	 * 			if targetAttributeMap is null & followingAttributeMap is not null, 
	 * 				then update following attribute value with matched value as prefix. 
	 * 			if targetAttributeMap is null & followingAttributeMap is also null, 
	 * 				then update precedingAttributeMap attribute value with matched value as suffix. 
	 * 
	 * @param 	patterns
	 * 			List of patterns to search
	 * 
	 * @param 	precedingAttributeMap
	 * 			Preceding parsed attribute value, can be null if no need to check preceding attributes.
	 * 
	 * @param	precedingAttributeValues
	 * 			Preceding parsed value should be present in the list if provided
	 * 
	 * @param 	followingAttributeMap
	 * 			Following parsed attribute value, can be null if no need to check following attributes.
	 * 
	 * @param	followingAttributeValues
	 * 			Following parsed value should be present in the list if provided
	 * 
	 * @return	Remaining unparsed text
	 */
	public static String parsePatternBetweenAttributesWithValues(Integer srcAttributeIdx, String srcAttributeValue, 
			final Map<Integer, ParsedAttributeItem> targetAttributeMap,
			Collection<Pattern> patterns, final Map<Integer, ParsedAttributeItem> precedingAttributeMap, Collection<String> precedingAttributeValues,
			final Map<Integer, ParsedAttributeItem> followingAttributeMap, Collection<String> followingAttributeValues) {

		if (StringUtils.isBlank(srcAttributeValue)) {
			LOGGER.debug("Parse pattern between attributes - Skipping as no tokens to parse.");
			return srcAttributeValue;
		}

		if (precedingAttributeMap == null
				&& followingAttributeMap == null) {
			throw new IllegalArgumentException("Either preceding or following attribute map is required.");
		}
		
	    String attributeValue;
		boolean isPrecedingAttributeFound, isFollowingAttributeFound; 
	    int findStartIdx, precedingAttributeIdx, followingAttributeIdx, attributeIdx;
		
		StringBuilder intermediateText = new StringBuilder(srcAttributeValue);
		srcAttributeIdx = (srcAttributeIdx == GeneralConstants.DEFAULT_POSITION_INDEX)? 0: srcAttributeIdx;	// Update source index for calculation if it default one
		
		PATTERN_LOOP:
		for(Pattern pattern: patterns) {
			// Search pattern available
		    Matcher matcher = pattern.matcher(intermediateText);
		    findStartIdx = 0;
		    while(matcher.find(findStartIdx)) {
		    	findStartIdx = matcher.end();
	
		    	// Get preceding & following attribute positions
		    	precedingAttributeIdx = indexOfEndsWithAttribute(srcAttributeIdx + matcher.start(), precedingAttributeMap);
		    	// Preceding attribute value should be present in given values list if present
		    	if (precedingAttributeIdx != -1 && precedingAttributeValues != null && precedingAttributeValues.size() > 0) {
		    		if (!precedingAttributeValues.contains(precedingAttributeMap.get(precedingAttributeIdx).getValue())) {
		    			precedingAttributeIdx = -1;
		    		}
		    	}
		    	followingAttributeIdx = indexOfStartsWithAttribute(srcAttributeIdx + matcher.end(), followingAttributeMap);	
		    	// Following attribute value should be present in given values list if present
		    	if (followingAttributeIdx != -1 && followingAttributeValues != null && followingAttributeValues.size() > 0) {
		    		if (!followingAttributeValues.contains(followingAttributeMap.get(followingAttributeIdx).getValue())) {
		    			followingAttributeIdx = -1;
		    		}
		    	}
				
		    	isPrecedingAttributeFound = (precedingAttributeMap == null)? true: (precedingAttributeIdx != -1);
		    	isFollowingAttributeFound = (followingAttributeMap == null)? true: (followingAttributeIdx != -1);
		    			
				// If preceding & following attribute check success 
				if(isPrecedingAttributeFound && isFollowingAttributeFound) {
			    	// Fetch match value and its position
			    	attributeValue = intermediateText.substring(matcher.start(), matcher.end()).trim();
			    	attributeIdx = intermediateText.indexOf(attributeValue, matcher.start());
	
			    	// Remove matched value from the input and fill with white spaces
			    	intermediateText.replace(attributeIdx, attributeIdx + attributeValue.length(), 
			    			StringUtils.repeat(GeneralConstants.SPACE_STRING, attributeValue.length()));
	
			    	if(targetAttributeMap != null) {
				    	// Target attribute provided in the input, then tag match value to target attribute
			    		targetAttributeMap.put((srcAttributeIdx + attributeIdx), new ParsedAttributeItem(attributeValue));
			    	}
			    	else if(followingAttributeMap != null) {
			    		// No target attribute provided and following attribute present, then prefix match value to following attribute
						attributeValue = attributeValue + GeneralConstants.SPACE_STRING + followingAttributeMap.get(followingAttributeIdx).getValue();
			    		followingAttributeMap.remove(followingAttributeIdx);
			    		followingAttributeMap.put((srcAttributeIdx + attributeIdx), new ParsedAttributeItem(attributeValue));
			    	}
			    	else if(precedingAttributeMap != null) {
			    		// No target & following attribute provided, then suffix match value to preceding attribute
						attributeValue = precedingAttributeMap.get(precedingAttributeIdx).getValue() + GeneralConstants.SPACE_STRING + attributeValue;
			    		precedingAttributeMap.remove(precedingAttributeIdx);
			    		precedingAttributeMap.put(precedingAttributeIdx, new ParsedAttributeItem(attributeValue));
			    	}
					
					if(StringUtils.isBlank(intermediateText.toString())) {
						LOGGER.debug("Parse pattern between attributes - No more remaining tokens to parse."); 
						break PATTERN_LOOP;
					}
			    	// build matcher again with updated string
			    	matcher = pattern.matcher(intermediateText);
		    	}
		    }
		}
		
		return intermediateText.toString();
	}
	
	/**
	 * Method to check whether given attribute value found at end of given end index. 
	 * If found return index of that attribute value, otherwise return -1
	 *  
	 * @param endIdx
	 * @param attributeValueMap
	 * @return
	 */
	private static int indexOfEndsWithAttribute(int endIdx, final Map<Integer, ParsedAttributeItem> attributeValueMap) {
		if(attributeValueMap == null) {
			return -1;
		}
		
		int endIdxOfAttribute;
		// Iterate through attribute values
		for(Entry<Integer, ParsedAttributeItem> entry: attributeValueMap.entrySet()) {
			// Calculate end index of a attribute using its value
			endIdxOfAttribute = entry.getKey() + entry.getValue().getValue().length();
			if(endIdx == endIdxOfAttribute + 1
					|| endIdx == endIdxOfAttribute) {	
				// Given end index is matching with calculated end index, considering single whitespace / end of line 
				return entry.getKey();
			}
		}

		return -1;
	}
	
	/**
	 * Method to check whether given attribute value found at start of given start index (or +1 consider a whitespace). 
	 * If found return index of that attribute value, otherwise return -1 
	 * 
	 * @param startIdx
	 * @param attributeValueMap
	 * @return
	 */
	private static int indexOfStartsWithAttribute(int startIdx, final Map<Integer, ParsedAttributeItem> attributeValueMap) {
		if(attributeValueMap == null) {
			return -1;
		}
		
		if (attributeValueMap.containsKey(startIdx)) {
			return startIdx;
		}
		startIdx = startIdx + 1;
		if (attributeValueMap.containsKey(startIdx)) {
			return startIdx;
		}
		
		return -1;
	}
	
	/**
	 * Method to check whether given search pattern found in remaining unparsed text,
	 * if found and between (can be before/after) given value, then tag matched value into attribute. 
	 * 
	 * @param 	srcAttributeIdx
	 * @param 	srcAttributeValue
	 * 
	 * @param 	targetAttributeMap
	 * 			Where to tag parsed matched value
	 * 
	 * @param 	referenceAttributeValue
	 *			Reference attribute to see preceding/following parsed values 
	 *			(if null, srcAttributeValue will be considered as referenceAttributeValue)			
	 * 
	 * @param 	patterns
	 * 			Search pattern to see
	 * 
	 * @param 	precedingValues
	 * 			Preceding value list, can be null if no need to check preceding attributes.
	 * 			
	 * @param 	followingValues
	 * 			Following value list, can be null if no need to check following attributes.
	 * 
	 * @return	Remaining unparsed text
	 */
	public static String parsePatternBetweenValues(Integer srcAttributeIdx, String srcAttributeValue,
			final Map<Integer, ParsedAttributeItem> targetAttributeMap, String referenceAttributeValue, Collection<Pattern> patterns, Collection<String> precedingValues,
			Collection<String> followingValues) {

		if (StringUtils.isBlank(srcAttributeValue)) {
			LOGGER.debug("Parse pattern between attributes - Skipping as no tokens to parse.");
			return srcAttributeValue;
		}

		if (precedingValues == null 
				&& followingValues == null) {
			throw new IllegalArgumentException("Either preceding or following values are required.");
		}
		
	    String attributeValue;
		boolean isPrecedingValueFound, isFollowingValueFound; 
	    int findStartIdx, attributeIdx;
		
		StringBuilder intermediateText = new StringBuilder(srcAttributeValue);
		srcAttributeIdx = (srcAttributeIdx == GeneralConstants.DEFAULT_POSITION_INDEX)? 0: srcAttributeIdx;	// Update source index for calculation if it default one
		referenceAttributeValue = (referenceAttributeValue == null)? srcAttributeValue: referenceAttributeValue;
		
		PATTERN_LOOP:
		for(Pattern pattern: patterns) {
		    Matcher matcher = pattern.matcher(intermediateText);
		    findStartIdx = 0;
		    while(matcher.find(findStartIdx)) {
				findStartIdx = matcher.end();

				// Fetch match value and its position
		    	attributeValue = intermediateText.substring(matcher.start(), matcher.end()).trim();
		    	attributeIdx = intermediateText.indexOf(attributeValue, matcher.start());
	
		    	// Check whether any preceding & following value present 
		    	isPrecedingValueFound = (precedingValues == null)? true: endsWith(referenceAttributeValue, attributeIdx - 1, precedingValues);
		    	isFollowingValueFound = (followingValues == null)? true: startsWith(referenceAttributeValue, attributeIdx + attributeValue.length(), followingValues);
		    			
				// If preceding & following value check success 
				if(isPrecedingValueFound && isFollowingValueFound) {
			    	// Remove matched value from the input and fill with white spaces
					intermediateText.replace(attributeIdx, attributeIdx + attributeValue.length(), 
			    			StringUtils.repeat(GeneralConstants.SPACE_STRING, attributeValue.length()));
	
			    	//tag match value to target attribute
		    		targetAttributeMap.put((srcAttributeIdx + attributeIdx), new ParsedAttributeItem(attributeValue));
			    	
					if(StringUtils.isBlank(intermediateText.toString())) {
						// No more remaining tokens to parse
						LOGGER.debug("Parse pattern between values - No more remaining tokens to parse."); 
						break PATTERN_LOOP;	
					}
					
			    	// build matcher again with updated string
			    	matcher = pattern.matcher(intermediateText);
		    	}
		    }
		}
		return intermediateText.toString();
	}		
	    
	/**
	 * Method to check whether input has either one of listed values
	 * with end index equivalent to atIndex 
	 * 
	 * @param input
	 * @param atIndex
	 * @param values
	 * @return
	 */
	private static boolean endsWith(String input, int atIndex, Collection<String> values) {
		if(values == null || atIndex < 0 || atIndex >= input.length()) {
			return false;
		}
		
		int startIdx;
		input = input.substring(0, atIndex + 1).trim();
		
		for(String value: values) {
			startIdx = input.length() - value.length();
			if(input.endsWith(value)
					&& (startIdx == 0 || Character.isWhitespace(input.charAt(startIdx - 1)))) {
				return true;
			}
		}
		
		return false;
	}

	/**
	 * Method to check whether input has either one of listed values
	 * with end index equivalent to atIndex 
	 * 
	 * @param input
	 * @param atIndex
	 * @param values
	 * @return
	 */
	private static boolean startsWith(String input, int atIndex, Collection<String> values) {
		if(values == null || atIndex < 0 || atIndex >= input.length()) {
			return false;
		}
		
		int endIdx;
		input = input.substring(atIndex).trim();
		
		for(String value: values) {
			endIdx = value.length();
			if(input.startsWith(value)
					&& (endIdx == input.length() || Character.isWhitespace(input.charAt(endIdx)))) {
				return true;
			}
		}
		
		return false;
	}

	/**
	 * This method will check given values in source attribute, if match found,
	 * then matched value will be tagged to target attribute map with identified
	 * position index (relative to source attribute index).  Also it will remove
	 * matched value from source attribute and will be filled with white-spaces. 
	 * 
	 * @param srcAttributeIdx
	 * @param srcAttributeValue
	 * @param destAttributeMap
	 * @param values
	 * 
	 * @return	Remaining unparsed text
	 */
	public static String parseByValue(Integer srcAttributeIdx, String srcAttributeValue, final Map<Integer, ParsedAttributeItem> destAttributeMap, Collection<String> values) {
		if (StringUtils.isBlank(srcAttributeValue)) {
			LOGGER.debug("Parse attribute by pattern - Skipping as no text to parse.");
			return srcAttributeValue;
		}
		
		StringBuilder intermediateText = new StringBuilder(srcAttributeValue);
		srcAttributeIdx = (srcAttributeIdx == GeneralConstants.DEFAULT_POSITION_INDEX)? 0: srcAttributeIdx;	// Update source index for calculation if it default one
		int startIdx, endIdx;
		
		VALUE_LOOP:
		for (String value: values) {
			endIdx = 0;
			  
			while((startIdx = intermediateText.indexOf(value, endIdx)) != -1) {
				endIdx = startIdx + value.length();
				if(((startIdx == 0) || (!Character.isLetter(intermediateText.charAt(startIdx - 1)) && !Character.isDigit(intermediateText.charAt(startIdx - 1))))
						&& ((endIdx == intermediateText.length()) || (!Character.isLetter(intermediateText.charAt(endIdx)) && !Character.isDigit(intermediateText.charAt(endIdx))))) {
					// Remove matched attribute from the input and fill with white spaces
					intermediateText.replace(startIdx, endIdx, 
							StringUtils.repeat(GeneralConstants.SPACE_STRING, value.length()));

			    	// Store matched attribute value in destination attribute map
			    	destAttributeMap.put((srcAttributeIdx + startIdx), new ParsedAttributeItem(value));

					if(StringUtils.isBlank(intermediateText.toString())) {
						LOGGER.debug("Parse attribute by value - No more remaining tokens to parse."); 
						break VALUE_LOOP;
					}
				}
			}
		}
		
		return intermediateText.toString();
	}

	/**
	 * Method to check whether given search value found in source attribute,
	 * if found and between (can be before/after) given parsed attributes,
	 * then tag matched value into attribute. 
	 * 
	 * @param 	srcAttributeIdx
	 * @param 	srcAttributeValue
	 * 
	 * @param 	targetAttributeMap
	 * 			Where to tag parsed matched value
	 * 			if targetAttributeMap is null & followingAttributeMap is not null, 
	 * 				then update following attribute value with matched value as prefix. 
	 * 			if targetAttributeMap is null & followingAttributeMap is also null, 
	 * 				then update precedingAttributeMap attribute value with matched value as suffix. 
	 * 
	 * @param 	values
	 * 			Collection of values to search
	 * 
	 * @param 	precedingAttributeMap
	 * 			Preceding parsed attribute value, can be null if no need to check preceding attributes.
	 * 
	 * @param 	followingAttributeMap
	 * 			Following parsed attribute value, can be null if no need to check following attributes.
	 * 
	 * @return	Remaining unparsed text
	 */
	public static String parseValueBetweenAttributes(Integer srcAttributeIdx, String srcAttributeValue, 
			final Map<Integer, ParsedAttributeItem> targetAttributeMap,
			Collection<String> values, final Map<Integer, ParsedAttributeItem> precedingAttributeMap, 
			final Map<Integer, ParsedAttributeItem> followingAttributeMap) {
		return parseValueBetweenAttributesWithValues(srcAttributeIdx, srcAttributeValue, targetAttributeMap, 
				values, precedingAttributeMap, null, followingAttributeMap, null);
	}
	
	/**
	 * Method to check whether given search values found in source attribute,
	 * if found and between (can be before/after) given parsed attributes,
	 * then tag matched value into attribute. 
	 * 
	 * @param 	srcAttributeIdx
	 * @param 	srcAttributeValue
	 * 
	 * @param 	targetAttributeMap
	 * 			Where to tag parsed matched value
	 * 			if targetAttributeMap is null & followingAttributeMap is not null, 
	 * 				then update following attribute value with matched value as prefix. 
	 * 			if targetAttributeMap is null & followingAttributeMap is also null, 
	 * 				then update precedingAttributeMap attribute value with matched value as suffix. 
	 * 
	 * @param 	values
	 * 			Collection of values to search
	 * 
	 * @param 	precedingAttributeMap
	 * 			Preceding parsed attribute value, can be null if no need to check preceding attributes.
	 * 
	 * @param	precedingAttributeValues
	 * 			Preceding parsed value should be present in the list if provided
	 * 
	 * @param 	followingAttributeMap
	 * 			Following parsed attribute value, can be null if no need to check following attributes.
	 * 
	 * @param	followingAttributeValues
	 * 			Following parsed value should be present in the list if provided
	 * 
	 * @return	Remaining unparsed text
	 */
	public static String parseValueBetweenAttributesWithValues(Integer srcAttributeIdx, String srcAttributeValue, 
			final Map<Integer, ParsedAttributeItem> targetAttributeMap,
			Collection<String> values, final Map<Integer, ParsedAttributeItem> precedingAttributeMap, Collection<String> precedingAttributeValues,
			final Map<Integer, ParsedAttributeItem> followingAttributeMap, Collection<String> followingAttributeValues) {

		if (StringUtils.isBlank(srcAttributeValue)) {
			LOGGER.debug("Parse pattern between attributes - Skipping as no tokens to parse.");
			return srcAttributeValue;
		}

		if (precedingAttributeMap == null
				&& followingAttributeMap == null) {
			throw new IllegalArgumentException("Either preceding or following attribute map is required.");
		}
		
		boolean isPrecedingAttributeFound, isFollowingAttributeFound; 
	    int precedingAttributeIdx, followingAttributeIdx;
		
		StringBuilder intermediateText = new StringBuilder(srcAttributeValue);
		srcAttributeIdx = (srcAttributeIdx == GeneralConstants.DEFAULT_POSITION_INDEX)? 0: srcAttributeIdx;	// Update source index for calculation if it default one

		int startIdx, endIdx;
		
		VALUE_LOOP:
		for (String value: values) {
			endIdx = 0;
			  
			while((startIdx = intermediateText.indexOf(value, endIdx)) != -1) {
				endIdx = startIdx + value.length();
				if(((startIdx == 0) || (!Character.isLetter(intermediateText.charAt(startIdx - 1)) && !Character.isDigit(intermediateText.charAt(startIdx - 1))))
						&& ((endIdx == intermediateText.length()) || (!Character.isLetter(intermediateText.charAt(endIdx)) && !Character.isDigit(intermediateText.charAt(endIdx))))) {

			    	// Get preceding & following attribute positions
			    	precedingAttributeIdx = indexOfEndsWithAttribute(srcAttributeIdx + startIdx, precedingAttributeMap);
			    	// Preceding attribute value should be present in given values list if present
			    	if (precedingAttributeIdx != -1 && precedingAttributeValues != null && precedingAttributeValues.size() > 0) {
			    		if (!precedingAttributeValues.contains(precedingAttributeMap.get(precedingAttributeIdx).getValue())) {
			    			precedingAttributeIdx = -1;
			    		}
			    	}
			    	followingAttributeIdx = indexOfStartsWithAttribute(srcAttributeIdx + endIdx, followingAttributeMap);	
			    	// Following attribute value should be present in given values list if present
			    	if (followingAttributeIdx != -1 && followingAttributeValues != null && followingAttributeValues.size() > 0) {
			    		if (!followingAttributeValues.contains(followingAttributeMap.get(followingAttributeIdx).getValue())) {
			    			followingAttributeIdx = -1;
			    		}
			    	}
					
			    	isPrecedingAttributeFound = (precedingAttributeMap == null)? true: (precedingAttributeIdx != -1);
			    	isFollowingAttributeFound = (followingAttributeMap == null)? true: (followingAttributeIdx != -1);
			    			
					// If preceding & following attribute check success 
					if(isPrecedingAttributeFound && isFollowingAttributeFound) {
						// Remove matched attribute from the input and fill with white spaces
						intermediateText.replace(startIdx, endIdx, 
								StringUtils.repeat(GeneralConstants.SPACE_STRING, value.length()));

				    	if(targetAttributeMap != null) {
					    	// Target attribute provided in the input, then tag match value to target attribute
				    		targetAttributeMap.put((srcAttributeIdx + startIdx), new ParsedAttributeItem(value));
				    	}
				    	else if(followingAttributeMap != null) {
				    		// No target attribute provided and following attribute present, then prefix match value to following attribute
				    		value = value + GeneralConstants.SPACE_STRING + followingAttributeMap.get(followingAttributeIdx).getValue();
				    		followingAttributeMap.remove(followingAttributeIdx);
				    		followingAttributeMap.put((srcAttributeIdx + startIdx), new ParsedAttributeItem(value));
				    	}
				    	else if(precedingAttributeMap != null) {
				    		// No target & following attribute provided, then suffix match value to preceding attribute
				    		value = precedingAttributeMap.get(precedingAttributeIdx).getValue() + GeneralConstants.SPACE_STRING + value;
				    		precedingAttributeMap.remove(precedingAttributeIdx);
				    		precedingAttributeMap.put(precedingAttributeIdx, new ParsedAttributeItem(value));
				    	}
						
						if(StringUtils.isBlank(intermediateText.toString())) {
							LOGGER.debug("Parse value between attributes - No more remaining tokens to parse."); 
							break VALUE_LOOP;
						}
					}
				}
			}
		}
		
		return intermediateText.toString();
	}
	
}
