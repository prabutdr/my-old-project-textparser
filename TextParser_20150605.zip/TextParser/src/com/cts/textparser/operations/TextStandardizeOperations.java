/**
 * 
 */
package com.cts.textparser.operations;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;

import com.cts.textparser.constant.GeneralConstants;
import com.cts.textparser.to.InsertInPatternItem;
import com.cts.textparser.to.ParsedAttributeItem;
import com.cts.textparser.to.ReplaceInPatternItem;

/**
 * Utility class to hold methods which will do text standardize operations.
 * 
 * @author 153093
 *
 */
public class TextStandardizeOperations {

	private static final Logger LOGGER = Logger.getLogger(TextStandardizeOperations.class);

	/**
	 * Method to convert attribute values into upper case
	 * 
	 * @param 	attributeName
	 * 			Target attribute name to be modified
	 * 
	 * @param 	textParserTO
	 * 			Internal transfer object which holds all attribute maps
	 * 
	 * @return	Result code
	 */
	public static String convertToUpperCase(final Map<Integer, ParsedAttributeItem> attributeMap) {
		LOGGER.debug("Convert to upper case starts... ");
		
		// Convert all attribute values to upper case and store them back into attribute value map
		Iterator<Entry<Integer, ParsedAttributeItem>> attributeMapIterator = attributeMap.entrySet().iterator();
		while (attributeMapIterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> attributeEntry = attributeMapIterator.next();
			attributeEntry.getValue().setValue(attributeEntry.getValue().getValue().toUpperCase());
		}
		
		LOGGER.debug("Convert to upper case ends.");
		return GeneralConstants.SUCCESS_RESULT_CODE;
	}

	/**
	 * Method to replace special character sequences as configured in properties file.
	 * For example, this method can be used to introduce white-space before & after certain special 
	 * character sequences.
	 * 
	 * @param 	attributeMap
	 * 			Target attribute map to be modified.
	 * 			
	 * @param 	replacePatternMap
	 * 			Pattern map to be applied
	 * 
	 * @return	Result code
	 */
	public static String replacePattern(final Map<Integer, ParsedAttributeItem> attributeMap, final Map<String, String> replacePatternMap) {
		LOGGER.debug("Replace pattern starts... ");
		
		// Apply rule for all attribute values
		Iterator<Entry<Integer, ParsedAttributeItem>> attributeMapIterator = attributeMap.entrySet().iterator();
		while (attributeMapIterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> attributeEntry = attributeMapIterator.next();
			
			// Replace char sequences as per pattern map configured
			String attributeValue = attributeEntry.getValue().getValue();
			for(Entry<String, String> replacePatternEntry: replacePatternMap.entrySet()) {
				attributeValue = attributeValue.replaceAll(replacePatternEntry.getKey(), replacePatternEntry.getValue());
			}
			
			// Place modified attribute value back to attribute map
			attributeEntry.getValue().setValue(attributeValue);
		}
		
		LOGGER.debug("Replace pattern ends.");
		return GeneralConstants.SUCCESS_RESULT_CODE;		
	}

	/**
	 * Method to identify certain patterns and replace certain expression
	 * within that identified pattern.  For example, identify comma which is 
	 * used in numeric representation, and then replace them with empty string.
	 * 
	 * @param 	attributeMap
	 * 			Target attribute map to be modified.
	 * 
	 * @param 	replaceInPatternItemList
	 * 
	 * @return	Result code
	 */
	public static String replaceInPattern(final Map<Integer, ParsedAttributeItem> attributeMap, final List<ReplaceInPatternItem> replaceInPatternItemList) {
		LOGGER.debug("Replace in pattern starts... ");
		
		// Apply rule for all attribute values
		Iterator<Entry<Integer, ParsedAttributeItem>> attributeMapIterator = attributeMap.entrySet().iterator();
		while (attributeMapIterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> attributeEntry = attributeMapIterator.next();
			
			// Apply replace in pattern rule one by one
			String attributeValue = attributeEntry.getValue().getValue();
			for(ReplaceInPatternItem replaceInPatternItem: replaceInPatternItemList) {
				attributeValue = TextUtils.replaceInPattern(attributeValue, replaceInPatternItem);
			}
			
			// Place modified attribute value back to attribute map
			attributeEntry.getValue().setValue(attributeValue);
		}
		
		LOGGER.debug("Replace in pattern ends.");
		return GeneralConstants.SUCCESS_RESULT_CODE;		
	}
	
	/**
	 * Method to identify certain patterns and insert certain text at specified position
	 * within that identified pattern.  For example, identify "D24" and insert space
	 * after "D".
	 * 
	 * @param 	attributeMap
	 * 			Target attribute map to be modified.
	 * 
	 * @param 	insertInPatternItemList
	 * 
	 * @return	Result code
	 */
	public static String insertInPattern(final Map<Integer, ParsedAttributeItem> attributeMap, final List<InsertInPatternItem> insertInPatternItemList) {
		LOGGER.debug("Insert in pattern starts... ");
		
		// Apply rule for all attribute values
		Iterator<Entry<Integer, ParsedAttributeItem>> attributeMapIterator = attributeMap.entrySet().iterator();
		while (attributeMapIterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> attributeEntry = attributeMapIterator.next();
			
			// Apply insert in pattern rule one by one
			String attributeValue = attributeEntry.getValue().getValue();
			for(InsertInPatternItem insertInPatternItem: insertInPatternItemList) {
				attributeValue = TextUtils.insertInPattern(attributeValue, insertInPatternItem);
			}
			
			// Place modified attribute value back to attribute map
			attributeEntry.getValue().setValue(attributeValue);
		}
		
		LOGGER.debug("Insert in pattern ends.");
		return GeneralConstants.SUCCESS_RESULT_CODE;		
	}
	
	/**
	 * This method will replace all phrases with substitute value in the given
	 * input string.  This method will not replace partial phrases, means this
	 * will replace only if phrases NOT combined with alphanumeric characters. 
	 * 
	 * @param 	attributeMap
	 * 			Target attribute map to be modified.
	 * 
	 * @param 	phraseMap
	 * 
	 * @return	Result code
	 */
	public static String replacePhrases(final Map<Integer, ParsedAttributeItem> attributeMap, final Map<String, String> phraseMap) {
		LOGGER.debug("Replace phrases starts... ");
		
		// Apply rule for all attribute values
		Iterator<Entry<Integer, ParsedAttributeItem>> attributeMapIterator = attributeMap.entrySet().iterator();
		while (attributeMapIterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> attributeEntry = attributeMapIterator.next();
			
			// Place modified attribute value back to attribute map
			attributeEntry.getValue().setValue(TextUtils.replacePhrases(attributeEntry.getValue().getValue(), phraseMap));
		}
		
		LOGGER.debug("Replace phrases ends.");
		return GeneralConstants.SUCCESS_RESULT_CODE;		
	}
	
	/**
	 * This method will replace all number words (like TWO, HUNDRED) with equivalent digit
	 * substitute value in given target attribute.  
	 * 
	 * @param 	attributeMap
	 * 			Target attribute map to be modified.
	 * 
	 * @return	Result code
	 */
	public static String convertNumberWordsToDigits(final Map<Integer, ParsedAttributeItem> attributeMap) {
		LOGGER.debug("Convert number words to digits starts... ");
		
		// Apply rule for all attribute values
		Iterator<Entry<Integer, ParsedAttributeItem>> attributeMapIterator = attributeMap.entrySet().iterator();
		while (attributeMapIterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> attributeEntry = attributeMapIterator.next();
			
			// Place modified attribute value back to attribute map
			attributeEntry.getValue().setValue(NumberUtils.convertNumberWordsToDigits(attributeEntry.getValue().getValue()));
		}
		
		LOGGER.debug("Convert number words to digits ends.");
		return GeneralConstants.SUCCESS_RESULT_CODE;		
	}
	
	/**
	 * This method will replace all fractions (like 1/2, 1 4/7) with equivalent decimal
	 * substitute value in given target attribute.  
	 * 
	 * @param 	attributeMap
	 * 			Target attribute map to be modified.
	 * 
	 * @return	Result code
	 */
	public static String convertFractionsToDecimal(final Map<Integer, ParsedAttributeItem> attributeMap) {
		LOGGER.debug("Convert fractions to decimal starts... ");
		
		// Apply rule for all attribute values
		Iterator<Entry<Integer, ParsedAttributeItem>> attributeMapIterator = attributeMap.entrySet().iterator();
		while (attributeMapIterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> attributeEntry = attributeMapIterator.next();
			
			// Place modified attribute value back to attribute map
			attributeEntry.getValue().setValue(NumberUtils.convertFractionsToDecimal(attributeEntry.getValue().getValue()));
		}
		
		LOGGER.debug("Convert fractions to decimal ends.");
		return GeneralConstants.SUCCESS_RESULT_CODE;		
	}
	
	/**
	 * Check the values within the brackets (), and if same value present before 
	 * bracket starts then considering it as duplicate value and removing 
	 * one of it. 
	 * Example - "2 (2)" will be converted to "2"    
	 * 
	 * @param 	attributeMap
	 * 			Target attribute map to be modified.
	 * 
	 * @return	Result code
	 */
	public static String removeDuplicatesInBracket(final Map<Integer, ParsedAttributeItem> attributeMap) {
		LOGGER.debug("Remove duplicates within brackets starts... ");
		
		// Apply rule for all attribute values
		Iterator<Entry<Integer, ParsedAttributeItem>> attributeMapIterator = attributeMap.entrySet().iterator();
		while (attributeMapIterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> attributeEntry = attributeMapIterator.next();
			
			// Place modified attribute value back to attribute map
			attributeEntry.getValue().setValue(TextUtils.removeDuplicatesInBracket(attributeEntry.getValue().getValue()));
		}
		
		LOGGER.debug("Remove duplicates within brackets ends.");
		return GeneralConstants.SUCCESS_RESULT_CODE;		
	}
	
	/**
	 * Method to remove spare spaces. i.e., this will replace more than one white spaces
	 * into one white space character  
	 * 
	 * @param 	attributeMap
	 * 			Target attribute map to be modified.
	 * 
	 * @return	Result code
	 */
	public static String removeSpareSpaces(final Map<Integer, ParsedAttributeItem> attributeMap) {
		LOGGER.debug("Remove spare spaces starts... ");
		
		// Apply rule for all attribute values
		Iterator<Entry<Integer, ParsedAttributeItem>> attributeMapIterator = attributeMap.entrySet().iterator();
		while (attributeMapIterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> attributeEntry = attributeMapIterator.next();
			
			// Place modified attribute value back to attribute map
			attributeEntry.getValue().setValue(TextUtils.removeSpareSpaces(attributeEntry.getValue().getValue()));
		}
		
		LOGGER.debug("Remove spare spaces ends.");
		return GeneralConstants.SUCCESS_RESULT_CODE;		
	}
	
	/**
	 * Method to replace parsed values in attribute map with equivalent (normalized)
	 * value as configured in given map.  It will replace, only if complete
	 * parsed value matched with given map key. 
	 * 
	 * @param 	attributeMap
	 * 			Target attribute to be modified
	 * 
	 * @param 	valueMap
	 * 			
	 * @return	Result code
	 */
	public static String normalizeValuePerMap(final Map<Integer, ParsedAttributeItem> attributeMap, final Map<String, String> valueMap) {
		LOGGER.debug("Normalize value per map starts... ");
		
		// Do it for all source attribute values
		Iterator<Entry<Integer, ParsedAttributeItem>> attributeMapIterator = attributeMap.entrySet().iterator();
		String attributeValue;
		while (attributeMapIterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> attributeEntry = attributeMapIterator.next();
			
			attributeValue = attributeEntry.getValue().getValue();
			if (valueMap.containsKey(attributeValue)) {
				// Update equivalent replacement attribute value
				attributeEntry.getValue().setValue(valueMap.get(attributeValue));
			}
		}
		
		LOGGER.debug("Normalize value per map ends.");
		return GeneralConstants.SUCCESS_RESULT_CODE;
	}
	
}
