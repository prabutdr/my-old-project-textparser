/**
 * 
 */
package com.cts.textparser.operations;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;

import com.cts.textparser.constant.GeneralConstants;
import com.cts.textparser.to.ParsedAttributeItem;

/**
 * Operation class to hold methods which will do SIG specific parsing operations.
 * 
 * @author 153093
 *
 */
public class SIGParseOperations {

	private static final Logger LOGGER = Logger.getLogger(SIGParseOperations.class);

	/**
	 * This method will split attribute values follows patterns like "numeric_or_numeric_range unit"
	 * into attribute low value, attribute high value and attribute unit.
	 * And tag the values into respective sub attribute category as given attribute names.
	 * If there is no numeric range, only one numeric value found, then it will be tagged as high value.
	 * Examples - 
	 * 		1 TO 3 TABLET		Low - 1		High - 3		Unit - TABLET	  
	 * 		1 TIMES DAILY		Low - 0		High - 1		Unit - TIMES DAILY	  
	 * 		EVERY 4 HOURS		Low - 0		High - 4		Unit - HOURS	  
	 * 		EVERY DAY			Low - 0		High - 0		Unit - EVERY DAY	  
	 * 
	 * 
	 * @param groupAttributeMap
	 * @param lowSubAttributeName
	 * @param highSubAttributeName
	 * @param unitSubAttributeName
	 * @return	Result code
	 */
	public static String parseLowHighUnitSubAttributes(final Map<Integer, ParsedAttributeItem> groupAttributeMap, 
			String lowSubAttributeName, String highSubAttributeName, String unitSubAttributeName) {
		LOGGER.debug("Parse low, high & unit sub attributes starts... ");
		
		// Do it for all source attribute values
		Iterator<Entry<Integer, ParsedAttributeItem>> attributeMapIterator = groupAttributeMap.entrySet().iterator();
		while (attributeMapIterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> attributeEntry = attributeMapIterator.next();
			
			SIGParseUtils.parseLowHighUnitSubAttributes(attributeEntry.getValue(), 
					lowSubAttributeName, highSubAttributeName, unitSubAttributeName);
		}
		
		LOGGER.debug("Parse low, high & unit sub attributes ends. ");
		return GeneralConstants.SUCCESS_RESULT_CODE;
	}
	
	/**
	 * This method will check given patterns in source attribute, if match found,
	 * then matched value will be tagged to sub attribute map with identified
	 * position index (relative to source attribute index).  
	 * 
	 * @param 	groupAttributeMap
	 * @param 	subAttrbuteName
	 * @param 	patterns
	 * @return	Result code
	 */
	public static String standardizeSubAttributeValue(final Map<Integer, ParsedAttributeItem> groupAttributeMap, 
			final String subAttrbuteName, Collection<String> standardizedValues, String defaultStandardizedValue) {
		LOGGER.debug("Standardize sub attribute value starts... ");
		
		String subAttributeValue;
		for(ParsedAttributeItem groupAttributeItem: groupAttributeMap.values()) {
			subAttributeValue = groupAttributeItem.getSubAttributeValue(subAttrbuteName);
			if (subAttributeValue != null) {
				subAttributeValue = TextUtils.standardizeValue(subAttributeValue, standardizedValues, defaultStandardizedValue);
				groupAttributeItem.putSubAttributeValue(subAttrbuteName, subAttributeValue);
			}
		}
		
		LOGGER.debug("Standardize sub attribute value ends.");
		return GeneralConstants.SUCCESS_RESULT_CODE;
	}

	/**
	 * Method to parse low, high, unit sub attributes for duration.
	 * If duration units before duration value then will perform custom logic as below,
	 * Example - 
	 * 	1) Duration is "DAY 1"	- actual duration "FOR 1 DAY"
	 * 	2) Duration is "DAY 5"	- actual duration "FOR 1 DAY"
     * 	3) Duration is "DAYS 3 to 5"	- actual duration "FOR 3 DAY"
     * 	4) Duration is "DAYS 4 to 1"	- actual duration "FOR 4 DAY"
     * Otherwise do same as parseLowHighUnitSubAttributes
     * 
	 * @param durationAttributeMap
	 * @param lowSubAttributeName
	 * @param highSubAttributeName
	 * @param unitSubAttributeName
	 * 
	 * @return	Result code
	 */
	public static String parseLowHighUnitSubAttributesForDuration(final Map<Integer, ParsedAttributeItem> durationAttributeMap, 
			String lowSubAttributeName, String highSubAttributeName, String unitSubAttributeName) {
		LOGGER.debug("Parse low, high & unit sub attributes for duration starts... ");
		
		// Do it for all source attribute values
		Iterator<Entry<Integer, ParsedAttributeItem>> attributeMapIterator = durationAttributeMap.entrySet().iterator();
		while (attributeMapIterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> attributeEntry = attributeMapIterator.next();
			
			SIGParseUtils.parseLowHighUnitSubAttributesForDuration(attributeEntry.getValue(), 
					lowSubAttributeName, highSubAttributeName, unitSubAttributeName);
		}
		
		LOGGER.debug("Parse low, high & unit sub attributes for duration ends. ");
		return GeneralConstants.SUCCESS_RESULT_CODE;
	}

	/**
	 * Method to remove duplicate values from attribute map
	 * 
	 * @param targetAttributeMap
	 */
	public static String removeDuplicatesInAttribute(final Map<Integer, ParsedAttributeItem> targetAttributeMap) {
		LOGGER.debug("Remove duplicates in attribute starts... ");
		SIGParseUtils.removeDuplicatesInAttribute(targetAttributeMap);
		LOGGER.debug("Remove duplicates in attribute ends. ");
		return GeneralConstants.SUCCESS_RESULT_CODE;
	}
}
