/**
 * 
 */
package com.cts.textparser.operations;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;

import org.apache.commons.lang.StringUtils;

import com.cts.textparser.constant.RegexConstants;
import com.cts.textparser.to.ParsedAttributeItem;
import com.cts.textparser.util.ApplicationUtil;

/**
 * Utility class to hold methods which will do SIG specific parse operations.
 * 
 * @author 153093
 *
 */
public class SIGParseUtils {

	/**
	 * This method will split attribute values follows patterns like "numeric_or_numeric_range unit"
	 * into attribute low value, attribute high value and attribute unit.
	 * And tag the values into respective sub attribute category as given attribute names.
	 * If there is no numeric range, only one numeric value found, then it will be tagged as high value.
	 * Examples - 
	 * 		1 TO 3 TABLET		Low - 1		High - 3		Unit - TABLET	  
	 * 		1 TIMES DAILY		Low - 0		High - 1		Unit - TIMES DAILY	  
	 * 		EVERY 4 HOURS		Low - 0		High - 4		Unit - HOURS	  
	 * 		EVERY DAY			Low - 0		High - 0		Unit - EVERY DAY	  
	 * 
	 * @param 	groupAttributeItem
	 * @param 	lowSubAttributeName
	 * @param 	highSubAttributeName
	 * @param 	unitSubAttributeName
	 */
	public static void parseLowHighUnitSubAttributes(ParsedAttributeItem groupAttributeItem, 
			String lowSubAttributeName, String highSubAttributeName, String unitSubAttributeName) {
		 
		String attributeValue, attributeUnit;
		Double lowAttributeValue, highAttributeValue, tempAttributeValue;
		int findIdx;

		attributeValue = groupAttributeItem.getValue();
		
		lowAttributeValue = highAttributeValue = null;
		attributeUnit = null;
		Matcher matcher = RegexConstants.PATTERN_NUMERIC.matcher(attributeValue);
		findIdx = 0;
		if (matcher.find(findIdx)) {
			// Parse attribute low value if any
			lowAttributeValue = Double.valueOf(attributeValue.substring(matcher.start(), matcher.end()));
			findIdx = matcher.end();
			
			if (matcher.find(findIdx)) {
				// Parse attribute high value if any
				highAttributeValue = Double.valueOf(attributeValue.substring(matcher.start(), matcher.end()));
				findIdx = matcher.end();
			}
		}
		// Consider remaining as attribute unit
		attributeUnit = attributeValue.substring(findIdx).trim();
		
		// Swap values in case only one attribute value found (low),
		// or High value is less than low value
		if (highAttributeValue == null || (lowAttributeValue != null && highAttributeValue < lowAttributeValue)) {
			tempAttributeValue = lowAttributeValue;
			lowAttributeValue = highAttributeValue;
			highAttributeValue = tempAttributeValue;
		}
		
		// Tag splitted attribute values to transfer object
		if (lowAttributeValue != null) {
			groupAttributeItem.putSubAttributeValue(lowSubAttributeName, lowAttributeValue.toString());
		}
		if (highAttributeValue != null) {
			groupAttributeItem.putSubAttributeValue(highSubAttributeName, highAttributeValue.toString());
		}
		if (StringUtils.isNotBlank(attributeUnit)) {
			groupAttributeItem.putSubAttributeValue(unitSubAttributeName, attributeUnit);
		}
	}

	/**
	 * Method to parse low, high, unit sub attributes for duration.
	 * If duration units before duration value then will perform custom logic as below,
	 * Example - 
	 * 	1) Duration is "DAY 1"	- actual duration "FOR 1 DAY"
	 * 	2) Duration is "DAY 5"	- actual duration "FOR 1 DAY"
     * 	3) Duration is "DAYS 3 to 5"	- actual duration "FOR 3 DAY"
     * 	4) Duration is "DAYS 4 to 1"	- actual duration "FOR 4 DAY"
     * Otherwise do same as parseLowHighUnitSubAttributes
     * 
	 * @param durationAttributeItem
	 * @param lowSubAttributeName
	 * @param highSubAttributeName
	 * @param unitSubAttributeName
	 */
	public static void parseLowHighUnitSubAttributesForDuration(ParsedAttributeItem durationAttributeItem,
			String lowSubAttributeName, String highSubAttributeName, String unitSubAttributeName) {
		
		String duration = durationAttributeItem.getValue();

		Matcher matcher = RegexConstants.PATTERN_DURATION_UNIT_AT_BOL.matcher(duration);
		if(matcher.find()) {
			// Numeric pattern at end of line in duration, mean duration unit followed by range
			// then, calculate range interval and set values appropriately
			String durationUnit = duration.substring(0, matcher.end()).trim();
			if (StringUtils.isBlank(durationUnit)) {
				return;
			}
			durationAttributeItem.removeSubAttribute(lowSubAttributeName);
			durationAttributeItem.removeSubAttribute(highSubAttributeName);
			durationAttributeItem.removeSubAttribute(unitSubAttributeName);
			Double highDuration = ApplicationUtil.getIntervalFromRange(duration);
			if (highDuration != null) {
				durationAttributeItem.putSubAttributeValue(highSubAttributeName, String.valueOf(highDuration));
			}
			durationAttributeItem.putSubAttributeValue(unitSubAttributeName, durationUnit);
		}
		else {
			parseLowHighUnitSubAttributes(durationAttributeItem, lowSubAttributeName, highSubAttributeName, unitSubAttributeName);
		}
	}

	/**
	 * Method to remove duplicate values from attribute map
	 * 
	 * @param targetAttributeMap
	 */
	public static void removeDuplicatesInAttribute(final Map<Integer, ParsedAttributeItem> targetAttributeMap) {
		if(targetAttributeMap == null || targetAttributeMap.size() <= 1) {
			return;  // Simply return there are no duplicates to remove
		}

		Set<String> valueSet = new HashSet<>();
		
		Iterator<Entry<Integer, ParsedAttributeItem>> iterator = targetAttributeMap.entrySet().iterator();
		while(iterator.hasNext()) {
			Entry<Integer, ParsedAttributeItem> entry = iterator.next();
			
			if(!valueSet.add(entry.getValue().getValue())) {
				iterator.remove();
			}
		}
	}

}
