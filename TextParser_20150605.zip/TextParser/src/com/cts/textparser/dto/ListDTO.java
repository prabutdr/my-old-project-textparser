/**
 * 
 */
package com.cts.textparser.dto;

import java.util.List;

import org.apache.commons.beanutils.BeanUtils;

import com.cts.textparser.constant.ActiveInd;
import com.cts.textparser.constant.ModifyInd;
import com.cts.textparser.constant.SortInd;


/**
 * 
 * @author 153093
 *
 */
public class ListDTO {

	private int index;
	private ModifyInd modifyInd = ModifyInd.NONE;

	private String name;
	private String description;
	private SortInd sortInd;
	private ActiveInd activeInd;
	private List<ListItemDTO> values;
	
	/**
	 * Describe properties as string
	 * 
	 */
	@Override
	public String toString() {
		try {
			return BeanUtils.describe(this).toString();
		} catch (Exception e) {
			return super.toString();
		}
	}

	/**
	 * @return the index
	 */
	public int getIndex() {
		return index;
	}
	/**
	 * @param index the index to set
	 */
	public void setIndex(int index) {
		this.index = index;
	}
	/**
	 * @return the modifyInd
	 */
	public ModifyInd getModifyInd() {
		return modifyInd;
	}
	/**
	 * @param modifyInd the modifyInd to set
	 */
	public void setModifyInd(ModifyInd modifyInd) {
		this.modifyInd = modifyInd;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the sortInd
	 */
	public SortInd getSortInd() {
		return sortInd;
	}
	/**
	 * @param sortInd the sortInd to set
	 */
	public void setSortInd(SortInd sortInd) {
		this.sortInd = sortInd;
	}
	/**
	 * @return the activeInd
	 */
	public ActiveInd getActiveInd() {
		return activeInd;
	}
	/**
	 * @param activeInd the activeInd to set
	 */
	public void setActiveInd(ActiveInd activeInd) {
		this.activeInd = activeInd;
	}
	/**
	 * @return the values
	 */
	public List<ListItemDTO> getValues() {
		return values;
	}
	/**
	 * @param values the values to set
	 */
	public void setValues(List<ListItemDTO> values) {
		this.values = values;
	}
}
