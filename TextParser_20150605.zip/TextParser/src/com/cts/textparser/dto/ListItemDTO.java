/**
 * 
 */
package com.cts.textparser.dto;

import com.cts.textparser.constant.ModifyInd;


/**
 * 
 * @author 153093
 *
 */
public class ListItemDTO {

	private int index;
	private ModifyInd modifyInd = ModifyInd.NONE;

	private String value;
	
	public ListItemDTO() {
		super();
	}
	
	public ListItemDTO(int index, String value) {
		this.index = index;
		this.value = value;
		this.modifyInd = ModifyInd.NONE;
	}
	
	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}
	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
	/**
	 * @return the index
	 */
	public int getIndex() {
		return index;
	}
	/**
	 * @param index the index to set
	 */
	public void setIndex(int index) {
		this.index = index;
	}
	/**
	 * @return the modifyInd
	 */
	public ModifyInd getModifyInd() {
		return modifyInd;
	}
	/**
	 * @param modifyInd the modifyInd to set
	 */
	public void setModifyInd(ModifyInd modifyInd) {
		this.modifyInd = modifyInd;
	}
}
