/**
 * 
 */
package com.cts.textparser.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cts.textparser.constant.GeneralConstants;

/**
 * @author 153093
 *
 */
@Controller
@RequestMapping(value = "/dictionaryAdmin")
public class DictionaryAdminController {

	@RequestMapping(method = RequestMethod.GET)
	public String showDictionaryAdmin(ModelMap model) {
		return GeneralConstants.VIEW_DICTIONARY_ADMIN;
	}
}
