/**
 * 
 */
package com.cts.textparser.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cts.textparser.constant.GeneralConstants;
import com.cts.textparser.dto.ListDTO;
import com.cts.textparser.util.TextParserException;
import com.cts.textparser.util.WorkbookDAO;

/**
 * @author 153093
 *
 */
@Controller
@RequestMapping(value = "/list")
public class DictionaryListController {

	private static final Logger LOGGER = Logger.getLogger(DictionaryListController.class); 

	@Autowired(required = true)
	@Qualifier("workbookDAO")
	private WorkbookDAO workbookDAO;
	
	@RequestMapping(value = "/getAllSummary.json", method = RequestMethod.GET)
	@ResponseBody
	public List<ListDTO> getAllListSummary() throws TextParserException {
		try {
			return workbookDAO.getAllListSummary();
		} catch (TextParserException e) {
			LOGGER.error("TextParserException occurred", e);
			throw e;
		}
	}

	@RequestMapping(value = "/delete.json", method = RequestMethod.POST)
	public @ResponseBody String deleteList(@RequestBody ListDTO listDTO) throws TextParserException {
		try {
			LOGGER.debug("TESTRP - delete request received - " + listDTO);
			workbookDAO.deleteList(listDTO);
		} catch (TextParserException e) {
			LOGGER.error("TextParserException occurred", e);
			throw e;
		}
			
	   return GeneralConstants.SUCCESS;
	}	
}
