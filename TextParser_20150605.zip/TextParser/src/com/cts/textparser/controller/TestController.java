/**
 * 
 */
package com.cts.textparser.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cts.textparser.dto.ListItemDTO;

/**
 * @author 153093
 *
 */
@Controller
@RequestMapping("/test")
public class TestController {

	@RequestMapping(method = RequestMethod.GET)
	@ResponseBody
	public ListItemDTO showHome(ModelMap model) {
		return new ListItemDTO(10, "TEST STRING");
	}

}
