package commom;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
 

public class MainMethod {

	static boolean flag = true;
	/**
	 * @param args
	 */
	    public static void main( String[] args )
	    {
	    	/*try {
			     Dictionaries dict = new Dictionaries();
			     //dict.matchValues("inhale 1 puff by inhalation route every 12 hours");
				
			  FileInputStream file = new FileInputStream(new File("C:\\SampleInput.xlsx"));
			    
			   // FileInputStream file = new FileInputStream(new File("C:\\Hi.xlsx"));
	            
			  //Get the workbook instance for XLS file 
			  XSSFWorkbook workbook = new XSSFWorkbook (file);
			   
			  //Get first sheet from the workbook
			  XSSFSheet sheet = workbook.getSheetAt(0);
			     
			    //Get the workbook instance for XLS file 
			   // HSSFWorkbook workbook = new HSSFWorkbook(file);
			 
			    //Get first sheet from the workbook
			   // HSSFSheet sheet = workbook.getSheetAt(0);
			     
			    //Iterate through each rows from first sheet
			    Iterator<Row> rowIterator = sheet.iterator();
			    while(rowIterator.hasNext()) {
			        Row row = rowIterator.next();
			         
			        //For each row, iterate through each columns
			        Iterator<Cell> cellIterator = row.cellIterator();
			        while(cellIterator.hasNext()) {
			        	Cell cell = cellIterator.next();
			        	dict.matchValues(cell.getStringCellValue());
			        	//System.out.println(cell.getStringCellValue() + "\n");
			        }
			    }
			    file.close();
			} catch (FileNotFoundException e) {
			    e.printStackTrace();
			} catch (IOException e) {
			    e.printStackTrace();
			}catch(Exception e){
				e.printStackTrace();
			}
			*/
	    	/*String inputSig = "444444444444444444.555mL PO Q6H";
	    	String array[] = inputSig.split("[ ]");
	    	for(int i = 0 ;i< array.length; i++){
	    		System.out.println(array[i]);
	    		//String regex =  "^([0-9]{1,3}(\\.[0-9])?)()*$";
	    	String regex = "[0-9]*[\\.]([0-9]{1,3}[a-zA-Z]*)";
	    	if(array[i].matches(regex))
	    	{
	    		  System.out.println("true");
	    	}
	    	else
	    	{
	    		  System.out.println("false");
	    	}
	    	}*/
	    	
	    	String a = "XDAY";
	    	if(a.contains("X"))
	    	{
	    		System.out.println("True");
	    	}
	    	else{
	    		System.out.println("False");
	    	}
	    	
	    	/*String num="253.65";
	        try{
	            double d=Double.parseDouble(num);
	            if(d==0.0){
	                System.out.println("valid");
	            }else if(d>0&&(num.split("\\.")[1].length()==2)){
	                System.out.println(num+" is valid");
	            }else{
	                System.out.println(num+" is invalid");
	            }
	        } catch (NumberFormatException e){
	            System.out.println(num+"is not a valid number");
	        }
	    	/*String array[] = inputSig.split("[ ]");
	    	for(int i = 0 ;i< array.length; i++){
	    		System.out.println(array[i]);
	    
	    	if(inputSig.matches(regex)){
	    	// Pattern p = Pattern.compile();

	    	   // Matcher m = p.matcher(inputSig);

	    	    //if (m.matches()) {
	    	      
	    	    }
	    	    else{
	    	    	System.out.println("false");
	    	    }
	    	}

	    	/*int indexOfDot = inputSig.indexOf(".");
			if(inputSig.matches("[0-9]*\.?[0-9]") && indexOfDot >0 ){
				System.out.println("In if" + inputSig);
			}
			else
			{
				System.out.println("In else" + inputSig.replaceAll("[.]", " "));
			}*/
		}
	}

