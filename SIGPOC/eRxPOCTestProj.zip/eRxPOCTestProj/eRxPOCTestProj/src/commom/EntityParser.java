package commom;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;


public class EntityParser {
	
	public Map<String,String> listOfWords = new HashMap<String, String>();
	public Map<String,String> latinToEnglishMapping = new HashMap<String, String>();
	public Map<String,String> shortSigMapping = new HashMap<String, String>();
	/*ArrayList<String> stopWords = new ArrayList<String>();
	ArrayList<String> temporals = new ArrayList<String>();
	ArrayList<String> oneWordFrequency = new ArrayList<String>();
	ArrayList<String> dosageForm = new ArrayList<String>();
	ArrayList<String> durationDelimiter = new ArrayList<String>();
	ArrayList<String> dosageMetrics = new ArrayList<String>();*/
	
	public void loadConfig()
	{
		/*try{
		int  i = 0;	
		Properties prop = new Properties();
		InputStream in = getClass().getResourceAsStream("dict.properties");
		prop.load(in);
		in.close();
		for (String retval: prop.getProperty("stopWords").split(",")){
			stopWords.set(i, retval);
			i++;
	      }
		i = 0;
		for (String retval: prop.getProperty("temporals").split(",")){
			temporals.set(i, retval);
			i++;
	      }
		i = 0;
		for (String retval: prop.getProperty("oneWordFrequency").split(",")){
			oneWordFrequency.set(i, retval);
			i++;
	      }
		i = 0;
		for (String retval: prop.getProperty("dosageForm").split(",")){
			dosageForm.set(i, retval);
			i++;
	      }
		i = 0;
		for (String retval: prop.getProperty("durationDelimiter").split(",")){
			durationDelimiter.set(i, retval);
			i++;
	      }
		i = 0;
		for (String retval: prop.getProperty("dosageMetrics").split(",")){
			dosageMetrics.set(i, retval);
			i++;
	      }
		System.out.println("StopWords" + prop.getProperty("stopWords").split(","));
		System.out.println("temporals" + prop.getProperty("temporals"));
		System.out.println("oneWordFrequency" + prop.getProperty("oneWordFrequency"));
		System.out.println("dosageForm" + prop.getProperty("dosageForm"));
		System.out.println("durationDelimiter" + prop.getProperty("durationDelimiter"));
		System.out.println("dosageMetrics" + prop.getProperty("dosageMetrics"));
		
		stopWords = new ArrayList<String>(
			    Arrays.asList(prop.getProperty("stopWords").));
		
		temporals = new ArrayList<String>(
			    Arrays.asList(prop.getProperty("temporals")));
		
		oneWordFrequency = new ArrayList<String>(
			    Arrays.asList(prop.getProperty("oneWordFrequency")));
			   
		
		 dosageForm = new ArrayList<String>(
			    Arrays.asList(prop.getProperty("dosageForm")));
		
		 durationDelimiter = new ArrayList<String>(
			    Arrays.asList(prop.getProperty("durationDelimiter")));
		
		dosageMetrics = new ArrayList<String>(
			    Arrays.asList(prop.getProperty("dosageMetrics")));
		}
		catch(Exception e){
			e.printStackTrace();
		}*/
	}

	
	ArrayList<String> stopWords = new ArrayList<String>(
		    Arrays.asList("a", "an", "the`", "of", "at",
         		      "on", "upon", "in", "to", "from", "out", "as", "so", "such", "or", "and", "those", "this", "these", "that",
        		      "for", ",", "is", "was", "am", "are", "'s", "been", "were","by","route", "times","time","with","before","after"));
	
	ArrayList<String> temporals = new ArrayList<String>(
		    Arrays.asList("day","days","week","weeks","month","months","year","years","daily","weekly","monthly","yearly","nightly","hours","hour","hr","hrs","morning","evening","afternoon","noon","night"));
	
	ArrayList<String> oneWordFrequency = new ArrayList<String>(
		    Arrays.asList("daily","weekly","monthly","yearly","nightly","hourly"));
		   
	
	ArrayList<String> dosageForm = new ArrayList<String>(
		    Arrays.asList("patch","application","shampoo","lotion","film(s)","film","flims","otic","packet","packet(s)","packets","pkt","inch","inch(s)","kit","kit(s)","kits","applicator","applicator(s)","applicators","pill","pill(s)","pills","puff","puff(s)","puffs","tablet","tablet(s)","tablets","tab","tabs","cap","capsule","capsule(s)","capsules","suppository","spray","foam/shampoo","cream/gel","injection","solution"));
	
	ArrayList<String> durationDelimiter = new ArrayList<String>(
		    Arrays.asList("for","x"));
	
	ArrayList<String> dosageMetrics = new ArrayList<String>(
		    Arrays.asList("squirt","squirts","units","unit","mg","gram" ,"gm","miligram","mcg","ml","millilitre","drop","drops","tsp","cc","teaspoon","tablespoon"));
	
	ArrayList<String> siteofAdminPrefixWords = new ArrayList<String>(
		    Arrays.asList("both","affected","left","right","each"));

	public ParseBean matchValues(String input)
	{
		String verb = "";
		String freq = "";
		String total_duration= "";
		String timeOfDay = "";
		String dosage ="";
		String total_dosage ="";
		String dosage_form ="";
		String total_frequency="";
		String f_total_frequency ="";
		String dosage_strength ="";
		String f_dosage_strength ="";
		String f_total_duration = "";
		String siteOfAdmin = "";
		String routeOfAdmin = "";
		String vehicle = "";
		String additional_dosage_duration ="";
		boolean durationFlag = false;
		boolean isDrugForm = false;
		boolean isDrugStrengthProcessed =  false;
		boolean isTemporal = false;
		boolean durationDelimiterFlag = false;
		String latinToEnglishSentence = "";
		String splitXSentence = "";
		String qSentence = "";
		ParseBean parseBean = new ParseBean();
		HashMap dosageHashMap = new HashMap();
		HashMap frequencyHashMap = new HashMap();
		
		listOfWords.put("take", "Verb");
		listOfWords.put("put", "Verb");
		listOfWords.put("apply", "Verb");
		listOfWords.put("inject", "Verb");
		listOfWords.put("inhale", "Verb");
		listOfWords.put("spray", "Verb");
		listOfWords.put("give", "Verb");
		listOfWords.put("place", "Verb");
		listOfWords.put("chew", "Verb");
		listOfWords.put("swallow", "Verb");
		listOfWords.put("instill", "Verb");
		listOfWords.put("insert", "Verb");
		listOfWords.put("place", "Verb");
		listOfWords.put("dissolve", "Verb");
		listOfWords.put("once", "Frequency");
		listOfWords.put("twice", "Frequency");
		listOfWords.put("thrice", "Frequency");
		listOfWords.put("before meals", "Time of Day");
		listOfWords.put("after meals", "Time of Day");
		listOfWords.put("Morning", "Time of Day");
		listOfWords.put("noon", "Time of Day");
		listOfWords.put("afterNoon", "Time of Day");
		listOfWords.put("evening", "Time of Day");
		listOfWords.put("night", "Time of Day");
		listOfWords.put("bedtime", "Time of Day");
		listOfWords.put("empty stomach", "Time of Day");
		listOfWords.put("mg", "dosage metrics");
		listOfWords.put("gram", "dosage metrics");
		listOfWords.put("gm", "dosage metrics");
		listOfWords.put("miligram", "dosage metrics");
		listOfWords.put("mcg", "dosage metrics");
		listOfWords.put("ml", "dosage metrics");
		listOfWords.put("unit", "dosage metrics");
		listOfWords.put("units", "dosage metrics");
		listOfWords.put("millilitre", "dosage metrics");
		listOfWords.put("drop", "dosage metrics");
		listOfWords.put("drops", "dosage metrics");
		listOfWords.put("squirt", "dosage metrics");
		listOfWords.put("squirts", "dosage metrics");
		listOfWords.put("tsp", "dosage metrics");
		listOfWords.put("cc", "dosage metrics");
		listOfWords.put("teaspoon", "dosage metrics");
		listOfWords.put("tablespoon", "dosage metrics");
		listOfWords.put("day", "duration metrics");
		listOfWords.put("days", "duration metrics");
		listOfWords.put("week", "duration metrics");
		listOfWords.put("weeks", "duration metrics");
		listOfWords.put("month", "duration metrics");
		listOfWords.put("months", "duration metrics");
		listOfWords.put("year", "duration metrics");
		listOfWords.put("years", "duration metrics");
		listOfWords.put("weekly", "duration metrics");
		listOfWords.put("monthly", "duration metrics");
		listOfWords.put("yearly", "duration metrics");
		listOfWords.put("nightly", "duration metrics");
		listOfWords.put("daily", "duration metrics");
		listOfWords.put("hours", "duration metrics");
		listOfWords.put("hour", "duration metrics");
		listOfWords.put("every", "duration metrics");
		listOfWords.put("puff", "dosage form");
		listOfWords.put("puff(s)", "dosage form");
		listOfWords.put("puffs", "dosage form");
		listOfWords.put("tab", "dosage form");
		listOfWords.put("tabs", "dosage form");
		listOfWords.put("tablet", "dosage form");
		listOfWords.put("tablets", "dosage form");
		listOfWords.put("shampoo", "dosage form");
		listOfWords.put("lotion", "dosage form");
		listOfWords.put("tablet(s)", "dosage form");
		listOfWords.put("cap", "dosage form");
		listOfWords.put("capsule", "dosage form");
		listOfWords.put("capsule(s)", "dosage form");
		listOfWords.put("capsules", "dosage form");
		listOfWords.put("suppository", "dosage form");
		listOfWords.put("spray", "dosage form");
		listOfWords.put("foam/shampoo", "dosage form");
		listOfWords.put("cream/gel", "dosage form");
		listOfWords.put("injection", "dosage form");
		listOfWords.put("solution", "dosage form");
		listOfWords.put("pill", "dosage form");
		listOfWords.put("patch", "dosage form");
		listOfWords.put("pill(s)", "dosage form");
		listOfWords.put("pills", "dosage form");
		listOfWords.put("applicator", "dosage form");
		listOfWords.put("application", "dosage form");
		listOfWords.put("applicator(s)", "dosage form");
		listOfWords.put("applicators", "dosage form");
		listOfWords.put("pkt", "dosage form");
		listOfWords.put("kit", "dosage form");
		listOfWords.put("kits", "dosage form");
		listOfWords.put("kit(s)", "dosage form");
		listOfWords.put("inch", "dosage form");
		listOfWords.put("inch(s)", "dosage form");
		listOfWords.put("packet(s)", "dosage form");
		listOfWords.put("packets", "dosage form");
		listOfWords.put("packet", "dosage form");
		listOfWords.put("film", "dosage form");
		listOfWords.put("films", "dosage form");
		listOfWords.put("film(s)", "dosage form");
		listOfWords.put("mouth", "route of administration");
		listOfWords.put("ear", "route of administration");
		listOfWords.put("ears", "route of administration");
		listOfWords.put("otic", "route of administration");
		listOfWords.put("oral", "route of administration");
		listOfWords.put("orally", "route of administration");
		listOfWords.put("nose", "route of administration");
		listOfWords.put("rectal", "route of administration");
		listOfWords.put("rectally", "route of administration");
		listOfWords.put("subcutaneous", "route of administration");
		listOfWords.put("nasal", "route of administration");
		listOfWords.put("topical", "route of administration");
		listOfWords.put("top", "route of administration");
		listOfWords.put("inhalation", "route of administration");
		listOfWords.put("transdermal", "route of administration");
		listOfWords.put("food", "vehicle");
		listOfWords.put("water", "vehicle");
		listOfWords.put("meals", "vehicle");
		listOfWords.put("meal", "vehicle");
		listOfWords.put("inhaler", "vehicle");
		listOfWords.put("milk", "vehicle");
		listOfWords.put("lungs", "site of admininstration");
		listOfWords.put("nose", "site of admininstration");
		listOfWords.put("nostril", "site of admininstration");
		listOfWords.put("scalp", "site of admininstration");
		listOfWords.put("armpit", "site of admininstration");
		listOfWords.put("eye", "site of admininstration");
		listOfWords.put("eyes", "site of admininstration");
		listOfWords.put("rectum", "site of admininstration");
		listOfWords.put("skin", "site of admininstration");
		listOfWords.put("hand", "site of admininstration");
		listOfWords.put("face", "site of admininstration");
		listOfWords.put("tongue", "site of admininstration");
		listOfWords.put("muscle", "site of admininstration");
		listOfWords.put("leg", "site of admininstration");
		listOfWords.put("legs", "site of admininstration");
		listOfWords.put("arm", "site of admininstration");
		listOfWords.put("arms", "site of admininstration");
		listOfWords.put("eyelid", "site of admininstration");
		listOfWords.put("eyelids", "site of admininstration");
		listOfWords.put("lids", "site of admininstration");
		listOfWords.put("lid", "site of admininstration");
		
		//Latin to English word map
		latinToEnglishMapping.put("PO", "by mouth" );
		latinToEnglishMapping.put("Q", "every" );
		latinToEnglishMapping.put("H", "hours" );
		latinToEnglishMapping.put("BID", "twice daily" );
		latinToEnglishMapping.put("INH", "inhale 1 puffs every 2 hours" );
		latinToEnglishMapping.put("QPM", "every evening" );
		latinToEnglishMapping.put("QAM", "every morning" );
		latinToEnglishMapping.put("QID", "four times daily" );
		latinToEnglishMapping.put("PRN", "as needed" );
		latinToEnglishMapping.put("QD", "daily" );
		latinToEnglishMapping.put("TID", "three times daily" );
		latinToEnglishMapping.put("QHS", "every night at bedtime" );
		latinToEnglishMapping.put("HS", "at bedtime" );
		latinToEnglishMapping.put("C", "capsule" );
		latinToEnglishMapping.put("T", "tablet" );
		latinToEnglishMapping.put("TK", "take" );
		latinToEnglishMapping.put("APP", "apply" );
		latinToEnglishMapping.put("GTT", "drop" );
		latinToEnglishMapping.put("GTTS", "drops" );
		latinToEnglishMapping.put("OS", "left eye" );
		latinToEnglishMapping.put("OD", "right eye" );
		latinToEnglishMapping.put("OU", "both eyes" );
		latinToEnglishMapping.put("U", "use" );
		latinToEnglishMapping.put("SQ", "subcutaneous" );
		latinToEnglishMapping.put("AC", "before a meal" );
		latinToEnglishMapping.put("IM", "in the muscle" );
		latinToEnglishMapping.put("TSP", "teaspoon" );
		latinToEnglishMapping.put("QOD", "every other day" );
		latinToEnglishMapping.put("QDAY", "daily" );
		latinToEnglishMapping.put("DR", "discard remainder" );
		latinToEnglishMapping.put("AA", "to the affected area" );
		latinToEnglishMapping.put("NEB", "nebulizer" );
		
		//Short Sig mapping
		
		shortSigMapping.put("TAKE", "TK");
		shortSigMapping.put("TAKE", "TK");
		shortSigMapping.put("INHALE", "INL");
		shortSigMapping.put("PUFF", "PFS");
		shortSigMapping.put("BY MOUTH", "PO");
		shortSigMapping.put("EVERY", "Q");
		shortSigMapping.put("HOURS", "H");
		
		try{
			// Tokenizing the incoming sig
			System.out.println("Input String:" + input);
			parseBean.setInputString(input.toUpperCase());
			input = input.replaceAll("[(),;]"," ");
		
			//Replacing . only if it is not with number
			boolean isCheckForDot = checkForDot(input);
			if(!isCheckForDot){
				input = input.replaceAll("[.]"," ");
			}
			System.out.println("\nInput after replacing special characters: " + input);
		
			//Logic for splitting up the tokens with "X"
			input = getSentenceAfterXSplit(input);
			System.out.println("\nTotal sentence after X split: " + input);
		
			//Splitting the Q%% words
			input  = getSentenceAfterQSplit(input);
			System.out.println("\nTotal sentence after Q split: " + input);
		
			//Replacing the Latin word
			input = getLatintoEnglishSentence(input);	
			parseBean.setFullConvertedString(input.toUpperCase());
			System.out.println("\nLatin To English Sentence: " + input);
		
			// To determine if the token is for drug strength - Start
			dosageHashMap = getDosageStrength(input);
			dosage_strength = (String) dosageHashMap.get("dosageStrength");
			isDrugStrengthProcessed = (Boolean) dosageHashMap.get("isDrugStrengthProcessed");
		
			// To determine if the token is for drug strength - End
			
			//Calculation for the frequency  - Starts
		 
			frequencyHashMap = getFrequency(input);
			additional_dosage_duration = (String) frequencyHashMap.get("additional_dosage_duration");
			freq = (String) frequencyHashMap.get("freq");
			total_frequency = (String) frequencyHashMap.get("total_frequency");
			durationFlag = (Boolean) frequencyHashMap.get("durationFlag");
			 
			//Calculation for the frequency  - Ends
			
			StringTokenizer st = new StringTokenizer(input," ");
			int totalNoOfTokens = st.countTokens();
			String tokenArray[] = new String[totalNoOfTokens];
			int a  = 0;
			while(st.hasMoreTokens()) {
				tokenArray[a] = st.nextToken(); 
				a++;
			}
			
			for (int x=0; x<tokenArray.length; x++){
			
			 
			  //Calculation for dosage and dosage form
			 if(dosageForm.contains(tokenArray[x].toLowerCase()))
			 {
				 dosage = tokenArray[x-1];
			 }
			 if(dosageMetrics.contains(tokenArray[x].toLowerCase())){
				 
				 dosage_strength = tokenArray[x-1] + " " + tokenArray[x];
			 }
			}
			 
			//Calculating total duration	
			 total_duration = getTotalDuration(input);
			
			 //STARTING TOKENS TAGGING -----------------------------------------------------------	
			 //------------------------------------------------------------------------------------
			 for (int x=0; x<tokenArray.length; x++){
	    	 
	    	 //Skipping trivial tokens or the tokens that are used in previous calculations
				 if(checkforNumber(tokenArray[x])||
	    			 stopWords.contains(tokenArray[x])||freq.equalsIgnoreCase(tokenArray[x])){
	    		 continue;
	    	 }
	    	 
	    	 //Logic to tag values according to the BPM format
	    	 if(listOfWords.containsKey(tokenArray[x].toLowerCase()))
	    	 {
	    	 String token= listOfWords.get(tokenArray[x].toLowerCase());
	    	 
	    	 //Verb tagging
	    	 if(token.equalsIgnoreCase("Verb"))
	    	 {
	    		 if(!(verb.trim().equalsIgnoreCase(tokenArray[x].trim()))){
	    			 verb = verb + " " + tokenArray[x]; 
	    		 }
	    		 else{
	    			 verb = tokenArray[x];
	    		 }
	    		 
	    	 }
	    	
	    	 //Time of Day tagging
	    	 if(token.equalsIgnoreCase("Time of Day"))
	    	 {
	    		 timeOfDay = tokenArray[x];
	    	 }
	    	 //Route of Administration tagging
	    	 if(token.equalsIgnoreCase("route of administration"))
	    	 {
	    		routeOfAdmin = tokenArray[x];
	    	 }
	    	 // Dosage strength tagging
	    	 if(token.equalsIgnoreCase("dosage metrics") || isDrugStrengthProcessed == true)
	    	 {
	    		f_dosage_strength = dosage_strength;
	    	 }
	    	 // Dosage form and total dosage tagging
	    	 if(token.equalsIgnoreCase("dosage form"))
	    	 {
	    		 total_dosage = dosage;
	    		 dosage_form = tokenArray[x];
	    	 }
	    	 // Frequency and Duration tagging
	    	 if(token.equalsIgnoreCase("duration metrics"))
	    	 {
	    		 f_total_frequency = total_frequency;
	    		 f_total_duration = total_duration;
	    	 }
	    	 
	    	 //Vehicle tagging
	    	 if(token.equalsIgnoreCase("vehicle"))
	    	 {
	    		 if(!(vehicle.trim().equalsIgnoreCase(tokenArray[x].trim()))){
	    			 vehicle = vehicle + " " + tokenArray[x]; 
	    		 }
	    		 else{
	    		 vehicle = tokenArray[x];
	    		 }
	    		 
	    	 }
	    	 
	    	 //Site of Administration tagging
	    	 if(token.equalsIgnoreCase("site of admininstration"))
	    	 {
	    		if(siteofAdminPrefixWords.contains(tokenArray[x-1])) 
	    		{
	    			siteOfAdmin = siteOfAdmin + " " + tokenArray[x-1] + " " + tokenArray[x];
	    		}
	    		else
	    		{
	    			siteOfAdmin = siteOfAdmin + " " + tokenArray[x];
	    		}
	    	 } 
	    	 
	     }
	    	 else
	    	 {
	    		 //System.out.println("The list of non matching tokens are : " + tokenArray[x]);
	    	 }	    	 
	     }
		}
		catch(Exception e){
			System.out.println("Could not parse the string:" + latinToEnglishSentence);
		}
		
	     System.out.println("\n--------------------------------");
	     System.out.println("--------------------------------");
	     System.out.println ("Final List of Tokens are:\n" + "Verb:->" + verb.toUpperCase());
	     System.out.println ("Frequency:->" + f_total_frequency.toUpperCase());
	     System.out.println ("Time of Day:->" + timeOfDay.toUpperCase());
	     System.out.println ("Dosage:->" + total_dosage.toUpperCase());
	     System.out.println ("Dosage Form:->" + dosage_form.toUpperCase());
	     System.out.println ("Duration:->" + f_total_duration.toUpperCase());
	     System.out.println ("Strength:->" + f_dosage_strength.toUpperCase());
	     System.out.println ("Route of Administration:->" + routeOfAdmin.toUpperCase());
	     System.out.println ("Site of Administration:->" + siteOfAdmin.toUpperCase());
	     System.out.println ("Vehicle->" + vehicle.toUpperCase());
	     System.out.println("--------------------------------");
	     System.out.println("--------------------------------");
	     
	     // Add the values in the bean to transfer to the results page
	     parseBean.setDosage(total_dosage.toUpperCase());
	     parseBean.setDosageForm(dosage_form.toUpperCase());
	     parseBean.setDrugStrength(f_dosage_strength.toUpperCase());
	     parseBean.setDuration(f_total_duration.toUpperCase());
	     parseBean.setFrequency(f_total_frequency.toUpperCase());
	     parseBean.setRouteOfAdmin(routeOfAdmin.toUpperCase());
	     parseBean.setSiteOfAdmin(siteOfAdmin.toUpperCase());
	     parseBean.setTimeOfDay(timeOfDay.toUpperCase());
	     parseBean.setVehicle(vehicle.toUpperCase());
	     parseBean.setVerb(verb.toUpperCase());
	     
	     return parseBean;
	     

	}
	
	/**
	 * Function to check whether the string is number or not
	 * @param input
	 * @return
	 */
	public boolean checkforNumber(String input){
		
		boolean flag = true;
		
		try	{
			Integer.parseInt(input);
		}
		catch(NumberFormatException e){
			flag = false;
		}
		return flag;
	}
	
	/**
	 * Method to determine whether the given token is a drug Strength metrics
	 * @param drugStrength
	 * @return
	 */
	public boolean isDrugForm(String drugStrength){
		
		boolean  isDrugFormFlag =false;
		for(int i = 0;i <dosageMetrics.size();i++){
			if(drugStrength.contains(dosageMetrics.get(i).toLowerCase())
					|| drugStrength.contains(dosageMetrics.get(i).toUpperCase())){
				isDrugFormFlag = true;
				break;
			}
		}
		return isDrugFormFlag;
	}
	
	/**
	 * Method to check whether '.' is special character or as a floating point number in the sentence
	 * @param inputSig
	 * @return
	 */
	public boolean checkForDot(String inputSig){
		
		boolean isCheckForFloating = false;
    	String arraytoken[] = inputSig.split("[ ]");
    	for(int i = 0 ;i< arraytoken.length; i++){
    	String regex = "[0-9]*[\\.]([0-9]{1,3}[a-zA-Z]*)";
    	if(arraytoken[i].matches(regex)){
    		isCheckForFloating = true;
    		break;
    		 }
    	}
    	return isCheckForFloating;
	}
	
	/**
	 * Method for splitting up the tokens with "X"
	 * @param input
	 * @return
	 */
	
	public String getSentenceAfterXSplit(String input){
		
		String  splitXSentence = "";
		StringTokenizer st = new StringTokenizer(input," ");
		int totalNoOfTokens = st.countTokens();
		String tokenArray[] = new String[totalNoOfTokens];
		int a = 0;
		while(st.hasMoreTokens()) {
			tokenArray[a] = st.nextToken(); 
			if((tokenArray[a].contains("x") || tokenArray[a].contains("X"))){
				
				splitXSentence = " " + splitXSentence  + " " + tokenArray[a].substring(0, 1)+ " ";
				splitXSentence = " " + splitXSentence  + " " + tokenArray[a].substring(1, tokenArray[a].length())+ " ";
			}
			else{
				splitXSentence = splitXSentence + " " + tokenArray[a] + " ";
			}
			a++;
		} 
		return splitXSentence;
	}
	
	
	/**
	 * Method for splitting up the tokens with "Q"
	 * @param input
	 * @return
	 */
	
	public String getSentenceAfterQSplit(String input){
		
		String  qSentence = "";
		StringTokenizer st = new StringTokenizer(input," ");
		int totalNoOfTokens = st.countTokens();
		String tokenArray[] = new String[totalNoOfTokens];
		int a = 0;
		while(st.hasMoreTokens()) {
			tokenArray[a] = st.nextToken(); 
			if((tokenArray[a].matches("[Qq][0-9]*[Hh]"))){
				int qIndex = (tokenArray[a].toUpperCase()).indexOf("Q");
				int hIndex = (tokenArray[a].toUpperCase()).indexOf("H");
				String duration = tokenArray[a].substring(qIndex+1, hIndex);
				qSentence = " " + qSentence  + " " + "Q" + " " + duration + " " + "H" + " ";
			}
			else{
				qSentence = " " + qSentence + " " + tokenArray[a] + " ";
			}
			a++;
		} 
		return qSentence;
	}
	
	
	/**
	 * Method for getting English sentence for Latin abbreviation
	 * @param input
	 * @return
	 */
	
	public String getLatintoEnglishSentence(String input){
		
		String  latinToEngSentence = "";
		StringTokenizer st = new StringTokenizer(input," ");
		int totalNoOfTokens = st.countTokens();
		String tokenArray[]  = new String[totalNoOfTokens];
		int i = 0;
		while(st.hasMoreTokens()) {
		tokenArray[i] = st.nextToken(); 
		if(latinToEnglishMapping.containsKey(tokenArray[i].toUpperCase())){
			latinToEngSentence = latinToEngSentence + " " + latinToEnglishMapping.get(tokenArray[i].toUpperCase()) + " ";
		}
		else
		{
			latinToEngSentence = latinToEngSentence + " " + tokenArray[i] + " ";
		}
		i++;
		} 
		return latinToEngSentence;
	}
	
	
	/**
	 * Method for calculating dosage strength
	 * @param input
	 * @return
	 */
	
	public HashMap getDosageStrength(String input){
		
		HashMap dosageStrengthHashMap =  new HashMap();
		String dosage_strength = "";
		boolean isDrugStrengthProcessed = false;
		StringTokenizer st = new StringTokenizer(input," ");
		int totalNoOfTokens = st.countTokens();
		String tokenArray[] = new String[totalNoOfTokens];
		int n = 0;
		while(st.hasMoreTokens()) {
			tokenArray[n] = st.nextToken(); 
			if(isDrugForm(tokenArray[n]) == true){
				dosage_strength = tokenArray[n];
				isDrugStrengthProcessed = true;
			}
			n++;
		} 
	dosageStrengthHashMap.put("dosageStrength", dosage_strength);
	dosageStrengthHashMap.put("isDrugStrengthProcessed", isDrugStrengthProcessed);
	return dosageStrengthHashMap;
	}
	
	/**
	 * Method for calculating frequency
	 * @param input
	 * @return
	 */
	
	public HashMap getFrequency(String input){
		
		String additional_dosage_duration ="";
		String freq = "";
		String total_frequency = "";
		int a = 0;
		boolean durationFlag =  false;
		HashMap frequencyHashMap =  new HashMap();
		StringTokenizer st = new StringTokenizer(input," ");
		int totalNoOfTokens = st.countTokens();
		String tokenArray[] = new String[totalNoOfTokens];
		while(st.hasMoreTokens()) {
			tokenArray[a] = st.nextToken(); 
			a++;
		}
		for (int x=0; x<tokenArray.length; x++){
			// Looking for frequency by matching with the keyword "times" or "time"
			 if(tokenArray[x].toLowerCase().equalsIgnoreCase("times") 
					 || tokenArray[x].toLowerCase().equalsIgnoreCase("time")){
				 int y = x+1;
				 do {
					 additional_dosage_duration = additional_dosage_duration + " " + tokenArray[y];
					 y++;
				 }while(!(temporals.contains(tokenArray[y-1].toLowerCase())));
				 freq = tokenArray[x-1];
	    		 total_frequency = tokenArray[x-1] + " " + (tokenArray[x].equalsIgnoreCase("x")? "times" : tokenArray[x]) + additional_dosage_duration;
	    		 durationFlag = true;
	    	 }
			// Looking for frequency by matching with the keyword "ONCE, TWICE, THRICE"
			 else if(durationFlag == false && tokenArray[x].equalsIgnoreCase("ONCE")|| tokenArray[x].equalsIgnoreCase("TWICE")||tokenArray[x].equalsIgnoreCase("THRICE")){
				 total_frequency = tokenArray[x];
				 int y = x+1;
				 do {
					 additional_dosage_duration = additional_dosage_duration + " " + tokenArray[y];
					 y++;
				 }while(!(temporals.contains(tokenArray[y-1].toLowerCase())));
				 freq = tokenArray[x];
	    		 total_frequency = tokenArray[x] + additional_dosage_duration;
	    		 durationFlag = true;
			 }
			 else if(durationFlag == false && tokenArray[x].toLowerCase().equalsIgnoreCase("every")){
				 total_frequency = tokenArray[x];
				 int y = x+1;
				 do {
					 additional_dosage_duration = additional_dosage_duration + " " + tokenArray[y];
					 y++;
				 }while(!(temporals.contains(tokenArray[y-1].toLowerCase())));
	    		 total_frequency = tokenArray[x] + additional_dosage_duration;
	    		 durationFlag = true;
			 }
			 else if(durationFlag == false && oneWordFrequency.contains(tokenArray[x].toLowerCase())){
				 
				 total_frequency = tokenArray[x];
			 }
		}
			 frequencyHashMap.put("additional_dosage_duration", additional_dosage_duration);
			 frequencyHashMap.put("freq", freq);
			 frequencyHashMap.put("total_frequency", total_frequency);
			 frequencyHashMap.put("durationFlag", durationFlag);
			 return frequencyHashMap;
	}
	
	/**
	 * Method for calculating duration
	 * @param input
	 * @return
	 */
	public String getTotalDuration(String input){
		
		int a = 0;
		String total_duration = "";
		boolean isTemporal = false;
		StringTokenizer st = new StringTokenizer(input," ");
		int totalNoOfTokens = st.countTokens();
		String tokenArray[] = new String[totalNoOfTokens];
		while(st.hasMoreTokens()) {
			tokenArray[a] = st.nextToken(); 
			a++;
		}
		for (int x=0; x<tokenArray.length; x++){
		 if(durationDelimiter.contains(tokenArray[x].toLowerCase()))
		 {
			 int y = x+1;
			 while(!(y == totalNoOfTokens)){
				 if(temporals.contains(tokenArray[y].toLowerCase())){
					 isTemporal = true;
					 break;
				 }
				 y++;
			 }
			 
			 if(isTemporal){
				 total_duration = total_duration + " " + tokenArray[x+1] + " " + tokenArray[x+2];
			 }
		 }	
		}
		return total_duration;
	}
}