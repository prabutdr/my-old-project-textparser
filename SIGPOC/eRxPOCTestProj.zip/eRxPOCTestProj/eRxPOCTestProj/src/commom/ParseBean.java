package commom;

public class ParseBean {

	private String inputString ="";
	private String fullConvertedString = "";
	private String verb = "";
	private String frequency = "";
	private String timeOfDay ="";
	private String dosage ="";
	private String dosageForm ="";
	private String duration ="";
	private String drugStrength = "";
	private String routeOfAdmin = "";
	private String siteOfAdmin = "";
	private String vehicle = "";
	
	public String getInputString() {
		return inputString;
	}
	public void setInputString(String inputString) {
		this.inputString = inputString;
	}
	public String getFullConvertedString() {
		return fullConvertedString;
	}
	public void setFullConvertedString(String fullConvertedString) {
		this.fullConvertedString = fullConvertedString;
	}
	public String getVerb() {
		return verb;
	}
	public void setVerb(String verb) {
		this.verb = verb;
	}
	public String getFrequency() {
		return frequency;
	}
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	public String getTimeOfDay() {
		return timeOfDay;
	}
	public void setTimeOfDay(String timeOfDay) {
		this.timeOfDay = timeOfDay;
	}
	public String getDosage() {
		return dosage;
	}
	public void setDosage(String dosage) {
		this.dosage = dosage;
	}
	public String getDosageForm() {
		return dosageForm;
	}
	public void setDosageForm(String dosageForm) {
		this.dosageForm = dosageForm;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getDrugStrength() {
		return drugStrength;
	}
	public void setDrugStrength(String drugStrength) {
		this.drugStrength = drugStrength;
	}
	public String getRouteOfAdmin() {
		return routeOfAdmin;
	}
	public void setRouteOfAdmin(String routeOfAdmin) {
		this.routeOfAdmin = routeOfAdmin;
	}
	public String getSiteOfAdmin() {
		return siteOfAdmin;
	}
	public void setSiteOfAdmin(String siteOfAdmin) {
		this.siteOfAdmin = siteOfAdmin;
	}
	public String getVehicle() {
		return vehicle;
	}
	public void setVehicle(String vehicle) {
		this.vehicle = vehicle;
	}
}
