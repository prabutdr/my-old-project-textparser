package commom;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * Servlet implementation class DisplayResults
 */
public class DisplayResults extends HttpServlet {
	private static final long serialVersionUID = 1L;
	List<ParseBean> resultList = new ArrayList<ParseBean>();
    /**
     * Default constructor. 
     */
    public DisplayResults() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		try {
		     EntityParser dict = new EntityParser();
			dict.loadConfig();
		     FileInputStream file = new FileInputStream(new File("D:\\SampleInput.xlsx"));
		     PrintWriter out = new PrintWriter(new File("D:\\eRxPoS\\eRxPOCTestProj\\eRxPOCTestProj\\Output.txt"));
		    
		   // FileInputStream file = new FileInputStream(new File("C:\\Hi.xlsx"));
           
		     //Get the workbook instance for XLS file 
		     XSSFWorkbook workbook = new XSSFWorkbook (file);
		   
		     //Get first sheet from the workbook
		     XSSFSheet sheet = workbook.getSheetAt(0);
		     
		    //Get the workbook instance for XLS file 
		   // HSSFWorkbook workbook = new HSSFWorkbook(file);
		 
		    //Get first sheet from the workbook
		   // HSSFSheet sheet = workbook.getSheetAt(0);
		     
		    //Iterate through each rows from first sheet
		    Iterator<Row> rowIterator = sheet.iterator();
		    int count = 0;
		    while(rowIterator.hasNext()) {
		        Row row = rowIterator.next();
		         
		        //For each row, iterate through each columns
		        count++;
		        Iterator<Cell> cellIterator = row.cellIterator();
		        while(cellIterator.hasNext()) {
		        	Cell cell = cellIterator.next();
		        	ParseBean p = dict.matchValues(cell.getStringCellValue());
		        	resultList.add(p);
		        	
		        	out.println("Record - " + count);
		        	out.println("Input SIG: " + p.getInputString());
		        	out.println("Recommended SIG: " + p.getFullConvertedString());
		        	out.println("Verb: " + p.getVerb());
		        	out.println("Frequency: " + p.getFrequency());
		        	out.println("TimeOfDay: " + p.getTimeOfDay());
		        	out.println("Dosage: " + p.getDosage());
		        	out.println("DosageForm: " + p.getDosageForm());
		        	out.println("Duration: " + p.getDuration());
		        	out.println("DrugStrength: " + p.getDrugStrength());
		        	out.println("RouteOfAdmin: " + p.getRouteOfAdmin());
		        	out.println("SiteOfAdmin: " + p.getSiteOfAdmin());
		        	out.println("Vehicle: " + p.getVehicle());
		        	out.println();
		        }
		    }
		    file.close();
		    out.close();
		} catch (FileNotFoundException e) {
		    e.printStackTrace();
		} catch (IOException e) {
		    e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
		request.setAttribute("resultListBean", resultList);
		RequestDispatcher rd = request.getRequestDispatcher("ResultPage.jsp");
		rd.forward(request, response);
	}
	}
	
