package commom;

import java.util.Map;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EntityParser {
	/**
	 * 
	 * @param input
	 * @return
	 */
	public SIGToken parse(String input) {
		SIGToken tokens = new SIGToken();
		
		// Convert entire SIG to upper case
		input = input.toUpperCase();
		tokens.setOriginalSIG(input);
		
		// Replace special chars
		input = replaceSpecialChars(input);
		input = input.replaceAll("\\s+", " ").trim();
		
		input = parseSpecialFormats(input);
		input = input.replaceAll("\\s+", " ").trim();
		
		input = replaceLatinAbbr(input);
		input = input.replaceAll("\\s+", " ").trim();

		input = replaceOtherAbbr(input);
		input = input.replaceAll("\\s+", " ").trim();

		input = CommonUtils.replaceNumberWordsToDigits(input);
		input = input.replaceAll("\\s+", " ").trim();

		tokens.setConvertedSIG(input);

		input = parseFrequency(input, tokens);
		input = input.replaceAll("\\s+", " ").trim();
		
		input = parseDrugStrength(input, tokens);
		input = input.replaceAll("\\s+", " ").trim();

		input = parseDosageInfo(input, tokens);
		input = input.replaceAll("\\s+", " ").trim();
		
		input = parseDuration(input, tokens);
		input = input.replaceAll("\\s+", " ").trim();
		
		input = matchDictionary(input, tokens);
		input = input.replaceAll("\\s+", " ").trim();
		
		input = removeIgnorableTokens(input);
		
		tokens.setNonParsedTokens(input);
		
		return tokens;
	}

	/**
	 * 
	 * @param input
	 * @return
	 */
	private static String replaceLatinAbbr(String input) {
		StringBuffer originalSIG = new StringBuffer(input);

		// Replace latin words with English 
		for (Map.Entry<String,String> entry : Dictionary.latinAbbrMap.entrySet()) {
			  String key = entry.getKey();
			  
			  int startIdx, endIdx;
			  endIdx = 0;
			  
			  while((startIdx = originalSIG.indexOf(key, endIdx)) != -1) {
				  endIdx = startIdx + key.length();
				  if(((startIdx <= 0) || (!Character.isLetter(originalSIG.charAt(startIdx - 1)) && !Character.isDigit(originalSIG.charAt(startIdx - 1))))
						  && ((endIdx >= originalSIG.length()) || (!Character.isLetter(originalSIG.charAt(endIdx)) && !Character.isDigit(originalSIG.charAt(endIdx))))) {
					  originalSIG.replace(startIdx, endIdx, entry.getValue());
					  endIdx = startIdx;
				  }
			  }
		}
		
		return originalSIG.toString();
	}
	
	/**
	 * 
	 * @param input
	 * @return
	 */
	private static String replaceOtherAbbr(String input) {
		StringBuffer originalSIG = new StringBuffer(input);

		// Replace other abbreviations 
		for (Map.Entry<String,String> entry : Dictionary.otherAbbrMap.entrySet()) {
			  String key = entry.getKey();
			  
			  int startIdx, endIdx;
			  endIdx = 0;
			  
			  while((startIdx = originalSIG.indexOf(key, endIdx)) != -1) {
				  endIdx = startIdx + key.length();
				  if(((startIdx <= 0) || (!Character.isLetter(originalSIG.charAt(startIdx - 1)) && !Character.isDigit(originalSIG.charAt(startIdx - 1))))
						  && ((endIdx >= originalSIG.length()) || (!Character.isLetter(originalSIG.charAt(endIdx)) && !Character.isDigit(originalSIG.charAt(endIdx))))) {
					  originalSIG.replace(startIdx, endIdx, entry.getValue());
					  endIdx = startIdx;
				  }
			  }
		}
		
		return originalSIG.toString();
	}
	
	/**
	 * 
	 * @param input
	 * @return
	 */
	private static String replaceSpecialChars(String input) {
		// Replace special chars per mapping
		for (Map.Entry<String,String> entry : Dictionary.specialCharMap.entrySet()) {
			input = input.replaceAll(entry.getKey(), entry.getValue());
		}
		
		StringBuffer originalSIG = new StringBuffer(input);
		Pattern pattern = Pattern.compile("[0-9][\\,][0-9]");
	    while(true) {
		    Matcher matcher = pattern.matcher(originalSIG);
		    if (matcher.find()) {
		    	originalSIG.replace(matcher.start() + 1, matcher.start() + 2, GeneralConstants.EMPTY_STRING);
		    }
		    else {
		    	break; // stop if there is no match
		    }
		}
		/*pattern = Pattern.compile("[^0-9 ][\\.][^0-9 ]");
	    while(true) {
		    Matcher matcher = pattern.matcher(originalSIG);
		    if (matcher.find()) {
		    	originalSIG.replace(matcher.start() + 1, matcher.start() + 2, " . ");
		    }
		    else {
		    	break; // stop if there is no match
		    }
		    System.out.println(matcher);
		}*/
	    input = originalSIG.toString();

		// Replace comma (,) & dot (.) characters appropriately
		String token;
		StringTokenizer st = new StringTokenizer(input," ");
		input = "";
		String regexNumbersWithDot = "[0-9]*[\\.]([0-9]{1,3}[a-zA-Z]*)";
		//String regexNumbersWithComma = "[0-9]*[\\,]([0-9]{1,3}[a-zA-Z]*)";
		while(st.hasMoreTokens()) {
			token = st.nextToken(); 
			if(!(token.matches(regexNumbersWithDot))){
				token = token.replaceAll("[.]", " . ");
			}
			else {
				token = token.replaceAll("[,]", " , "); 
			}
			
			input = input + " " + token;
		}
		
		return input;
	}
	
	/**
	 * 
	 * @param input
	 * @return
	 */
	private static String removeIgnorableTokens(String input) {
		StringBuffer originalSIG = new StringBuffer(input);

		for(String ignorableToken: Dictionary.ignorableTokens) {
			  int startIdx, endIdx;
			  endIdx = 0;
			  
			  while((startIdx = originalSIG.indexOf(ignorableToken, endIdx)) != -1) {
				  endIdx = startIdx + ignorableToken.length();
				  if(((startIdx <= 0) || (!Character.isLetter(originalSIG.charAt(startIdx - 1)) && !Character.isDigit(originalSIG.charAt(startIdx - 1))))
						  && ((endIdx >= originalSIG.length()) || (!Character.isLetter(originalSIG.charAt(endIdx)) && !Character.isDigit(originalSIG.charAt(endIdx))))) {
					  originalSIG.replace(startIdx, endIdx, GeneralConstants.EMPTY_STRING);
					  endIdx = startIdx;
				  }
			  }
		}
		
		return originalSIG.toString().trim();
	}

	/**
	 * 
	 * @param input
	 * @return
	 */
	private static String parseSpecialFormats(String input) {
		StringBuffer originalSIG = new StringBuffer(input);

		// 1. Parse format like Q24H, Q2-6H..etc 
	    Pattern pattern = Pattern.compile("[Qq][0-9-]+[Hh]");
	    while(true) {
		    Matcher matcher = pattern.matcher(originalSIG);
		    if (matcher.find()) {
		    	originalSIG.replace(matcher.start(), matcher.start() + 1, " Q ");
		    	originalSIG.replace(matcher.end() + 1, matcher.end() + 2, " H ");
		    }
		    else {
		    	break; // stop if there is no match
		    }
	    }

	    // 2. Parse format like "x30 days" 
	    pattern = Pattern.compile("[X][\\s]*[0-9]+");
	    while(true) {
		    Matcher matcher = pattern.matcher(originalSIG);
		    if (matcher.find()) {
		    	originalSIG.replace(matcher.start(), matcher.start() + 1, " FOR ");
		    }
		    else {
		    	break; // stop if there is no match
		    }
	    }
		
	    // 3. Parse format like "2x a day" 
	    pattern = Pattern.compile("[0-9]+[\\s]*[X]");
	    while(true) {
		    Matcher matcher = pattern.matcher(originalSIG);
		    if (matcher.find()) {
		    	//System.out.println("end - " +matcher.end());
		    	originalSIG.replace(matcher.end() - 1, matcher.end(), " TIMES ");
		    }
		    else {
		    	break; // stop if there is no match
		    }
	    }
		
		return originalSIG.toString();
	}
	
	/**
	 * 
	 * @param input
	 * @param tokens
	 * @return
	 */
	private static String parseDrugStrength(String input, SIGToken tokens) {
		StringBuffer originalSIG = new StringBuffer(input);

		for(String dosageMetrics: Dictionary.dosageMetrics) {
			Pattern pattern = Pattern.compile("((\\d+[./-])?\\d+)?[\\s]*" + dosageMetrics);
		    while(true) {
			    Matcher matcher = pattern.matcher(originalSIG);
			    if (matcher.find()) {
			    	tokens.getDrugStrength().add(originalSIG.substring(matcher.start(), matcher.end()));
			    	
			    	originalSIG.replace(matcher.start(), matcher.end(), GeneralConstants.EMPTY_STRING);
			    }
			    else {
			    	break; // stop if there is no match
			    }
		    }
		}
		
		return originalSIG.toString();
	}
	
	/**
	 * 
	 * @param input
	 * @param tokens
	 * @return
	 */
	private static String parseDuration(String input, SIGToken tokens) {
		StringBuffer originalSIG = new StringBuffer(input);

		for(String dosageMetrics: Dictionary.durationMetrics) {
			Pattern pattern = Pattern.compile("((\\d+[./-])?\\d+)+[\\s]*" + dosageMetrics);
		    while(true) {
			    Matcher matcher = pattern.matcher(originalSIG);
			    if (matcher.find()) {
			    	tokens.getDuration().add(originalSIG.substring(matcher.start(), matcher.end()));
			    	
			    	originalSIG.replace(matcher.start(), matcher.end(), GeneralConstants.EMPTY_STRING);
			    }
			    else {
			    	break; // stop if there is no match
			    }
		    }
		}
		
		return originalSIG.toString();
	}
	
	/**
	 * 
	 * @param input
	 * @param tokens
	 * @return
	 */
	private static String parseDosageInfo(String input, SIGToken tokens) {
		StringBuffer originalSIG = new StringBuffer(input);

		for(String dosageForm: Dictionary.dosageForm) {
			Pattern pattern = Pattern.compile("((\\d+[./-])?\\d+)?[\\s]*" + dosageForm);
		    while(true) {
			    Matcher matcher = pattern.matcher(originalSIG);
			    if (matcher.find()) {
			    	String dosage = originalSIG.substring(matcher.start(), matcher.end()).replace(dosageForm, "").trim();
			    	if(!GeneralConstants.EMPTY_STRING.equals(dosage)) {
			    		tokens.getDosage().add(dosage);
			    	}
			    	tokens.getDosageForm().add(dosageForm);
			    	
			    	originalSIG.replace(matcher.start(), matcher.end(), GeneralConstants.EMPTY_STRING);
			    }
			    else {
			    	break; // stop if there is no match
			    }
		    }
		}
		
		return originalSIG.toString();
	}

	/**
	 * 
	 * @param input
	 * @param tokens
	 * @return
	 */
	private static String parseFrequency(String input, SIGToken tokens) {
		StringBuffer originalSIG = new StringBuffer(input);

		for(String frequencySuffix: Dictionary.frequencySuffix) {
			Pattern pattern = Pattern.compile("((\\d+[./-])?\\d+)?[\\s]*" + frequencySuffix);
		    while(true) {
			    Matcher matcher = pattern.matcher(originalSIG);
			    if (matcher.find()) {
			    	tokens.getFrequency().add(originalSIG.substring(matcher.start(), matcher.end()));
			    	
			    	originalSIG.replace(matcher.start(), matcher.end(), GeneralConstants.EMPTY_STRING);
			    }
			    else {
			    	break; // stop if there is no match
			    }
		    }
		}
		
		for(String frequencySuffixWithEvery: Dictionary.frequencySuffixWithEvery) {
			Pattern pattern = Pattern.compile("EVERY[\\s]*((\\d+[./-])?\\d+)?[\\s]*" + frequencySuffixWithEvery);
		    while(true) {
			    Matcher matcher = pattern.matcher(originalSIG);
			    if (matcher.find()) {
			    	tokens.getFrequency().add(originalSIG.substring(matcher.start(), matcher.end()));
			    	
			    	originalSIG.replace(matcher.start(), matcher.end(), GeneralConstants.EMPTY_STRING);
			    }
			    else {
			    	break; // stop if there is no match
			    }
		    }
		}

		return originalSIG.toString();
	}
	
	/**
	 * 
	 * @param input
	 * @param tokens
	 * @return
	 */
	private static String matchDictionary(String input, SIGToken tokens) {
		StringBuffer originalSIG = new StringBuffer(input);
		String tokenType;

		for (Map.Entry<String,String> entry : Dictionary.tokenList.entrySet()) {
			String key = entry.getKey();
			 
			int startIdx, endIdx;
			endIdx = 0;
			  
			while((startIdx = originalSIG.indexOf(key, endIdx)) != -1) {
				endIdx = startIdx + key.length();
				if(((startIdx <= 0) || (!Character.isLetter(originalSIG.charAt(startIdx - 1)) && !Character.isDigit(originalSIG.charAt(startIdx - 1))))
						&& ((endIdx >= originalSIG.length()) || (!Character.isLetter(originalSIG.charAt(endIdx)) && !Character.isDigit(originalSIG.charAt(endIdx))))) {
					tokenType = entry.getValue();
					 
					if(Dictionary.VERB.equals(tokenType)) {
						tokens.getVerb().add(key);
					}
					else if(Dictionary.FREQUENCY.equals(tokenType)) {
						tokens.getFrequency().add(key);
					}
					else if(Dictionary.TIME_OF_DAY.equals(tokenType)) {
						tokens.getTimeOfDay().add(key);
					}
					else if(Dictionary.DURATION.equals(tokenType)) {
						tokens.getDuration().add(key);
					}
					else if(Dictionary.DRUG_STRENGTH.equals(tokenType)) {
						tokens.getDrugStrength().add(key);
					}
					else if(Dictionary.ROUTE_OF_ADMIN.equals(tokenType)) {
						tokens.getRouteOfAdmin().add(key);
					}
					else if(Dictionary.SITE_OF_ADMIN.equals(tokenType)) {
						tokens.getSiteOfAdmin().add(key);
					}
					else if(Dictionary.VEHICLE.equals(tokenType)) {
						tokens.getVehicle().add(key);
					}
					else if(Dictionary.INDICATION.equals(tokenType)) {
						tokens.getIndication().add(key);
					}
					else if(Dictionary.DIRECTION.equals(tokenType)) {
						tokens.getDirection().add(key);
					}
					else if(Dictionary.INSTRUCTION.equals(tokenType)) {
						tokens.getInstruction().add(key);
					}
					
					originalSIG.replace(startIdx, endIdx, GeneralConstants.EMPTY_STRING);
					endIdx = startIdx;
				}
			}
		}
		
		return originalSIG.toString();
	}
	
	/**
	 * Main method for testing
	 * @param args
	 */
	public static void main(String[] args) { 
		String input = "inhale 1 puff by inhalation route every 12 hours";
		input = input.toUpperCase();
		input = parseSpecialFormats(input);
		System.out.println("Input String after replacing latin abbr: " + input);
		
		SIGToken tokens = new SIGToken(); 
		input = parseDrugStrength(input, tokens);
		input = input.replaceAll("\\s+", " ").trim();

		input = parseDosageInfo(input, tokens);
		
		System.out.println("Output - " + tokens.getDrugStrength());
		System.out.println("Output - " + tokens.getDosage());
	}
	
}