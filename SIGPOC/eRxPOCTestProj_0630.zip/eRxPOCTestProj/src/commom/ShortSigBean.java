package commom;

public class ShortSigBean {

	private String shortVerb = "";
	private String shortFrequency = "";
	private String shortTimeOfDay = "";
	private String shortDosageForm = "";
	private String shortVehicle = "";
	private String shortDuration = "";
	private String shortRouteOfAdmin = "";
	private String shortSiteOfAdmin = "";
	private String drugStrength = "";
	private String dosage = "";
	
	public String getDrugStrength() {
		return drugStrength;
	}
	public void setDrugStrength(String drugStrength) {
		this.drugStrength = drugStrength;
	}
	public String getDosage() {
		return dosage;
	}
	public void setDosage(String dosage) {
		this.dosage = dosage;
	}
	public String getShortVerb() {
		return shortVerb;
	}
	public void setShortVerb(String shortVerb) {
		this.shortVerb = shortVerb;
	}
	public String getShortFrequency() {
		return shortFrequency;
	}
	public void setShortFrequency(String shortFrequency) {
		this.shortFrequency = shortFrequency;
	}
	public String getShortTimeOfDay() {
		return shortTimeOfDay;
	}
	public void setShortTimeOfDay(String shortTimeOfDay) {
		this.shortTimeOfDay = shortTimeOfDay;
	}
	public String getShortDosageForm() {
		return shortDosageForm;
	}
	public void setShortDosageForm(String shortDosageForm) {
		this.shortDosageForm = shortDosageForm;
	}
	public String getShortVehicle() {
		return shortVehicle;
	}
	public void setShortVehicle(String shortVehicle) {
		this.shortVehicle = shortVehicle;
	}
	public String getShortDuration() {
		return shortDuration;
	}
	public void setShortDuration(String shortDuration) {
		this.shortDuration = shortDuration;
	}
	public String getShortRouteOfAdmin() {
		return shortRouteOfAdmin;
	}
	public void setShortRouteOfAdmin(String shortRouteOfAdmin) {
		this.shortRouteOfAdmin = shortRouteOfAdmin;
	}
	public String getShortSiteOfAdmin() {
		return shortSiteOfAdmin;
	}
	public void setShortSiteOfAdmin(String shortSiteOfAdmin) {
		this.shortSiteOfAdmin = shortSiteOfAdmin;
	}
}
