/**
 * 
 */
package commom;

/**
 * To hold common constant values for this application
 * 
 * @author Cognizant
 *
 */
public class GeneralConstants {
	public static String SPACE_STRING = " ";
	
	public static String EMPTY_STRING = "";
}
