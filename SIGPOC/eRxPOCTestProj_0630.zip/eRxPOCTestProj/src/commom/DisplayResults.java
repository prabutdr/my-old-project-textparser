package commom;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DisplayResults
 */
public class DisplayResults extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    ShortSigGenerator generator =  new ShortSigGenerator();

	EntityParser dict = new EntityParser();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<SIGToken> resultList = new ArrayList<SIGToken>();
		Scanner scanner;
		PrintWriter out;
		
		try {
		     scanner = new Scanner(new File("C:\\Users\\153093\\Desktop\\Prabu\\RFP\\SIG_POC\\eRxPOCTestProj\\eRxPOCTestProj\\IO\\SIG_Input.txt"));
		     out = new PrintWriter(new File("C:\\Users\\153093\\Desktop\\Prabu\\RFP\\SIG_POC\\eRxPOCTestProj\\eRxPOCTestProj\\IO\\SIG_Output.txt"));

		     int count = 0;
		     while(scanner.hasNextLine()) {
		    	 String line = scanner.nextLine(); 
		    	 SIGToken tokens = dict.parse(line);
		    	 String shortSig = generator.generateShortSig(tokens);
		        	
		    	 tokens.setShortSig(shortSig);
		    	 resultList.add(tokens);
		        	
		    	 out.println("Record - " + ++count);
		    	 out.println("Input SIG: " + tokens.getOriginalSIG());
		    	 out.println("Recommended SIG: " + tokens.getConvertedSIG());
		    	 out.println("Non Parsed Tokens: " + tokens.getNonParsedTokens());
		    	 out.println("Verb: " + CommonUtils.toString(tokens.getVerb()));
		    	 out.println("Frequency: " + CommonUtils.toString(tokens.getFrequency()));
		    	 out.println("TimeOfDay: " + CommonUtils.toString(tokens.getTimeOfDay()));
		    	 out.println("Dosage: " + CommonUtils.toString(tokens.getDosage()));
		    	 out.println("DosageForm: " + CommonUtils.toString(tokens.getDosageForm()));
		    	 out.println("Duration: " + CommonUtils.toString(tokens.getDuration()));
		    	 out.println("DrugStrength: " + CommonUtils.toString(tokens.getDrugStrength()));
		    	 out.println("RouteOfAdmin: " + CommonUtils.toString(tokens.getRouteOfAdmin()));
		    	 out.println("SiteOfAdmin: " + CommonUtils.toString(tokens.getSiteOfAdmin()));
		    	 out.println("Vehicle: " + CommonUtils.toString(tokens.getVehicle()));
		    	 out.println("Indication: " + CommonUtils.toString(tokens.getIndication()));
		    	 out.println("Direction: " + CommonUtils.toString(tokens.getDirection()));
		    	 out.println("Instruction: " + CommonUtils.toString(tokens.getInstruction()));
		    	 out.println();
		     }
		     scanner.close();
		     out.close();
		} catch (FileNotFoundException e) {
		    e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		request.setAttribute("resultListBean", resultList);
		RequestDispatcher rd = request.getRequestDispatcher("ResultPage.jsp");
		rd.forward(request, response);
	}
}
	
