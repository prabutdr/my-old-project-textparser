package commom;

import java.util.ArrayList;

public class SIGToken {

	private String originalSIG ="";
	private String convertedSIG = "";
	private String nonParsedTokens = "";
	private String shortSig = "";
	
	private ArrayList<String> verb = new ArrayList<String>();
	private ArrayList<String> frequency = new ArrayList<String>();
	private ArrayList<String> timeOfDay = new ArrayList<String>();
	private ArrayList<String> dosage = new ArrayList<String>();
	private ArrayList<String> dosageForm = new ArrayList<String>();
	private ArrayList<String> duration = new ArrayList<String>();
	private ArrayList<String> drugStrength = new ArrayList<String>();
	private ArrayList<String> routeOfAdmin = new ArrayList<String>();
	private ArrayList<String> siteOfAdmin = new ArrayList<String>();
	private ArrayList<String> vehicle = new ArrayList<String>();
	private ArrayList<String> indication = new ArrayList<String>();
	private ArrayList<String> direction = new ArrayList<String>();
	private ArrayList<String> instruction = new ArrayList<String>();
	
	
	/**
	 * @return the originalSIG
	 */
	public String getOriginalSIG() {
		return originalSIG;
	}
	/**
	 * @param originalSIG the originalSIG to set
	 */
	public void setOriginalSIG(String originalSIG) {
		this.originalSIG = originalSIG;
	}
	/**
	 * @return the convertedSIG
	 */
	public String getConvertedSIG() {
		return convertedSIG;
	}
	/**
	 * @param convertedSIG the convertedSIG to set
	 */
	public void setConvertedSIG(String convertedSIG) {
		this.convertedSIG = convertedSIG;
	}
	/**
	 * @return the verb
	 */
	public ArrayList<String> getVerb() {
		return verb;
	}
	/**
	 * @param verb the verb to set
	 */
	public void setVerb(ArrayList<String> verb) {
		this.verb = verb;
	}
	/**
	 * @return the frequency
	 */
	public ArrayList<String> getFrequency() {
		return frequency;
	}
	/**
	 * @param frequency the frequency to set
	 */
	public void setFrequency(ArrayList<String> frequency) {
		this.frequency = frequency;
	}
	/**
	 * @return the timeOfDay
	 */
	public ArrayList<String> getTimeOfDay() {
		return timeOfDay;
	}
	/**
	 * @param timeOfDay the timeOfDay to set
	 */
	public void setTimeOfDay(ArrayList<String> timeOfDay) {
		this.timeOfDay = timeOfDay;
	}
	/**
	 * @return the dosage
	 */
	public ArrayList<String> getDosage() {
		return dosage;
	}
	/**
	 * @param dosage the dosage to set
	 */
	public void setDosage(ArrayList<String> dosage) {
		this.dosage = dosage;
	}
	/**
	 * @return the dosageForm
	 */
	public ArrayList<String> getDosageForm() {
		return dosageForm;
	}
	/**
	 * @param dosageForm the dosageForm to set
	 */
	public void setDosageForm(ArrayList<String> dosageForm) {
		this.dosageForm = dosageForm;
	}
	/**
	 * @return the duration
	 */
	public ArrayList<String> getDuration() {
		return duration;
	}
	/**
	 * @param duration the duration to set
	 */
	public void setDuration(ArrayList<String> duration) {
		this.duration = duration;
	}
	/**
	 * @return the drugStrength
	 */
	public ArrayList<String> getDrugStrength() {
		return drugStrength;
	}
	/**
	 * @param drugStrength the drugStrength to set
	 */
	public void setDrugStrength(ArrayList<String> drugStrength) {
		this.drugStrength = drugStrength;
	}
	/**
	 * @return the routeOfAdmin
	 */
	public ArrayList<String> getRouteOfAdmin() {
		return routeOfAdmin;
	}
	/**
	 * @param routeOfAdmin the routeOfAdmin to set
	 */
	public void setRouteOfAdmin(ArrayList<String> routeOfAdmin) {
		this.routeOfAdmin = routeOfAdmin;
	}
	/**
	 * @return the siteOfAdmin
	 */
	public ArrayList<String> getSiteOfAdmin() {
		return siteOfAdmin;
	}
	/**
	 * @param siteOfAdmin the siteOfAdmin to set
	 */
	public void setSiteOfAdmin(ArrayList<String> siteOfAdmin) {
		this.siteOfAdmin = siteOfAdmin;
	}
	/**
	 * @return the vehicle
	 */
	public ArrayList<String> getVehicle() {
		return vehicle;
	}
	/**
	 * @param vehicle the vehicle to set
	 */
	public void setVehicle(ArrayList<String> vehicle) {
		this.vehicle = vehicle;
	}
	/**
	 * @return the nonParsedTokens
	 */
	public String getNonParsedTokens() {
		return nonParsedTokens;
	}
	/**
	 * @param nonParsedTokens the nonParsedTokens to set
	 */
	public void setNonParsedTokens(String nonParsedTokens) {
		this.nonParsedTokens = nonParsedTokens;
	}
	/**
	 * @return the indication
	 */
	public ArrayList<String> getIndication() {
		return indication;
	}
	/**
	 * @param indication the indication to set
	 */
	public void setIndication(ArrayList<String> indication) {
		this.indication = indication;
	}
	/**
	 * @return the direction
	 */
	public ArrayList<String> getDirection() {
		return direction;
	}
	/**
	 * @param direction the direction to set
	 */
	public void setDirection(ArrayList<String> direction) {
		this.direction = direction;
	}
	/**
	 * @return the instruction
	 */
	public ArrayList<String> getInstruction() {
		return instruction;
	}
	/**
	 * @param instruction the instruction to set
	 */
	public void setInstruction(ArrayList<String> instruction) {
		this.instruction = instruction;
	}
	/**
	 * @return the shortSig
	 */
	public String getShortSig() {
		return shortSig;
	}
	/**
	 * @param shortSig the shortSig to set
	 */
	public void setShortSig(String shortSig) {
		this.shortSig = shortSig;
	}
	
	public double getParseScore() {
		int orginalTokenCount = originalSIG.trim().split("\\s+").length; // [ ;:\\.\\,\\)\\(]
		int nonParsedTokenCount = 0;
		if(!GeneralConstants.EMPTY_STRING.equals(nonParsedTokens)) {
			nonParsedTokenCount = nonParsedTokens.trim().split("\\s+").length;
		}
		double parsePercentage = (((double)orginalTokenCount - nonParsedTokenCount)/orginalTokenCount) * 100;

		System.out.println("originalSIG - " + originalSIG);
		System.out.println("nonParsedTokens - " + nonParsedTokens);
		System.out.println("orginalTokenCount - " + orginalTokenCount);
		System.out.println("nonParsedTokenCount - " + nonParsedTokenCount);
		System.out.println("parsePercentage - " + parsePercentage);
		
		return parsePercentage;
	}
}
