package commom;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;


public class ShortSigGenerator {

	public Map<String,String> shortSigMappingVerb = new HashMap<String, String>();
	public Map<String,String> shortSigMappingFrequency = new HashMap<String, String>();
	public Map<String,String> shortSigMappingTimeOfDay = new HashMap<String, String>();
	public Map<String,String> shortSigMappingDosageForm = new HashMap<String, String>();
	public Map<String,String> shortSigMappingVehicle = new HashMap<String, String>();
	public Map<String,String> shortSigMappingRouteOfAdmin = new HashMap<String, String>();
	public Map<String,String> shortSigMappingSiteOfAdmin = new HashMap<String, String>();
	
	ArrayList<String> matcherList = new ArrayList<String>(
		    Arrays.asList("TAKE","INHALE","PUFF","BY MOUTH","EVERY","HOURS","ONCE DAILY","DAILY","TWICE DAILY","TWICE A DAY","THRICE A DAY",
		    		"THRICE DAILY","FOUR TIMES A DAY","FOUR TIMES DAILY","FIVE TIMES A DAY","FIVE TIMES DAILY",
		    		"4 TIMES A DAY","2 TIMES A DAY","3 TIMES A DAY","1 TIMES A DAY","EVERY MORNING"));
	//Short Sig mapping
	
	public String generateShortSig(SIGToken bean){
		
		ShortSigBean shortSigBean = new ShortSigBean();
		shortSigMappingVerb.put("TAKE", "TK");
		shortSigMappingVerb.put("INHALE", "INL");
		shortSigMappingDosageForm.put("PUFF", "PFS");
		shortSigMappingRouteOfAdmin.put("BY MOUTH", "PO");
		shortSigMappingFrequency.put("EVERY", "Q");
		shortSigMappingFrequency.put("HOURS", "H");
		shortSigMappingFrequency.put("ONCE DAILY", "1 X A DAY");
		shortSigMappingFrequency.put("DAILY", "D");
		shortSigMappingFrequency.put("TWICE DAILY", "BID");
		shortSigMappingFrequency.put("2 TIMES A DAY", "BID");
		shortSigMappingFrequency.put("TWO TIMES A DAY", "TID");
		shortSigMappingFrequency.put("TWO TIMES DAILY", "TID");
		shortSigMappingFrequency.put("2 TIMES DAILY", "TID");
		shortSigMappingFrequency.put("TWICE A DAY", "BID");
		shortSigMappingFrequency.put("THRICE A DAY", "TID");
		shortSigMappingFrequency.put("3 TIMES A DAY", "TID");
		shortSigMappingFrequency.put("3 TIMES DAILY", "TID");
		shortSigMappingFrequency.put("THREE TIMES A DAY", "TID");
		shortSigMappingFrequency.put("THREE TIMES DAILY", "TID");
		shortSigMappingFrequency.put("THRICE DAILY", "TID");
		shortSigMappingFrequency.put("FOUR TIMES A DAY", "QID");
		shortSigMappingFrequency.put("FOUR TIMES DAILY", "QID");
		shortSigMappingFrequency.put("4 TIMES A DAY", "QID");
		shortSigMappingFrequency.put("4 TIMES DAILY", "QID");
		shortSigMappingFrequency.put("FIVE TIMES A DAY", "FID");
		shortSigMappingFrequency.put("FIVE TIMES DAILY", "FID");
		shortSigMappingFrequency.put("5 TIMES A DAY", "FID");
		shortSigMappingFrequency.put("5 TIMES DAILY", "FID");
		shortSigMappingFrequency.put("EVERY MORNING", "QAM");
		
	
		String verb = CommonUtils.toString(bean.getVerb());
		String dosage = CommonUtils.toString(bean.getDosage());
		String frequency = CommonUtils.toString(bean.getFrequency());
		String timeOfDay = CommonUtils.toString(bean.getTimeOfDay());
		String dosageForm = CommonUtils.toString(bean.getDosageForm());
		String drugStrength = CommonUtils.toString(bean.getDrugStrength());
		String vehicle =CommonUtils.toString( bean.getVehicle());
		String duration = CommonUtils.toString(bean.getDuration());
		String routeOfAdmin = CommonUtils.toString(bean.getRouteOfAdmin());
		String siteOfAdmin = CommonUtils.toString(bean.getSiteOfAdmin());
		
		String shortVerb = getShortSigForVerb(verb);
		String shortFrequency = getShortSigForFrequency(frequency);
		String shortTimeOfDay = getShortSigForTimeOfDay(timeOfDay);
		String shortDosageForm = getShortSigForDosageForm(dosageForm);
		String shortVehicle = getShortSigForVehicle(vehicle);
		String shortDuration = getShortSigForDuration(duration);
		String shortRouteOfAdmin = getShortSigForRouteOfAdmin(routeOfAdmin);
		String shortSiteOfAdmin = getShortSigForSiteOfAdmin(siteOfAdmin);
		
		shortSigBean.setDosage(dosage);
		shortSigBean.setDrugStrength(drugStrength);
		shortSigBean.setShortVerb(shortVerb);
		shortSigBean.setShortFrequency(shortFrequency);
		shortSigBean.setShortTimeOfDay(shortTimeOfDay);
		shortSigBean.setShortDosageForm(shortDosageForm);
		shortSigBean.setShortVehicle(shortVehicle);
		shortSigBean.setShortDuration(shortDuration);
		shortSigBean.setShortRouteOfAdmin(shortRouteOfAdmin);
		shortSigBean.setShortSiteOfAdmin(shortSiteOfAdmin);
		
		String shortSig = generateShortSig(shortSigBean);
	
		return shortSig;
	
	
	}
	
	
	public String getShortSigForVerb(String inputVerb){
		
		if(!(inputVerb == null || inputVerb.equalsIgnoreCase(""))){
			inputVerb = inputVerb.trim();
			if(matcherList.contains(inputVerb)){
				inputVerb = shortSigMappingVerb.get(inputVerb);
			}
		}
		
		return inputVerb;
	}
	
	public String getShortSigForFrequency(String inputFrequency){
		
		String shortSigFrequency = "";
		String tokens[] = inputFrequency.split(" ");
		if(!(inputFrequency == null || inputFrequency.equalsIgnoreCase(""))){
			if(matcherList.contains(inputFrequency)){
				shortSigFrequency = shortSigMappingFrequency.get(inputFrequency);
			}
			else{
				for(int i = 0 ; i<tokens.length ; i++){
					if(matcherList.contains(tokens[i])){
						shortSigFrequency = shortSigFrequency + " " + shortSigMappingFrequency.get(tokens[i]);
					}
					else{
						shortSigFrequency = shortSigFrequency + " " + tokens[i];
					}
				}
			}
		}
		
		return shortSigFrequency;
	}

	public String getShortSigForTimeOfDay(String inputTimeOfDay){
	
	return "";
	}

	public String getShortSigForDosageForm(String inputDosageForm){
		
		if(!(inputDosageForm == null || inputDosageForm.equalsIgnoreCase(""))){
			inputDosageForm = inputDosageForm.trim();
			if(matcherList.contains(inputDosageForm)){
				inputDosageForm = shortSigMappingDosageForm.get(inputDosageForm);
			}
		}
	
	return inputDosageForm;
	}

	public String getShortSigForVehicle(String inputVehicle){
	
	return "";
	}	
	
	public String getShortSigForDuration(String inputSiteOfAdmin){
		
		return "";
	}	
	
	public String getShortSigForRouteOfAdmin(String inputRouteOfAdmin){
		
		String routeOfAdmin = "";
		
		if(!(inputRouteOfAdmin == null || inputRouteOfAdmin.equalsIgnoreCase(""))){
			routeOfAdmin = "BY" + " " + inputRouteOfAdmin;
			if(matcherList.contains(routeOfAdmin)){
				routeOfAdmin = shortSigMappingRouteOfAdmin.get(routeOfAdmin);
			}
		}
		
		return routeOfAdmin;
		}	
	
	public String getShortSigForSiteOfAdmin(String inputRouteOfAdmin){
		
		return "";
		}	
	
	public String generateShortSig(ShortSigBean bean){
		
		String shortSig = bean.getShortVerb() + " " + bean.getDosage() + " " + bean.getShortDosageForm() + " " + bean.getShortRouteOfAdmin() + " " + bean.getShortFrequency();
		
		return shortSig;
	}
	
}
