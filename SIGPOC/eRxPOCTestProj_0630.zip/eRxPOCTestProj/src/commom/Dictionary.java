package commom;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * To hold entire lookup values (words/sentences) as dictionary.
 * 
 * TODO: Values are hard-coded here currently, later it will be loaded from DB/files. 
 * 
 * @author Cognizant
 *
 */
public class Dictionary {
	public static final String VERB = "VERB";

	public static final String FREQUENCY = "FREQUENCY";

	public static final String TIME_OF_DAY = "TIME_OF_DAY";

	public static final String DURATION = "DURATION";

	public static final String DRUG_STRENGTH = "DRUG_STRENGTH";

	public static final String ROUTE_OF_ADMIN = "ROUTE_OF_ADMIN";

	public static final String SITE_OF_ADMIN = "SITE_OF_ADMIN";

	public static final String VEHICLE = "VEHICLE";

	public static final String INDICATION = "INDICATION";

	public static final String DIRECTION = "DIRECTION";

	public static final String INSTRUCTION = "INSTRUCTION";

	/**
	 * This map will hold list of historical tokens map
	 */
	public static Map<String,String> tokenList;
	
	/**
	 * This map will contain Latin abbreviation to English sentence 
	 */
	public static Map<String,String> latinAbbrMap;
	
	/**
	 * This map will contain other abbreviations
	 */
	public static Map<String,String> otherAbbrMap;
	
	/**
	 * This map will contain special chars and equivalent direct replacement 
	 */
	public static Map<String,String> specialCharMap;
	
	public static ArrayList<String> ignorableTokens = new ArrayList<String>(
		    Arrays.asList("A", "AN", "THE", "OF", "AT", "ON", "UPON", "IN", "TO", "FROM", "OUT", "AS", "SO", "SUCH", "OR", "AND", "THOSE", 
		    		"THIS", "THESE", "THAT", "FOR", ",", "IS", "WAS", "AM", "ARE", "BEEN", "WERE", "BY", "ROUTE", "TOTAL", ".", "(", ")", ";", ":"));
	
	public static ArrayList<String> dosageForm = new ArrayList<String>(
		    Arrays.asList("PATCH", "APPLICATION", "SHAMPOO", "LOTION", "FILM(S)", "FILM", "FLIMS", "OTIC", "PACKET", "PACKETS", "PKT", "INCH",
		    		"INCHS", "KIT", "KITS", "APPLICATOR", "APPLICATORS", "PILL", "PILLS", "PUFF", "PUFFS",
		    		"TABLET", "TABLETS", "TAB", "TABS", "CAP", "CAPS", "CAPSULE", "CAPSULES", "SUPPOSITORY", "SPRAY", "FOAM/SHAMPOO",
		    		"CREAM/GEL", "INJECTION", "SOLUTION"));
	
	public static ArrayList<String> dosageMetrics = new ArrayList<String>(
		    Arrays.asList("SQUIRT", "SQUIRTS", "UNITS", "UNIT", "MG", "GRAM", "GM", "MILIGRAM", "MCG", "ML", 
		    		"MILLILITRE", "DROP", "DROPS", "TSP", "CC", "TEASPOON", "TEASPOONS", "TABLESPOON"));
	
	public static ArrayList<String> durationMetrics = new ArrayList<String>(
		    Arrays.asList("DAY", "DAYS", "MONTH", "MONTHS", "WEEK", "WEEKS", "YEAR", "YEARS"));

	public static ArrayList<String> frequencySuffix = new ArrayList<String>(
		    Arrays.asList("TIME PER DAY", "TIMES PER DAY", "TIMES A DAY", "TIMES DAY", "TIMES EVERY DAY", "TIMES A WEEK", "TIMES DAILY", "TIME DAILY", "TIMES EVERY WEEK"));

	public static ArrayList<String> frequencySuffixWithEvery = new ArrayList<String>(
		    Arrays.asList("HOURS", "HOUR", "DAYS", "HOURLY", "BEDTIME", "DAY", "EVENING", "MORNING", "NIGHT", "OTHER DAY"));

	static {
		// Load history tokens list
		HashMap<String, String> tmpTokenList = new HashMap<String, String>();
		tmpTokenList.put("TAKE", Dictionary.VERB);
		tmpTokenList.put("PUT", Dictionary.VERB);
		tmpTokenList.put("APPLY", Dictionary.VERB);
		tmpTokenList.put("INJECT", Dictionary.VERB);
		tmpTokenList.put("INHALE", Dictionary.VERB);
		tmpTokenList.put("SPRAY", Dictionary.VERB);
		tmpTokenList.put("GIVE", Dictionary.VERB);
		tmpTokenList.put("PLACE", Dictionary.VERB);
		tmpTokenList.put("CHEW", Dictionary.VERB);
		tmpTokenList.put("SWALLOW", Dictionary.VERB);
		tmpTokenList.put("INSTILL", Dictionary.VERB);
		tmpTokenList.put("INSERT", Dictionary.VERB);
		tmpTokenList.put("DISSOLVE", Dictionary.VERB);

		tmpTokenList.put("DAILY", Dictionary.FREQUENCY);
		tmpTokenList.put("NIGHTLY", Dictionary.FREQUENCY);
		
		tmpTokenList.put("MORNING", Dictionary.TIME_OF_DAY);
		tmpTokenList.put("NOON", Dictionary.TIME_OF_DAY);
		tmpTokenList.put("AFTERNOON", Dictionary.TIME_OF_DAY);
		tmpTokenList.put("EVENING", Dictionary.TIME_OF_DAY);
		tmpTokenList.put("NIGHT", Dictionary.TIME_OF_DAY);
		tmpTokenList.put("BEDTIME", Dictionary.TIME_OF_DAY);
		tmpTokenList.put("A DAY", Dictionary.DURATION);
		tmpTokenList.put("FOURTEEN DAYS", Dictionary.DURATION);
		tmpTokenList.put("ONE MONTH", Dictionary.DURATION);
		tmpTokenList.put("THIRTY DAYS", Dictionary.DURATION);
		tmpTokenList.put("220 MCG", Dictionary.DRUG_STRENGTH);
		tmpTokenList.put("EAR", Dictionary.ROUTE_OF_ADMIN);
		tmpTokenList.put("EARS", Dictionary.ROUTE_OF_ADMIN);
		tmpTokenList.put("INHALATION", Dictionary.ROUTE_OF_ADMIN);
		tmpTokenList.put("MOUTH", Dictionary.ROUTE_OF_ADMIN);
		tmpTokenList.put("NASAL", Dictionary.ROUTE_OF_ADMIN);
		tmpTokenList.put("ORAL", Dictionary.ROUTE_OF_ADMIN);
		tmpTokenList.put("ORALLY", Dictionary.ROUTE_OF_ADMIN);
		//tmpTokenList.put("OTIC", Dictionary.ROUTE_OF_ADMIN);
		tmpTokenList.put("RECTAL", Dictionary.ROUTE_OF_ADMIN);
		tmpTokenList.put("RECTALLY", Dictionary.ROUTE_OF_ADMIN);
		tmpTokenList.put("SUBCUTANEOUS", Dictionary.ROUTE_OF_ADMIN);
		tmpTokenList.put("TOPICAL", Dictionary.ROUTE_OF_ADMIN);
		tmpTokenList.put("TRANSDERMAL", Dictionary.ROUTE_OF_ADMIN);
		tmpTokenList.put("NOSE", Dictionary.ROUTE_OF_ADMIN);
		tmpTokenList.put("INTRANASAL", Dictionary.ROUTE_OF_ADMIN);
		tmpTokenList.put("BOTH EYES", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("BOTH LIDS", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("EACH NOSTRIL", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("EYE", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("EYES", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("OPERATIVE EYE", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("LEFT ARMPIT", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("LEFT EYE", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("LEGS ARMS", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("LUNGS", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("MUSCLE", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("NOSE", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("RECTUM", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("RIGHT EYE", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("SCALP", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("SCALP FACE", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("SKIN", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("SKIN SCALP", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("TONGUE", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("NOSTRIL", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("ARMPIT", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("HAND", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("FACE", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("LEG", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("LEGS", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("ARM", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("ARMS", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("EYELID", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("EYELIDS", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("LIDS", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("LID", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("EMPTY STOMACH", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("AFFECTED AREA", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("AFFECTED SITE", Dictionary.SITE_OF_ADMIN);
		tmpTokenList.put("FOOD", Dictionary.VEHICLE);
		tmpTokenList.put("WITH FOOD", Dictionary.VEHICLE);
		tmpTokenList.put("FOOD MILK", Dictionary.VEHICLE);
		tmpTokenList.put("FOOD WATER", Dictionary.VEHICLE);
		tmpTokenList.put("INHALER", Dictionary.VEHICLE);
		tmpTokenList.put("MEAL", Dictionary.VEHICLE);
		tmpTokenList.put("WITH MEAL", Dictionary.VEHICLE);
		tmpTokenList.put("MEALS", Dictionary.VEHICLE);
		tmpTokenList.put("WITH MEALS", Dictionary.VEHICLE);
		tmpTokenList.put("BEFORE MEALS", Dictionary.VEHICLE);
		tmpTokenList.put("AFTER MEALS", Dictionary.VEHICLE);
		tmpTokenList.put("BEFORE A MEAL", Dictionary.VEHICLE);
		tmpTokenList.put("AFTER A MEAL", Dictionary.VEHICLE);
		tmpTokenList.put("MEALS FOOD", Dictionary.VEHICLE);
		tmpTokenList.put("WATER", Dictionary.VEHICLE);
		tmpTokenList.put("MILK", Dictionary.VEHICLE);
		tmpTokenList.put("ASTHMA", Dictionary.INDICATION);
		tmpTokenList.put("BACK PAIN", Dictionary.INDICATION);
		tmpTokenList.put("PAIN", Dictionary.INDICATION);
		tmpTokenList.put("MUSCLE SPASMS", Dictionary.INDICATION);
		tmpTokenList.put("PAIN CENTER", Dictionary.INDICATION);
		tmpTokenList.put("AS NEEDED", Dictionary.DIRECTION);
		tmpTokenList.put("AS DIRECTED", Dictionary.DIRECTION);

		// Load matching English sentence for Latin abbreviations
		HashMap<String, String> tmpLatinAbbrMap = new HashMap<String, String>();
		tmpLatinAbbrMap.put("PO", "BY MOUTH");
		tmpLatinAbbrMap.put("Q", "EVERY");
		tmpLatinAbbrMap.put("H", "HOURS");
		tmpLatinAbbrMap.put("BID", "TWICE DAILY");
		tmpLatinAbbrMap.put("INH", "INHALE 1 PUFFS EVERY 2 HOURS");
		tmpLatinAbbrMap.put("QPM", "EVERY EVENING");
		tmpLatinAbbrMap.put("QAM", "EVERY MORNING");
		tmpLatinAbbrMap.put("QID", "FOUR TIMES DAILY");
		tmpLatinAbbrMap.put("PRN", "AS NEEDED");
		tmpLatinAbbrMap.put("QD", "DAILY");
		tmpLatinAbbrMap.put("TID", "THREE TIMES DAILY");
		tmpLatinAbbrMap.put("QHS", "EVERY NIGHT AT BEDTIME");
		tmpLatinAbbrMap.put("HS", "AT BEDTIME");
		tmpLatinAbbrMap.put("C", "CAPSULE");
		tmpLatinAbbrMap.put("T", "TABLET");
		tmpLatinAbbrMap.put("TK", "TAKE");
		tmpLatinAbbrMap.put("APP", "APPLY");
		tmpLatinAbbrMap.put("GTT", "DROP");
		tmpLatinAbbrMap.put("GTTS", "DROPS");
		tmpLatinAbbrMap.put("OS", "LEFT EYE");
		tmpLatinAbbrMap.put("OD", "RIGHT EYE");
		tmpLatinAbbrMap.put("OU", "BOTH EYES");
		tmpLatinAbbrMap.put("U", "USE");
		tmpLatinAbbrMap.put("SQ", "SUBCUTANEOUS");
		tmpLatinAbbrMap.put("AC", "BEFORE A MEAL");
		tmpLatinAbbrMap.put("IM", "IN THE MUSCLE");
		tmpLatinAbbrMap.put("TSP", "TEASPOON");
		tmpLatinAbbrMap.put("QOD", "EVERY OTHER DAY");
		tmpLatinAbbrMap.put("QDAY", "DAILY");
		tmpLatinAbbrMap.put("AA", "TO THE AFFECTED AREA");
		tmpLatinAbbrMap.put("NEB", "NEBULIZER");
		tmpLatinAbbrMap.put("XD", "TIMES DAILY" );
		tmpLatinAbbrMap.put("XDAY", "TIMES A DAY" );

		HashMap<String, String> tmpOtherAbbrMap = new HashMap<String, String>();
		tmpOtherAbbrMap.put("W/FOOD", "WITH FOOD");
		tmpOtherAbbrMap.put("HR", "HOUR");
		tmpOtherAbbrMap.put("HRS", "HOURS");
		tmpOtherAbbrMap.put("ONCE", "1 TIME");
		tmpOtherAbbrMap.put("TWICE", "2 TIMES");
		tmpOtherAbbrMap.put("THRICE", "3 TIMES");
		tmpOtherAbbrMap.put("HRLY", "HOURLY");
		
		// Load matching replacement for special chars
		HashMap<String, String> tmpSpecialCharMap = new HashMap<String, String>();
		tmpSpecialCharMap.put(";", " ; ");
		tmpSpecialCharMap.put("\\(", " ( "); // (
		tmpSpecialCharMap.put("\\)", " ) "); // )
		tmpSpecialCharMap.put("\\^", " ^ ");
		tmpSpecialCharMap.put(":", " : ");
		tmpSpecialCharMap.put("#", " # ");
		tmpSpecialCharMap.put("\\(S\\)", "S"); // (S)
		
		/*** TODO: look for optimization - order by n-gram ***/
		tokenList = new LinkedHashMap<String, String>();
		ArrayList<String> list = new ArrayList<String>(tmpTokenList.keySet());
		Collections.sort(list, new NGramDescComparator());
		for(String key: list) {
			tokenList.put(key, tmpTokenList.get(key));
		}

		latinAbbrMap = new LinkedHashMap<String, String>();
		list = new ArrayList<String>(tmpLatinAbbrMap.keySet());
		Collections.sort(list, new NGramDescComparator());
		for(String key: list) {
			latinAbbrMap.put(key, tmpLatinAbbrMap.get(key));
		}
		
		otherAbbrMap = new LinkedHashMap<String, String>();
		list = new ArrayList<String>(tmpOtherAbbrMap.keySet());
		Collections.sort(list, new NGramDescComparator());
		for(String key: list) {
			otherAbbrMap.put(key, tmpOtherAbbrMap.get(key));
		}

		specialCharMap = new LinkedHashMap<String, String>();
		list = new ArrayList<String>(tmpSpecialCharMap.keySet());
		Collections.sort(list, new NGramDescComparator());
		for(String key: list) {
			specialCharMap.put(key, tmpSpecialCharMap.get(key));
		}
		
		Collections.sort(dosageForm, new NGramDescComparator());
		Collections.sort(dosageMetrics, new NGramDescComparator());
		Collections.sort(durationMetrics, new NGramDescComparator());
		Collections.sort(frequencySuffix, new NGramDescComparator());
		Collections.sort(frequencySuffixWithEvery, new NGramDescComparator());
		Collections.sort(ignorableTokens, new NGramDescComparator());
		
		// Print & verify order
		/*System.out.println("\nLatin to Eng Abbreviations - ");
		for (Map.Entry<String,String> entry : latinAbbrMap.entrySet()) {
			  String key = entry.getKey();
			  String value = entry.getValue();
			  System.out.println(key + " = " + value);
		}
		
		System.out.println("\nToken List - ");
		for (Map.Entry<String,String> entry : tokenList.entrySet()) {
			  String key = entry.getKey();
			  String value = entry.getValue();
			  System.out.println(key + " = " + value);
		}
		
		System.out.println("\nspecialCharMap List - ");
		for (Map.Entry<String,String> entry : specialCharMap.entrySet()) {
			  String key = entry.getKey();
			  String value = entry.getValue();
			  System.out.println(key + " = " + value);
		}
		*/
	}	
	
	public static void main(String[] args) {
		//Dictionary dictionary = new Dictionary();
		String str = "saravanansaravanan";
		str = str.replaceAll("ra", "test");
		System.out.println("TESTRP - " + str);
	}
}